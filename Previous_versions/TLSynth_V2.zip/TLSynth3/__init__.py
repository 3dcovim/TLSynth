bl_info = {
	"name": "TLSynth",
	"blender": (2, 80, 0),
	"category": "Object",
	"version": (2, 0),
	"author": "3DCoVim",
	"description": "Real-time scanner simulator for meshes. Multiple representation and exportation options are available",
	"location": "View3D > Tool Shelf",
	"warning": "",
	"doc_url": "https://github.com/3dcovim/TLSynth",
}

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
import bpy_extras.view3d_utils
import os
import math
import re

recursion_guard = False  # Bandera global o de la clase

def pause_depsgraph_handler(handler_func):
	# Elimina temporalmente el controlador depsgraph_update_post"""
	if handler_func in bpy.app.handlers.depsgraph_update_post:
		bpy.app.handlers.depsgraph_update_post.remove(handler_func)
		return True
	return False

def resume_depsgraph_handler(handler_func):
	# Vuelve a agregar el controlador depsgraph_update_post"""
	if handler_func not in bpy.app.handlers.depsgraph_update_post:
		bpy.app.handlers.depsgraph_update_post.append(handler_func)

def cleanup_render_resources():
	# Eliminar materiales de Text, cilindros, y wireframe
	materials_to_remove = ['texto_Copy', 'cilindro_rojo', 'Wireframe_Material_Copy']
	for mat_name in materials_to_remove:
		mat = bpy.data.materials.get(mat_name)
		if mat:
			bpy.data.materials.remove(mat)

	# Eliminar Geometry Node de Text
	text_geometry_node_name = "Text_GN_"  # Nombre base del Geometry Node
	for node_group in bpy.data.node_groups:
		if node_group.name.startswith(text_geometry_node_name):
			bpy.data.node_groups.remove(node_group)

def find_target():
	return bpy.data.objects.get("Target")

def find_scanners():
	return [obj for obj in bpy.data.objects if obj.name.startswith('scanner')]

def create_top_camera(target, image_width, image_height):
	bpy.ops.object.camera_add(location=(0, 0, 10))
	camera = bpy.context.active_object

	# Obtener el centro del bounding box en coordenadas globales
	# center_world = get_bounding_box_center_world(target)
	# camera.location.x = center_world.x
	# camera.location.y = center_world.y
	
	# Obtener las dimensiones del bounding box
	bbox_corners = [target.matrix_world @ Vector(corner) for corner in target.bound_box]
	bbox_x = abs(bbox_corners[0][0] - bbox_corners[4][0])
	bbox_y = abs(bbox_corners[0][1] - bbox_corners[2][1])
	max_dim = max(bbox_x, bbox_y)
	
	# Configurar la cámara ortográfica para encuadrar el target
	camera.data.type = 'ORTHO'
	margin = 1.1
	camera.data.ortho_scale = max_dim * margin
	
	# Posicionar cámara
	center = target.location
	camera.location.x = center.x
	camera.location.y = center.y
	max_z = max((target.matrix_world @ v.co).z for v in target.data.vertices)
	camera.location.z = max_z + (max_dim * margin)
	
	if max_dim == bbox_y:
		camera.rotation_euler = (0, 0, 90)
	# Rotar cámara para vista superior
	camera.rotation_euler = (0, 0, 0)
	
	# Establecer la cámara como la activa
	bpy.context.scene.camera = camera
	return camera

def get_bounding_box_center_world(obj):
	from mathutils import Vector
	
	# Obtener el bounding box en coordenadas locales
	local_bbox = [Vector(corner) for corner in obj.bound_box]
	
	# Transformar las coordenadas locales del bounding box a coordenadas globales
	world_bbox = [obj.matrix_world @ corner for corner in local_bbox]
	
	# Calcular el centro del bounding box en el espacio global
	min_corner = Vector((min(v.x for v in world_bbox),
						 min(v.y for v in world_bbox),
						 min(v.z for v in world_bbox)))
	
	max_corner = Vector((max(v.x for v in world_bbox),
						 max(v.y for v in world_bbox),
						 max(v.z for v in world_bbox)))

	center_world = (min_corner + max_corner) / 2.0
	return center_world

def get_max_z(obj):
	# Obtener el valor máximo en Z de los vértices en coordenadas globales
	return max((obj.matrix_world @ v.co).z for v in obj.data.vertices)

def set_background_white():
	world = bpy.data.worlds["World"]
	world.use_nodes = True
	bg_node = world.node_tree.nodes.get('Background')
	if not bg_node:
		bg_node = world.node_tree.nodes.new(type='ShaderNodeBackground')
	bg_node.inputs[0].default_value = (1, 1, 1, 1)

def set_background_default():
	world = bpy.data.worlds["World"]
	world.use_nodes = True
	bg_node = world.node_tree.nodes.get('Background')
	if not bg_node:
		bg_node = world.node_tree.nodes.new(type='ShaderNodeBackground')
	bg_node.inputs[0].default_value = (0.3, 0.3, 0.3, 1)

def apply_wireframe_material(obj):
	# Guardar todos los materiales originales
	obj["original_materials"] = [mat for mat in obj.data.materials]

	# Crear y asignar material wireframe
	mat = bpy.data.materials.new(name="Wireframe_Material_Copy")
	mat.use_nodes = True
	nodes = mat.node_tree.nodes
	links = mat.node_tree.links
	nodes.clear()
	
	material_output = nodes.new('ShaderNodeOutputMaterial')
	wireframe = nodes.new('ShaderNodeWireframe')
	invert_color = nodes.new('ShaderNodeInvert')
	
	wireframe.inputs['Size'].default_value = 0.01
	links.new(wireframe.outputs['Fac'], invert_color.inputs['Color'])
	links.new(invert_color.outputs['Color'], material_output.inputs['Surface'])
	
	obj.data.materials.clear()  # Borrar materiales actuales
	obj.data.materials.append(mat)  # Asignar solo el wireframe

def save_original_materials(obj):
	# Guarda los materiales originales y su asignación a las caras de la malla."""
	materials = list(obj.data.materials)
	material_indices = [p.material_index for p in obj.data.polygons]
	return materials, material_indices

def restore_materials(obj, original_data):
	# Restaura los materiales y su asignación a las caras."""
	materials, material_indices = original_data

	# Limpiar los materiales actuales del objeto
	obj.data.materials.clear()
	
	# Restaurar los materiales originales
	for mat in materials:
		obj.data.materials.append(mat)
	
	# Restaurar la asignación de materiales a las caras
	for i, poly in enumerate(obj.data.polygons):
		poly.material_index = material_indices[i]

# def restore_material(obj):
	# if "original_materials" in obj:
		# # Restaurar los materiales originales
		# obj.data.materials.clear()  # Borrar materiales wireframe
		# for mat in obj["original_materials"]:
			# obj.data.materials.append(mat)  # Restaurar cada material original
		# del obj["original_materials"]  # Eliminar la propiedad después de restaurar

def text_gn_2_003_node_group(group_name, text_size):
	text_gn_2_003 = bpy.data.node_groups.new(type='GeometryNodeTree', name=group_name)
	
	# Crear nodos necesarios
	string_to_curves = text_gn_2_003.nodes.new("GeometryNodeStringToCurves")
	string = text_gn_2_003.nodes.new("FunctionNodeInputString")
	fill_curve = text_gn_2_003.nodes.new("GeometryNodeFillCurve")
	value = text_gn_2_003.nodes.new("ShaderNodeValue")
	set_material = text_gn_2_003.nodes.new("GeometryNodeSetMaterial")
	group_output = text_gn_2_003.nodes.new("NodeGroupOutput")
	
	group_output.name = "Group Output"
	group_output.is_active_output = True

	# Configurar parámetros de alineación
	string_to_curves.align_x = 'CENTER'
	string_to_curves.align_y = 'MIDDLE'
	string_to_curves.overflow = 'OVERFLOW'
	string_to_curves.pivot_mode = 'MIDPOINT'

	# Configuración de tamaño del texto
	value.outputs[0].default_value = text_size
	
	# Agregar y configurar el socket de geometría
	geometry_socket_10 = text_gn_2_003.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
	geometry_socket_10.attribute_domain = 'POINT'

	# Posicionar nodos
	group_output.location = (420.0, 0.0)
	string_to_curves.location = (-200.0, -100.0)
	string.location = (-400.0, -200.0)
	fill_curve.location = (0.0, -100.0)
	value.location = (-400.0, -300.0)
	set_material.location = (200.0, -100.0)

	# Conectar nodos
	text_gn_2_003.links.new(value.outputs[0], string_to_curves.inputs[1])
	text_gn_2_003.links.new(string.outputs[0], string_to_curves.inputs[0])
	text_gn_2_003.links.new(string_to_curves.outputs[0], fill_curve.inputs[0])
	text_gn_2_003.links.new(fill_curve.outputs[0], set_material.inputs[0])
	text_gn_2_003.links.new(set_material.outputs[0], group_output.inputs[0])

	# Asignar material creado
	set_material.inputs[2].default_value = create_text_material()
	
	return text_gn_2_003

def create_text_material():
	material = bpy.data.materials.new(name='texto_Copy')
	material.use_nodes = True
	nodes = material.node_tree.nodes
	links = material.node_tree.links
	nodes.clear()

	# Crear nodo: Material Output
	material_output = nodes.new('ShaderNodeOutputMaterial')
	material_output.location = (300.0, 300.0)

	# Crear nodo: Diffuse BSDF
	diffuse_bsdf = nodes.new('ShaderNodeBsdfDiffuse')
	diffuse_bsdf.location = (31.674, 263.246)
	diffuse_bsdf.inputs['Color'].default_value = (0, 0, 0, 1)  # Color negro
	diffuse_bsdf.inputs['Roughness'].default_value = 0.0

	# Conectar nodos
	links.new(diffuse_bsdf.outputs['BSDF'], material_output.inputs['Surface'])
	
	return material

def create_cylinder_material():
	material = bpy.data.materials.new(name='cilindro_rojo')
	material.use_nodes = True
	nodes = material.node_tree.nodes
	links = material.node_tree.links
	nodes.clear()

	# Crear nodo: Material Output
	material_output = nodes.new('ShaderNodeOutputMaterial')
	material_output.location = (300.0, 300.0)

	# Crear nodo: Diffuse BSDF
	diffuse_bsdf = nodes.new('ShaderNodeBsdfDiffuse')
	diffuse_bsdf.location = (31.674, 263.246)
	diffuse_bsdf.inputs['Color'].default_value = (1, 0, 0, 1)  # Color rojo
	diffuse_bsdf.inputs['Roughness'].default_value = 0.0

	# Conectar nodos
	links.new(diffuse_bsdf.outputs['BSDF'], material_output.inputs['Surface'])
	
	return material

def get_max_z(obj):
	max_z = max((obj.matrix_world @ v.co).z for v in obj.data.vertices)
	return max_z

def get_hit_distance(scanner):
	try:
		if scanner and scanner.modifiers.get("GeometryNodes"):
			depsgraph = bpy.context.evaluated_depsgraph_get()
			eval_scanner = scanner.evaluated_get(depsgraph)
			if eval_scanner.data.attributes.get("hit_distance"):
				hit_distance_attr = eval_scanner.data.attributes["hit_distance"]
				#float_value = hit_distance_attr.data[0].value
				if hit_distance_attr and len(hit_distance_attr.data) > 0:
					float_value = hit_distance_attr.data[0].value
				else:
					print({'WARNING'}, "The 'hit_distance' attribute was not found or has no data.")
					return None  # Devuelve None si el atributo no existe o está vacío
				#print({'INFO'}, f"Calculated Value: {float_value}")
				return str(round(float_value, 2))
			else:
				print({'WARNING'}, "The 'hit_distance' attribute was not found in the geometry.")
		else:
			print({'WARNING'}, "No object with a Geometry Nodes modifier was found.")
			return None
	except KeyError:
		return "-1.0"

def create_individual_text(text_value, location, max_z, text_size):
	location.z = max_z + 0.1
	bpy.ops.object.text_add(location=location)
	text_obj = bpy.context.active_object
	text_obj.name = f"Text_{text_value}"
	text_obj.visible_shadow = False  # Evitar sombras

	geo_nodes = text_gn_2_003_node_group(f"Text_GN_{text_value}", text_size)
	text_obj.modifiers.new(name="TextModifier", type='NODES')
	text_obj.modifiers["TextModifier"].node_group = geo_nodes

	nodes = text_obj.modifiers["TextModifier"].node_group.nodes
	nodes["String"].string = text_value
	
	return text_obj

def create_cylinder_at_scanner(location, radius, height, max_z):
	location.z = max_z + 0.1
	bpy.ops.mesh.primitive_cylinder_add(radius=radius, depth=height, location=location)
	cylinder = bpy.context.active_object
	cylinder.name = "Scanner_Cylinder"
	cylinder.data.materials.append(create_cylinder_material())
	return cylinder

def render_camera_image(filepath):
	bpy.context.scene.render.resolution_x = 800
	bpy.context.scene.render.resolution_y = 800
	bpy.context.scene.render.engine = 'BLENDER_EEVEE_NEXT'
	bpy.context.scene.render.filepath = filepath
	bpy.ops.render.render(write_still=True)
	print(f"Imagen renderizada y guardada en {filepath}")

def delete_objects(objects):
	bpy.ops.object.select_all(action='DESELECT')
	for obj in objects:
		obj.select_set(True)
	bpy.ops.object.delete()

class OBJECT_OT_render_top_view(bpy.types.Operator):
	bl_idname = "object.render_top_view"
	bl_label = "Generate Simplified Top View Image"
	bl_description = "Render a top view showing bounding box and scanners"

	filepath: bpy.props.StringProperty(subtype="FILE_PATH", default="//top_view_image.png")
	image_size: bpy.props.IntProperty(name="Image Size", default=1024, min=256, max=4096)
	
	def execute(self, context):
		was_paused = pause_depsgraph_handler(update_height_on_move)
		try:
			# Ejecutar el flujo
			target = bpy.data.objects.get(self.target_name)
			abs_path = bpy.path.abspath(self.filepath)
			if target:
				# Guardar material original de Target
				#original_material = target.active_material
				original_data = save_original_materials(target)
				
				set_background_white()
				apply_wireframe_material(target)
				scanners = find_scanners()
				
				# Calcular el radio y la altura del cilindro
				bbox = target.bound_box
				bbox_x = abs(bbox[0][0] - bbox[4][0])
				bbox_y = abs(bbox[0][1] - bbox[2][1])
				max_dim = max(bbox_x, bbox_y)
				cylinder_radius = max_dim / 15
				cylinder_height = cylinder_radius / 2

				camera = create_top_camera(target, self.image_size, self.image_size)
				max_z_target = get_max_z(target)
				text_objects = []
				cylinder_objects = []

				for scanner in scanners:
					hit_distance = get_hit_distance(scanner)
					if hit_distance is not None:
						# Continuar con el proceso si se ha obtenido un valor válido
						print(f"Hit distance: {hit_distance}")
						# Resto de código que usa hit_distance
						cylinder_obj = create_cylinder_at_scanner(scanner.location.copy(), cylinder_radius, cylinder_height, max_z_target)
						text_obj = create_individual_text(hit_distance, scanner.location.copy(), get_max_z(cylinder_obj), cylinder_radius)
						text_objects.append(text_obj)
						cylinder_objects.append(cylinder_obj)
					else:
						print({'WARNING'}, "Disable Improve Perfomance for this scanner.")
						self.report({'WARNING'}, f"Disable Improve Perfomance for this scanner.")
						# Opcionalmente, puedes decidir retornar 'CANCELLED' o manejarlo de otra manera
				
				render_camera_image(abs_path)
				
				delete_objects(text_objects + cylinder_objects)
				bpy.data.objects.remove(camera)
				
				# Restaurar el material original del Target
				#restore_material(target, original_material)
				#restore_material(target)
				restore_materials(target, original_data)
				# Llamar a la función de limpieza
				cleanup_render_resources()
				set_background_default()

			self.report({'INFO'}, f"Top view image saved at {abs_path}")
			return {'FINISHED'}
		finally:
			if was_paused:
				resume_depsgraph_handler(update_height_on_move)
				
		
	def invoke(self, context, event):
		self.target_name = context.scene.scanner_target_mesh
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}

	def draw_contour(self, shader, points, color):
		if points:
			indices = [(i, (i + 1) % len(points)) for i in range(len(points))]
			batch = batch_for_shader(shader, 'LINES', {"pos": points}, indices=indices)
			shader.bind()
			shader.uniform_float("color", color)
			batch.draw(shader)

	def draw_circle(self, shader, center, radius, segments, color):
		x, y = center
		vertices = [(x + radius * math.cos(2 * math.pi * i / segments), y + radius * math.sin(2 * math.pi * i / segments)) for i in range(segments)]
		vertices.append(vertices[0])  # Asegurar que el último vértice cierre el círculo
		batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": vertices})
		shader.bind()
		shader.uniform_float("color", color)
		batch.draw(shader)

	def world_to_screen(self, context, coord, size):
		region = context.region
		rv3d = context.space_data.region_3d
		coord_2d = bpy_extras.view3d_utils.location_3d_to_region_2d(region, rv3d, coord)
		if coord_2d is not None:
			return coord_2d.x * size / region.width, coord_2d.y * size / region.height
		return None

# Función para mostrar el diálogo de advertencia
def show_missing_attributes_dialog(self, context):
	def draw(self, context):
		self.layout.label(text="It is necessary to disable 'Improve performance' for export.")
	bpy.context.window_manager.popup_menu(draw, title="Advertencia", icon='ERROR')

# Función para mostrar el diálogo de advertencia cuando no hay scanners
def show_no_scanners_dialog(self, context):
	def draw(self, context):
		self.layout.label(text="No scanners generated in the scene.")
	bpy.context.window_manager.popup_menu(draw, title="Advertencia", icon='ERROR')

# Mantiene un registro de la posición anterior del objeto para detectar cambios
previous_location = {}

def update_height_on_move(scene, depsgraph):
	global previous_location
	global recursion_guard
	if recursion_guard:
		return
	recursion_guard = True
	try:
		# Elige el objeto con el modificador Geometry Nodes
		obj = bpy.context.active_object

		if obj and "scanner" in obj.name.lower() and obj.modifiers.get("GeometryNodes"):
			# Obtén la posición actual
			current_location = obj.location.copy()

			# Comprueba si la posición ha cambiado
			if obj.name not in previous_location:
				previous_location[obj.name] = current_location

			if current_location != previous_location[obj.name]:
				# Actualiza la posición registrada
				previous_location[obj.name] = current_location
			else:
				# Ejecuta el operador para actualizar el valor
				bpy.ops.object.show_float_value()
	finally:
		recursion_guard = False

# Función para crear el objeto scanner con Geometry Nodes
def create_scanner_base():
	mesh = bpy.data.meshes.new(name="ScannerMesh")
	scanner_object = bpy.data.objects.new("scanner", mesh)
	bpy.context.collection.objects.link(scanner_object)
	points_material = get_or_create_points_material()
	
	#initialize setposition_026 node group
	def setposition_026_node_group():
		setposition_026 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "SetPosition.026")

		setposition_026.color_tag = 'NONE'
		setposition_026.description = ""

		
		#setposition_026 interface
		#initialize setposition_026 nodes
		#node Group Input
		group_input = setposition_026.nodes.new("NodeGroupInput")
		group_input.name = "Group Input"
		#Socket Geometry
		geometry_socket = setposition_026.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket.attribute_domain = 'POINT'
		
		#Socket Geometry
		geometry_socket_1 = setposition_026.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_1.attribute_domain = 'POINT'
		
		#Socket Selection
		selection_socket = setposition_026.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
		selection_socket.default_value = True
		selection_socket.attribute_domain = 'POINT'
		selection_socket.hide_value = True
		
		#Socket Position
		position_socket = setposition_026.interface.new_socket(name = "Position", in_out='INPUT', socket_type = 'NodeSocketVector')
		position_socket.default_value = (0.0, 0.0, 0.0)
		position_socket.min_value = -3.4028234663852886e+38
		position_socket.max_value = 3.4028234663852886e+38
		position_socket.subtype = 'NONE'
		position_socket.attribute_domain = 'POINT'
		position_socket.hide_value = True
		
		#Socket Normal
		normal_socket = setposition_026.interface.new_socket(name = "Normal", in_out='INPUT', socket_type = 'NodeSocketVector')
		normal_socket.default_value = (0.0, 0.0, 0.0)
		normal_socket.min_value = -10000.0
		normal_socket.max_value = 10000.0
		normal_socket.subtype = 'NONE'
		normal_socket.attribute_domain = 'POINT'
		
		#Socket Hit distance
		hit_distance_socket = setposition_026.interface.new_socket(name = "Hit distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
		hit_distance_socket.default_value = 0.5
		hit_distance_socket.min_value = -10000.0
		hit_distance_socket.max_value = 10000.0
		hit_distance_socket.subtype = 'NONE'
		hit_distance_socket.attribute_domain = 'POINT'
		
		#Socket Noise
		noise_socket = setposition_026.interface.new_socket(name = "Noise", in_out='INPUT', socket_type = 'NodeSocketMenu')
		noise_socket.attribute_domain = 'POINT'
		#node Menu Switch
		menu_switch = setposition_026.nodes.new("GeometryNodeMenuSwitch")
		menu_switch.name = "Menu Switch"
		menu_switch.active_index = 1
		menu_switch.data_type = 'VECTOR'
		menu_switch.enum_items.clear()
		menu_switch.enum_items.new("Noise-normal")
		menu_switch.enum_items[0].description = ""
		menu_switch.enum_items.new("Noise-sphere")
		menu_switch.enum_items[1].description = ""
		  #group_input.Noise -> menu_switch.Menu
		setposition_026.links.new(group_input.outputs[5], menu_switch.inputs[0])
		noise_socket.default_value = "Noise-normal"
		
		#Socket Noise@1m
		noise_1m_socket = setposition_026.interface.new_socket(name = "Noise@1m", in_out='INPUT', socket_type = 'NodeSocketFloat')
		noise_1m_socket.default_value = 0.0
		noise_1m_socket.min_value = -10000.0
		noise_1m_socket.max_value = 10000.0
		noise_1m_socket.subtype = 'NONE'
		noise_1m_socket.attribute_domain = 'POINT'
		
		#Socket Radius
		radius_socket = setposition_026.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
		radius_socket.default_value = 0.0
		radius_socket.min_value = -3.4028234663852886e+38
		radius_socket.max_value = 3.4028234663852886e+38
		radius_socket.subtype = 'NONE'
		radius_socket.attribute_domain = 'POINT'
		
		#Socket Seed
		seed_socket = setposition_026.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
		seed_socket.default_value = 0
		seed_socket.min_value = -2147483648
		seed_socket.max_value = 2147483647
		seed_socket.subtype = 'NONE'
		seed_socket.attribute_domain = 'POINT'
		
		#Socket Distance - factor
		distance___factor_socket = setposition_026.interface.new_socket(name = "Distance - factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
		distance___factor_socket.default_value = 0.0
		distance___factor_socket.min_value = -3.4028234663852886e+38
		distance___factor_socket.max_value = 3.4028234663852886e+38
		distance___factor_socket.subtype = 'NONE'
		distance___factor_socket.attribute_domain = 'POINT'
		
		#Socket Reference
		reference_socket = setposition_026.interface.new_socket(name = "Reference", in_out='INPUT', socket_type = 'NodeSocketMenu')
		reference_socket.attribute_domain = 'POINT'
		 #node Menu Switch.001
		menu_switch_001 = setposition_026.nodes.new("GeometryNodeMenuSwitch")
		menu_switch_001.name = "Menu Switch.001"
		menu_switch_001.active_index = 1
		menu_switch_001.data_type = 'VECTOR'
		menu_switch_001.enum_items.clear()
		menu_switch_001.enum_items.new("Global")
		menu_switch_001.enum_items[0].description = ""
		menu_switch_001.enum_items.new("Relative to normal")
		menu_switch_001.enum_items[1].description = ""	
		
		#group_input.Reference -> menu_switch_001.Menu
		setposition_026.links.new(group_input.outputs[10], menu_switch_001.inputs[0])	
		
		reference_socket.default_value = "Global"
		
		#Socket XYZ - factors
		xyz___factors_socket = setposition_026.interface.new_socket(name = "XYZ - factors", in_out='INPUT', socket_type = 'NodeSocketVector')
		xyz___factors_socket.default_value = (0.0, 0.0, 0.0)
		xyz___factors_socket.min_value = -3.4028234663852886e+38
		xyz___factors_socket.max_value = 3.4028234663852886e+38
		xyz___factors_socket.subtype = 'NONE'
		xyz___factors_socket.attribute_domain = 'POINT'
		
		

		

		
		#node Group Output
		group_output = setposition_026.nodes.new("NodeGroupOutput")
		group_output.name = "Group Output"
		group_output.is_active_output = True
		
		#node Vector Math
		vector_math = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math.name = "Vector Math"
		vector_math.operation = 'MULTIPLY'
		
		#node Math.003
		math_003 = setposition_026.nodes.new("ShaderNodeMath")
		math_003.name = "Math.003"
		math_003.operation = 'MULTIPLY'
		math_003.use_clamp = False
		
		#node Set Position
		set_position = setposition_026.nodes.new("GeometryNodeSetPosition")
		set_position.name = "Set Position"
		
		#node Math.002
		math_002 = setposition_026.nodes.new("ShaderNodeMath")
		math_002.name = "Math.002"
		math_002.operation = 'MULTIPLY'
		math_002.use_clamp = False
		
		#node Math.001
		math_001 = setposition_026.nodes.new("ShaderNodeMath")
		math_001.name = "Math.001"
		math_001.operation = 'SUBTRACT'
		math_001.use_clamp = False
		#Value_001
		math_001.inputs[1].default_value = 0.5
		
		#node White Noise Texture
		white_noise_texture = setposition_026.nodes.new("ShaderNodeTexWhiteNoise")
		white_noise_texture.name = "White Noise Texture"
		white_noise_texture.noise_dimensions = '3D'
		#Vector
		white_noise_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
		
		#node Reroute
		reroute = setposition_026.nodes.new("NodeReroute")
		reroute.name = "Reroute"
		#node Reroute.001
		reroute_001 = setposition_026.nodes.new("NodeReroute")
		reroute_001.name = "Reroute.001"
		#node Reroute.002
		reroute_002 = setposition_026.nodes.new("NodeReroute")
		reroute_002.name = "Reroute.002"
		#node Frame
		frame = setposition_026.nodes.new("NodeFrame")
		frame.label = "NOISE"
		frame.name = "Frame"
		frame.label_size = 33
		frame.shrink = False
		
		#node Random Value
		random_value = setposition_026.nodes.new("FunctionNodeRandomValue")
		random_value.name = "Random Value"
		random_value.data_type = 'FLOAT_VECTOR'
		#ID
		random_value.inputs[7].default_value = 0
		
		#node Math.004
		math_004 = setposition_026.nodes.new("ShaderNodeMath")
		math_004.name = "Math.004"
		math_004.operation = 'MULTIPLY'
		math_004.use_clamp = False
		#Value_001
		math_004.inputs[1].default_value = -1.0
		
		#node Vector Math.001
		vector_math_001 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_001.name = "Vector Math.001"
		vector_math_001.operation = 'MULTIPLY'
		
		#node Vector Math.002
		vector_math_002 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_002.name = "Vector Math.002"
		vector_math_002.operation = 'SCALE'
		
		#node Vector Math.004
		vector_math_004 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_004.name = "Vector Math.004"
		vector_math_004.operation = 'CROSS_PRODUCT'
		
		#node Vector
		vector = setposition_026.nodes.new("FunctionNodeInputVector")
		vector.name = "Vector"
		vector.vector = (0.0, 0.0, 1.0)
		
		#node Vector Math.005
		vector_math_005 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_005.name = "Vector Math.005"
		vector_math_005.operation = 'CROSS_PRODUCT'
		

		
		#node Vector Math.016
		vector_math_016 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_016.name = "Vector Math.016"
		vector_math_016.operation = 'SCALE'
		
		#node Separate XYZ
		separate_xyz = setposition_026.nodes.new("ShaderNodeSeparateXYZ")
		separate_xyz.name = "Separate XYZ"
		
		#node Math.005
		math_005 = setposition_026.nodes.new("ShaderNodeMath")
		math_005.name = "Math.005"
		math_005.operation = 'MULTIPLY'
		math_005.use_clamp = False
		
		#node Math.006
		math_006 = setposition_026.nodes.new("ShaderNodeMath")
		math_006.name = "Math.006"
		math_006.operation = 'MULTIPLY'
		math_006.use_clamp = False
		
		#node Vector Math.017
		vector_math_017 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_017.name = "Vector Math.017"
		vector_math_017.operation = 'SCALE'
		
		#node Vector Math.003
		vector_math_003 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_003.name = "Vector Math.003"
		vector_math_003.operation = 'ADD'
		
		#node Math.007
		math_007 = setposition_026.nodes.new("ShaderNodeMath")
		math_007.name = "Math.007"
		math_007.operation = 'MULTIPLY'
		math_007.use_clamp = False
		
		#node Vector Math.018
		vector_math_018 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_018.name = "Vector Math.018"
		vector_math_018.operation = 'SCALE'
		
		#node Vector Math.006
		vector_math_006 = setposition_026.nodes.new("ShaderNodeVectorMath")
		vector_math_006.name = "Vector Math.006"
		vector_math_006.operation = 'ADD'
		
		#node Reroute.003
		reroute_003 = setposition_026.nodes.new("NodeReroute")
		reroute_003.name = "Reroute.003"
		#node Reroute.005
		reroute_005 = setposition_026.nodes.new("NodeReroute")
		reroute_005.name = "Reroute.005"
		
		
		#Set parents
		math_003.parent = frame
		math_002.parent = frame
		math_001.parent = frame
		white_noise_texture.parent = frame
		random_value.parent = frame
		math_004.parent = frame
		vector_math_001.parent = frame
		vector_math_002.parent = frame
		vector_math_004.parent = frame
		vector.parent = frame
		vector_math_005.parent = frame
		vector_math_016.parent = frame
		separate_xyz.parent = frame
		math_005.parent = frame
		math_006.parent = frame
		vector_math_017.parent = frame
		vector_math_003.parent = frame
		math_007.parent = frame
		vector_math_018.parent = frame
		vector_math_006.parent = frame
		reroute_003.parent = frame
		reroute_005.parent = frame
		
		#Set locations
		group_input.location = (-1734.4599609375, 235.5206298828125)
		menu_switch.location = (671.6766357421875, 214.4803009033203)
		group_output.location = (1015.8095703125, 321.52337646484375)
		vector_math.location = (-148.5823974609375, -29.1820068359375)
		math_003.location = (-281.9494323730469, 1023.4475708007812)
		set_position.location = (835.5911254882812, 325.94873046875)
		math_002.location = (-565.93798828125, 1018.1827392578125)
		math_001.location = (-761.5870361328125, 990.7195434570312)
		white_noise_texture.location = (-924.1334228515625, 1022.7271728515625)
		reroute.location = (-1119.2037353515625, 70.6515121459961)
		reroute_001.location = (-1064.421875, 121.00209045410156)
		reroute_002.location = (-522.5672607421875, 164.37095642089844)
		frame.location = (-484.440185546875, -1152.54638671875)
		random_value.location = (-808.163330078125, 616.9609375)
		math_004.location = (-1024.8990478515625, 507.53924560546875)
		vector_math_001.location = (-283.9027099609375, 833.734619140625)
		vector_math_002.location = (-792.528076171875, 789.5090942382812)
		vector_math_004.location = (88.78729248046875, 385.71820068359375)
		vector.location = (-139.25396728515625, 275.78271484375)
		vector_math_005.location = (439.5340576171875, 290.01318359375)
		menu_switch_001.location = (514.4254760742188, 74.26632690429688)
		vector_math_016.location = (64.52206420898438, 742.6491088867188)
		separate_xyz.location = (-589.138427734375, 358.4012451171875)
		math_005.location = (-274.8441162109375, 639.25)
		math_006.location = (-150.9132080078125, 441.1480712890625)
		vector_math_017.location = (324.9874267578125, 510.94549560546875)
		vector_math_003.location = (506.15069580078125, 772.8284912109375)
		math_007.location = (-299.88177490234375, 179.16864013671875)
		vector_math_018.location = (624.1331787109375, 249.96075439453125)
		vector_math_006.location = (833.0782470703125, 813.2300415039062)
		reroute_003.location = (-532.9037475585938, 546.9356689453125)
		reroute_005.location = (-59.125732421875, 674.2069091796875)
		
		#Set dimensions
		group_input.width, group_input.height = 140.0, 100.0
		menu_switch.width, menu_switch.height = 140.0, 100.0
		group_output.width, group_output.height = 140.0, 100.0
		vector_math.width, vector_math.height = 140.0, 100.0
		math_003.width, math_003.height = 140.0, 100.0
		set_position.width, set_position.height = 140.0, 100.0
		math_002.width, math_002.height = 140.0, 100.0
		math_001.width, math_001.height = 140.0, 100.0
		white_noise_texture.width, white_noise_texture.height = 140.0, 100.0
		reroute.width, reroute.height = 16.0, 100.0
		reroute_001.width, reroute_001.height = 16.0, 100.0
		reroute_002.width, reroute_002.height = 16.0, 100.0
		frame.width, frame.height = 2306.0087890625, 1294.10205078125
		random_value.width, random_value.height = 140.0, 100.0
		math_004.width, math_004.height = 140.0, 100.0
		vector_math_001.width, vector_math_001.height = 140.0, 100.0
		vector_math_002.width, vector_math_002.height = 140.0, 100.0
		vector_math_004.width, vector_math_004.height = 140.0, 100.0
		vector.width, vector.height = 140.0, 100.0
		vector_math_005.width, vector_math_005.height = 140.0, 100.0
		menu_switch_001.width, menu_switch_001.height = 140.0, 100.0
		vector_math_016.width, vector_math_016.height = 140.0, 100.0
		separate_xyz.width, separate_xyz.height = 140.0, 100.0
		math_005.width, math_005.height = 140.0, 100.0
		math_006.width, math_006.height = 140.0, 100.0
		vector_math_017.width, vector_math_017.height = 140.0, 100.0
		vector_math_003.width, vector_math_003.height = 140.0, 100.0
		math_007.width, math_007.height = 140.0, 100.0
		vector_math_018.width, vector_math_018.height = 140.0, 100.0
		vector_math_006.width, vector_math_006.height = 140.0, 100.0
		reroute_003.width, reroute_003.height = 16.0, 100.0
		reroute_005.width, reroute_005.height = 16.0, 100.0
		
		#initialize setposition_026 links
		#math_003.Value -> vector_math.Vector
		setposition_026.links.new(math_003.outputs[0], vector_math.inputs[1])
		#group_input.Geometry -> set_position.Geometry
		setposition_026.links.new(group_input.outputs[0], set_position.inputs[0])
		#reroute_002.Output -> vector_math.Vector
		setposition_026.links.new(reroute_002.outputs[0], vector_math.inputs[0])
		#reroute_001.Output -> math_003.Value
		setposition_026.links.new(reroute_001.outputs[0], math_003.inputs[0])
		#group_input.Position -> set_position.Position
		setposition_026.links.new(group_input.outputs[2], set_position.inputs[2])
		#set_position.Geometry -> group_output.Geometry
		setposition_026.links.new(set_position.outputs[0], group_output.inputs[0])
		#white_noise_texture.Value -> math_001.Value
		setposition_026.links.new(white_noise_texture.outputs[0], math_001.inputs[0])
		#math_002.Value -> math_003.Value
		setposition_026.links.new(math_002.outputs[0], math_003.inputs[1])
		#reroute.Output -> math_002.Value
		setposition_026.links.new(reroute.outputs[0], math_002.inputs[0])
		#math_001.Value -> math_002.Value
		setposition_026.links.new(math_001.outputs[0], math_002.inputs[1])
		#group_input.Selection -> set_position.Selection
		setposition_026.links.new(group_input.outputs[1], set_position.inputs[1])
		#group_input.Noise@1m -> reroute.Input
		setposition_026.links.new(group_input.outputs[6], reroute.inputs[0])
		#group_input.Hit distance -> reroute_001.Input
		setposition_026.links.new(group_input.outputs[4], reroute_001.inputs[0])
		#group_input.Normal -> reroute_002.Input
		setposition_026.links.new(group_input.outputs[3], reroute_002.inputs[0])
		#math_004.Value -> random_value.Min
		setposition_026.links.new(math_004.outputs[0], random_value.inputs[2])
		#math_004.Value -> random_value.Min
		setposition_026.links.new(math_004.outputs[0], random_value.inputs[0])
		#vector_math.Vector -> menu_switch.Noise-normal
		setposition_026.links.new(vector_math.outputs[0], menu_switch.inputs[1])
		#menu_switch.Output -> set_position.Offset
		setposition_026.links.new(menu_switch.outputs[0], set_position.inputs[3])
		#vector_math_002.Vector -> vector_math_001.Vector
		setposition_026.links.new(vector_math_002.outputs[0], vector_math_001.inputs[0])
		#group_input.XYZ - factors -> vector_math_002.Vector
		setposition_026.links.new(group_input.outputs[11], vector_math_002.inputs[0])
		#group_input.Radius -> math_004.Value
		setposition_026.links.new(group_input.outputs[7], math_004.inputs[0])
		#group_input.Radius -> random_value.Max
		setposition_026.links.new(group_input.outputs[7], random_value.inputs[1])
		#vector.Vector -> vector_math_004.Vector
		setposition_026.links.new(vector.outputs[0], vector_math_004.inputs[0])
		#vector_math_001.Vector -> menu_switch_001.Global
		setposition_026.links.new(vector_math_001.outputs[0], menu_switch_001.inputs[1])
		#menu_switch_001.Output -> menu_switch.Noise-sphere
		setposition_026.links.new(menu_switch_001.outputs[0], menu_switch.inputs[2])

		#math_005.Value -> vector_math_016.Scale
		setposition_026.links.new(math_005.outputs[0], vector_math_016.inputs[3])
		#separate_xyz.X -> math_005.Value
		setposition_026.links.new(separate_xyz.outputs[0], math_005.inputs[1])
		#vector_math_016.Vector -> vector_math_003.Vector
		setposition_026.links.new(vector_math_016.outputs[0], vector_math_003.inputs[0])
		#separate_xyz.Y -> math_006.Value
		setposition_026.links.new(separate_xyz.outputs[1], math_006.inputs[1])
		#math_006.Value -> vector_math_017.Scale
		setposition_026.links.new(math_006.outputs[0], vector_math_017.inputs[3])
		#vector_math_004.Vector -> vector_math_017.Vector
		setposition_026.links.new(vector_math_004.outputs[0], vector_math_017.inputs[0])
		#vector_math_017.Vector -> vector_math_003.Vector
		setposition_026.links.new(vector_math_017.outputs[0], vector_math_003.inputs[1])
		#vector_math_004.Vector -> vector_math_005.Vector
		setposition_026.links.new(vector_math_004.outputs[0], vector_math_005.inputs[1])
		#vector_math_005.Vector -> vector_math_018.Vector
		setposition_026.links.new(vector_math_005.outputs[0], vector_math_018.inputs[0])
		#math_007.Value -> vector_math_018.Scale
		setposition_026.links.new(math_007.outputs[0], vector_math_018.inputs[3])
		#separate_xyz.Z -> math_007.Value
		setposition_026.links.new(separate_xyz.outputs[2], math_007.inputs[1])
		#vector_math_003.Vector -> vector_math_006.Vector
		setposition_026.links.new(vector_math_003.outputs[0], vector_math_006.inputs[0])
		#vector_math_018.Vector -> vector_math_006.Vector
		setposition_026.links.new(vector_math_018.outputs[0], vector_math_006.inputs[1])
		#vector_math_002.Vector -> separate_xyz.Vector
		setposition_026.links.new(vector_math_002.outputs[0], separate_xyz.inputs[0])
		#reroute_005.Output -> vector_math_016.Vector
		setposition_026.links.new(reroute_005.outputs[0], vector_math_016.inputs[0])
		#reroute_002.Output -> vector_math_005.Vector
		setposition_026.links.new(reroute_002.outputs[0], vector_math_005.inputs[0])
		#group_input.Seed -> random_value.Seed
		setposition_026.links.new(group_input.outputs[8], random_value.inputs[8])
		#group_input.Distance - factor -> vector_math_002.Scale
		setposition_026.links.new(group_input.outputs[9], vector_math_002.inputs[3])
		#reroute_003.Output -> math_005.Value
		setposition_026.links.new(reroute_003.outputs[0], math_005.inputs[0])
		#random_value.Value -> reroute_003.Input
		setposition_026.links.new(random_value.outputs[0], reroute_003.inputs[0])
		#reroute_003.Output -> math_006.Value
		setposition_026.links.new(reroute_003.outputs[0], math_006.inputs[0])
		#reroute_003.Output -> math_007.Value
		setposition_026.links.new(reroute_003.outputs[0], math_007.inputs[0])
		#reroute_003.Output -> vector_math_001.Vector
		setposition_026.links.new(reroute_003.outputs[0], vector_math_001.inputs[1])
		#reroute_002.Output -> reroute_005.Input
		setposition_026.links.new(reroute_002.outputs[0], reroute_005.inputs[0])
		#reroute_005.Output -> vector_math_004.Vector
		setposition_026.links.new(reroute_005.outputs[0], vector_math_004.inputs[1])

		#vector_math_006.Vector -> menu_switch_001.Relative to normal
		setposition_026.links.new(vector_math_006.outputs[0], menu_switch_001.inputs[2])
		return setposition_026

	setposition_026 = setposition_026_node_group()

	#initialize sphere_scanner_019 node group
	def sphere_scanner_019_node_group():
		sphere_scanner_019 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Sphere scanner.019")

		sphere_scanner_019.color_tag = 'GEOMETRY'
		sphere_scanner_019.description = ""

		
		#sphere_scanner_019 interface
		#Socket Mesh
		mesh_socket = sphere_scanner_019.interface.new_socket(name = "Mesh", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		mesh_socket.attribute_domain = 'POINT'
		
		#Socket Angle
		angle_socket = sphere_scanner_019.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
		angle_socket.default_value = 0.0
		angle_socket.min_value = -3.4028234663852886e+38
		angle_socket.max_value = 3.4028234663852886e+38
		angle_socket.subtype = 'NONE'
		angle_socket.attribute_domain = 'POINT'
		
		
		#initialize sphere_scanner_019 nodes
		#node Group Output
		group_output_1 = sphere_scanner_019.nodes.new("NodeGroupOutput")
		group_output_1.name = "Group Output"
		group_output_1.is_active_output = True
		
		#node Group Input
		group_input_1 = sphere_scanner_019.nodes.new("NodeGroupInput")
		group_input_1.name = "Group Input"
		
		#node UV Sphere
		uv_sphere = sphere_scanner_019.nodes.new("GeometryNodeMeshUVSphere")
		uv_sphere.name = "UV Sphere"
		#Radius
		uv_sphere.inputs[2].default_value = 9.999999747378752e-06
		
		#node Math
		math = sphere_scanner_019.nodes.new("ShaderNodeMath")
		math.name = "Math"
		math.operation = 'DIVIDE'
		math.use_clamp = False
		#Value
		math.inputs[0].default_value = 360.0
		
		#node Math.006
		math_006_1 = sphere_scanner_019.nodes.new("ShaderNodeMath")
		math_006_1.name = "Math.006"
		math_006_1.operation = 'MULTIPLY'
		math_006_1.use_clamp = False
		#Value
		math_006_1.inputs[0].default_value = 2.0
		
		
		
		
		#Set locations
		group_output_1.location = (118.6519546508789, 35.24913787841797)
		group_input_1.location = (-557.705078125, -130.9492950439453)
		uv_sphere.location = (-52.502540588378906, 35.205318450927734)
		math.location = (-383.7773132324219, -34.77288818359375)
		math_006_1.location = (-215.20779418945312, 108.5316390991211)
		
		#Set dimensions
		group_output_1.width, group_output_1.height = 140.0, 100.0
		group_input_1.width, group_input_1.height = 140.0, 100.0
		uv_sphere.width, uv_sphere.height = 140.0, 100.0
		math.width, math.height = 140.0, 100.0
		math_006_1.width, math_006_1.height = 140.0, 100.0
		
		#initialize sphere_scanner_019 links
		#math.Value -> math_006_1.Value
		sphere_scanner_019.links.new(math.outputs[0], math_006_1.inputs[1])
		#math.Value -> uv_sphere.Rings
		sphere_scanner_019.links.new(math.outputs[0], uv_sphere.inputs[1])
		#group_input_1.Angle -> math.Value
		sphere_scanner_019.links.new(group_input_1.outputs[0], math.inputs[1])
		#uv_sphere.Mesh -> group_output_1.Mesh
		sphere_scanner_019.links.new(uv_sphere.outputs[0], group_output_1.inputs[0])
		#math_006_1.Value -> uv_sphere.Segments
		sphere_scanner_019.links.new(math_006_1.outputs[0], uv_sphere.inputs[0])
		return sphere_scanner_019

	sphere_scanner_019 = sphere_scanner_019_node_group()

	#initialize points_deletion_019 node group
	def points_deletion_019_node_group():
		points_deletion_019 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Points deletion.019")

		points_deletion_019.color_tag = 'GEOMETRY'
		points_deletion_019.description = ""

		
		#points_deletion_019 interface
		#Socket Geometry
		geometry_socket_2 = points_deletion_019.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_2.attribute_domain = 'POINT'
		
		#Socket Geometry
		geometry_socket_3 = points_deletion_019.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_3.attribute_domain = 'POINT'
		
		#Socket Angle
		angle_socket_1 = points_deletion_019.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
		angle_socket_1.default_value = 0.0
		angle_socket_1.min_value = -3.4028234663852886e+38
		angle_socket_1.max_value = 3.4028234663852886e+38
		angle_socket_1.subtype = 'NONE'
		angle_socket_1.attribute_domain = 'POINT'
		
		#Socket Vector
		vector_socket = points_deletion_019.interface.new_socket(name = "Vector", in_out='INPUT', socket_type = 'NodeSocketVector')
		vector_socket.default_value = (0.0, 0.0, 0.0)
		vector_socket.min_value = -10000.0
		vector_socket.max_value = 10000.0
		vector_socket.subtype = 'NONE'
		vector_socket.attribute_domain = 'POINT'
		
		#Socket Selection
		selection_socket_1 = points_deletion_019.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
		selection_socket_1.default_value = False
		selection_socket_1.attribute_domain = 'POINT'
		
		
		#initialize points_deletion_019 nodes
		#node Group Output
		group_output_2 = points_deletion_019.nodes.new("NodeGroupOutput")
		group_output_2.name = "Group Output"
		group_output_2.is_active_output = True
		
		#node Group Input
		group_input_2 = points_deletion_019.nodes.new("NodeGroupInput")
		group_input_2.name = "Group Input"
		
		#node Boolean Math
		boolean_math = points_deletion_019.nodes.new("FunctionNodeBooleanMath")
		boolean_math.name = "Boolean Math"
		boolean_math.operation = 'NOT'
		
		#node Vector Math.001
		vector_math_001_1 = points_deletion_019.nodes.new("ShaderNodeVectorMath")
		vector_math_001_1.name = "Vector Math.001"
		vector_math_001_1.operation = 'DOT_PRODUCT'
		#Vector_001
		vector_math_001_1.inputs[1].default_value = (0.0, 0.0, -1.0)
		
		#node Math.004
		math_004_1 = points_deletion_019.nodes.new("ShaderNodeMath")
		math_004_1.name = "Math.004"
		math_004_1.operation = 'GREATER_THAN'
		math_004_1.use_clamp = False
		
		#node Delete Geometry.001
		delete_geometry_001 = points_deletion_019.nodes.new("GeometryNodeDeleteGeometry")
		delete_geometry_001.name = "Delete Geometry.001"
		delete_geometry_001.domain = 'POINT'
		delete_geometry_001.mode = 'ALL'
		
		#node Delete Geometry
		delete_geometry = points_deletion_019.nodes.new("GeometryNodeDeleteGeometry")
		delete_geometry.name = "Delete Geometry"
		delete_geometry.domain = 'POINT'
		delete_geometry.mode = 'ALL'
		
		#node Frame
		frame_1 = points_deletion_019.nodes.new("NodeFrame")
		frame_1.label = "Delete non projected points"
		frame_1.name = "Frame"
		frame_1.label_size = 29
		frame_1.shrink = False
		
		#node Frame.002
		frame_002 = points_deletion_019.nodes.new("NodeFrame")
		frame_002.label = "Delete the points under the scanner"
		frame_002.name = "Frame.002"
		frame_002.label_size = 33
		frame_002.shrink = False
		
		#node Math
		math_1 = points_deletion_019.nodes.new("ShaderNodeMath")
		math_1.name = "Math"
		math_1.operation = 'COSINE'
		math_1.use_clamp = False
		
		#node Reroute
		reroute_1 = points_deletion_019.nodes.new("NodeReroute")
		reroute_1.name = "Reroute"
		
		
		#Set parents
		boolean_math.parent = frame_1
		vector_math_001_1.parent = frame_002
		math_004_1.parent = frame_002
		delete_geometry_001.parent = frame_002
		delete_geometry.parent = frame_1
		math_1.parent = frame_002
		reroute_1.parent = frame_002
		
		#Set locations
		group_output_2.location = (417.92071533203125, 157.53695678710938)
		group_input_2.location = (-752.72412109375, 64.44601440429688)
		boolean_math.location = (-193.17349243164062, -158.7728271484375)
		vector_math_001_1.location = (-10.69775390625, -304.3811950683594)
		math_004_1.location = (162.47406005859375, -385.123046875)
		delete_geometry_001.location = (265.5213928222656, -106.96450805664062)
		delete_geometry.location = (-4.1249542236328125, -66.13664245605469)
		frame_1.location = (232.30642700195312, 223.5938262939453)
		frame_002.location = (-497.8685302734375, 273.25750732421875)
		math_1.location = (-7.5352783203125, -511.3177185058594)
		reroute_1.location = (-8.61358642578125, -296.04931640625)
		
		#Set dimensions
		group_output_2.width, group_output_2.height = 140.0, 100.0
		group_input_2.width, group_input_2.height = 140.0, 100.0
		boolean_math.width, boolean_math.height = 140.0, 100.0
		vector_math_001_1.width, vector_math_001_1.height = 140.0, 100.0
		math_004_1.width, math_004_1.height = 140.0, 100.0
		delete_geometry_001.width, delete_geometry_001.height = 140.0, 100.0
		delete_geometry.width, delete_geometry.height = 140.0, 100.0
		frame_1.width, frame_1.height = 409.90423583984375, 342.527099609375
		frame_002.width, frame_002.height = 556.368896484375, 617.1976928710938
		math_1.width, math_1.height = 140.0, 100.0
		reroute_1.width, reroute_1.height = 100.0, 100.0
		
		#initialize points_deletion_019 links
		#math_004_1.Value -> delete_geometry_001.Selection
		points_deletion_019.links.new(math_004_1.outputs[0], delete_geometry_001.inputs[1])
		#vector_math_001_1.Value -> math_004_1.Value
		points_deletion_019.links.new(vector_math_001_1.outputs[1], math_004_1.inputs[0])
		#boolean_math.Boolean -> delete_geometry.Selection
		points_deletion_019.links.new(boolean_math.outputs[0], delete_geometry.inputs[1])
		#group_input_2.Vector -> vector_math_001_1.Vector
		points_deletion_019.links.new(group_input_2.outputs[2], vector_math_001_1.inputs[0])
		#group_input_2.Angle -> math_1.Value
		points_deletion_019.links.new(group_input_2.outputs[1], math_1.inputs[0])
		#math_1.Value -> math_004_1.Value
		points_deletion_019.links.new(math_1.outputs[0], math_004_1.inputs[1])
		#group_input_2.Selection -> reroute_1.Input
		points_deletion_019.links.new(group_input_2.outputs[3], reroute_1.inputs[0])
		#reroute_1.Output -> boolean_math.Boolean
		points_deletion_019.links.new(reroute_1.outputs[0], boolean_math.inputs[0])
		#group_input_2.Geometry -> delete_geometry_001.Geometry
		points_deletion_019.links.new(group_input_2.outputs[0], delete_geometry_001.inputs[0])
		#delete_geometry_001.Geometry -> delete_geometry.Geometry
		points_deletion_019.links.new(delete_geometry_001.outputs[0], delete_geometry.inputs[0])
		#delete_geometry.Geometry -> group_output_2.Geometry
		points_deletion_019.links.new(delete_geometry.outputs[0], group_output_2.inputs[0])
		return points_deletion_019

	points_deletion_019 = points_deletion_019_node_group()

	#initialize scanner_device_020 node group
	def scanner_device_020_node_group():
		scanner_device_020 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Scanner_device.020")

		scanner_device_020.color_tag = 'NONE'
		scanner_device_020.description = ""

		
		#scanner_device_020 interface
		#Socket Scanner_device
		scanner_device_socket = scanner_device_020.interface.new_socket(name = "Scanner_device", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		scanner_device_socket.attribute_domain = 'POINT'
		
		#Socket alfa
		alfa_socket = scanner_device_020.interface.new_socket(name = "alfa", in_out='INPUT', socket_type = 'NodeSocketFloat')
		alfa_socket.default_value = 0.5
		alfa_socket.min_value = -10000.0
		alfa_socket.max_value = 10000.0
		alfa_socket.subtype = 'NONE'
		alfa_socket.attribute_domain = 'POINT'
		
		#Socket height
		height_socket = scanner_device_020.interface.new_socket(name = "height", in_out='INPUT', socket_type = 'NodeSocketFloat')
		height_socket.default_value = -1.0
		height_socket.min_value = -10000.0
		height_socket.max_value = 10000.0
		height_socket.subtype = 'NONE'
		height_socket.attribute_domain = 'POINT'
		
		
		#initialize scanner_device_020 nodes
		#node Group Output
		group_output_3 = scanner_device_020.nodes.new("NodeGroupOutput")
		group_output_3.name = "Group Output"
		group_output_3.is_active_output = True
		
		#node Group Input
		group_input_3 = scanner_device_020.nodes.new("NodeGroupInput")
		group_input_3.name = "Group Input"
		
		#node Cube
		cube = scanner_device_020.nodes.new("GeometryNodeMeshCube")
		cube.name = "Cube"
		#Vertices X
		cube.inputs[1].default_value = 2
		#Vertices Y
		cube.inputs[2].default_value = 2
		#Vertices Z
		cube.inputs[3].default_value = 2
		
		#node Set Position.003
		set_position_003 = scanner_device_020.nodes.new("GeometryNodeSetPosition")
		set_position_003.name = "Set Position.003"
		#Selection
		set_position_003.inputs[1].default_value = True
		#Position
		set_position_003.inputs[2].default_value = (0.0, 0.0, 0.0)
		
		#node Combine XYZ.005
		combine_xyz_005 = scanner_device_020.nodes.new("ShaderNodeCombineXYZ")
		combine_xyz_005.name = "Combine XYZ.005"
		#X
		combine_xyz_005.inputs[0].default_value = 0.0
		#Y
		combine_xyz_005.inputs[1].default_value = 0.0
		
		#node Math.004
		math_004_2 = scanner_device_020.nodes.new("ShaderNodeMath")
		math_004_2.name = "Math.004"
		math_004_2.operation = 'COSINE'
		math_004_2.use_clamp = False
		
		#node Math.005
		math_005_1 = scanner_device_020.nodes.new("ShaderNodeMath")
		math_005_1.name = "Math.005"
		math_005_1.operation = 'MULTIPLY'
		math_005_1.use_clamp = False
		
		#node Math.006
		math_006_2 = scanner_device_020.nodes.new("ShaderNodeMath")
		math_006_2.name = "Math.006"
		math_006_2.operation = 'MULTIPLY'
		math_006_2.use_clamp = False
		#Value_001
		math_006_2.inputs[1].default_value = 0.15000000596046448
		
		#node Combine XYZ.006
		combine_xyz_006 = scanner_device_020.nodes.new("ShaderNodeCombineXYZ")
		combine_xyz_006.name = "Combine XYZ.006"
		
		#node Math.007
		math_007_1 = scanner_device_020.nodes.new("ShaderNodeMath")
		math_007_1.name = "Math.007"
		math_007_1.operation = 'MULTIPLY'
		math_007_1.use_clamp = False
		#Value_001
		math_007_1.inputs[1].default_value = 0.6579999923706055
		
		#node Math.008
		math_008 = scanner_device_020.nodes.new("ShaderNodeMath")
		math_008.name = "Math.008"
		math_008.operation = 'ADD'
		math_008.use_clamp = False
		
		#node Math.009
		math_009 = scanner_device_020.nodes.new("ShaderNodeMath")
		math_009.name = "Math.009"
		math_009.operation = 'MULTIPLY'
		math_009.use_clamp = False
		#Value_001
		math_009.inputs[1].default_value = 0.5
		
		
		
		
		#Set locations
		group_output_3.location = (918.3540649414062, 31.171894073486328)
		group_input_3.location = (-938.0803833007812, 19.482433319091797)
		cube.location = (187.68609619140625, -84.05833435058594)
		set_position_003.location = (726.4087524414062, 37.1970329284668)
		combine_xyz_005.location = (512.0537719726562, 198.73329162597656)
		math_004_2.location = (-738.0803833007812, 229.60768127441406)
		math_005_1.location = (-492.68414306640625, 234.99415588378906)
		math_006_2.location = (-618.3755493164062, -228.88182067871094)
		combine_xyz_006.location = (-36.512393951416016, -135.1771697998047)
		math_007_1.location = (-308.12762451171875, -241.10472106933594)
		math_008.location = (213.85992431640625, 280.0697021484375)
		math_009.location = (-40.213321685791016, 124.21070861816406)
		
		#Set dimensions
		group_output_3.width, group_output_3.height = 140.0, 100.0
		group_input_3.width, group_input_3.height = 140.0, 100.0
		cube.width, cube.height = 140.0, 100.0
		set_position_003.width, set_position_003.height = 140.0, 100.0
		combine_xyz_005.width, combine_xyz_005.height = 140.0, 100.0
		math_004_2.width, math_004_2.height = 140.0, 100.0
		math_005_1.width, math_005_1.height = 140.0, 100.0
		math_006_2.width, math_006_2.height = 140.0, 100.0
		combine_xyz_006.width, combine_xyz_006.height = 140.0, 100.0
		math_007_1.width, math_007_1.height = 140.0, 100.0
		math_008.width, math_008.height = 140.0, 100.0
		math_009.width, math_009.height = 140.0, 100.0
		
		#initialize scanner_device_020 links
		#math_006_2.Value -> combine_xyz_006.Z
		scanner_device_020.links.new(math_006_2.outputs[0], combine_xyz_006.inputs[2])
		#math_007_1.Value -> combine_xyz_006.Y
		scanner_device_020.links.new(math_007_1.outputs[0], combine_xyz_006.inputs[1])
		#math_005_1.Value -> math_008.Value
		scanner_device_020.links.new(math_005_1.outputs[0], math_008.inputs[0])
		#combine_xyz_006.Vector -> cube.Size
		scanner_device_020.links.new(combine_xyz_006.outputs[0], cube.inputs[0])
		#cube.Mesh -> set_position_003.Geometry
		scanner_device_020.links.new(cube.outputs[0], set_position_003.inputs[0])
		#combine_xyz_005.Vector -> set_position_003.Offset
		scanner_device_020.links.new(combine_xyz_005.outputs[0], set_position_003.inputs[3])
		#math_006_2.Value -> combine_xyz_006.X
		scanner_device_020.links.new(math_006_2.outputs[0], combine_xyz_006.inputs[0])
		#math_008.Value -> combine_xyz_005.Z
		scanner_device_020.links.new(math_008.outputs[0], combine_xyz_005.inputs[2])
		#math_006_2.Value -> math_009.Value
		scanner_device_020.links.new(math_006_2.outputs[0], math_009.inputs[0])
		#math_004_2.Value -> math_005_1.Value
		scanner_device_020.links.new(math_004_2.outputs[0], math_005_1.inputs[0])
		#math_009.Value -> math_008.Value
		scanner_device_020.links.new(math_009.outputs[0], math_008.inputs[1])
		#math_006_2.Value -> math_007_1.Value
		scanner_device_020.links.new(math_006_2.outputs[0], math_007_1.inputs[0])
		#group_input_3.alfa -> math_004_2.Value
		scanner_device_020.links.new(group_input_3.outputs[0], math_004_2.inputs[0])
		#group_input_3.height -> math_005_1.Value
		scanner_device_020.links.new(group_input_3.outputs[1], math_005_1.inputs[1])
		#group_input_3.height -> math_006_2.Value
		scanner_device_020.links.new(group_input_3.outputs[1], math_006_2.inputs[0])
		#set_position_003.Geometry -> group_output_3.Scanner_device
		scanner_device_020.links.new(set_position_003.outputs[0], group_output_3.inputs[0])
		return scanner_device_020

	scanner_device_020 = scanner_device_020_node_group()

	#initialize tripod_legs_020 node group
	def tripod_legs_020_node_group():
		tripod_legs_020 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Tripod_legs.020")

		tripod_legs_020.color_tag = 'NONE'
		tripod_legs_020.description = ""

		
		#tripod_legs_020 interface
		#Socket Leg 2
		leg_2_socket = tripod_legs_020.interface.new_socket(name = "Leg 2", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		leg_2_socket.attribute_domain = 'POINT'
		
		#Socket Leg 3
		leg_3_socket = tripod_legs_020.interface.new_socket(name = "Leg 3", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		leg_3_socket.attribute_domain = 'POINT'
		
		#Socket Base leg
		base_leg_socket = tripod_legs_020.interface.new_socket(name = "Base leg", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		base_leg_socket.attribute_domain = 'POINT'
		
		
		#initialize tripod_legs_020 nodes
		#node Group Output
		group_output_4 = tripod_legs_020.nodes.new("NodeGroupOutput")
		group_output_4.name = "Group Output"
		group_output_4.is_active_output = True
		
		#node Group Input
		group_input_4 = tripod_legs_020.nodes.new("NodeGroupInput")
		group_input_4.name = "Group Input"
		
		#node Duplicate Elements
		duplicate_elements = tripod_legs_020.nodes.new("GeometryNodeDuplicateElements")
		duplicate_elements.name = "Duplicate Elements"
		duplicate_elements.domain = 'INSTANCE'
		#Selection
		duplicate_elements.inputs[1].default_value = True
		#Amount
		duplicate_elements.inputs[2].default_value = 1
		
		#node Rotate Instances
		rotate_instances = tripod_legs_020.nodes.new("GeometryNodeRotateInstances")
		rotate_instances.name = "Rotate Instances"
		#Selection
		rotate_instances.inputs[1].default_value = True
		#Rotation
		rotate_instances.inputs[2].default_value = (0.0, 0.0, 2.094395160675049)
		#Pivot Point
		rotate_instances.inputs[3].default_value = (0.0, 0.0, 0.0)
		#Local Space
		rotate_instances.inputs[4].default_value = True
		
		#node Realize Instances
		realize_instances = tripod_legs_020.nodes.new("GeometryNodeRealizeInstances")
		realize_instances.name = "Realize Instances"
		#Selection
		realize_instances.inputs[1].default_value = True
		#Realize All
		realize_instances.inputs[2].default_value = True
		#Depth
		realize_instances.inputs[3].default_value = 0
		
		#node Geometry to Instance
		geometry_to_instance = tripod_legs_020.nodes.new("GeometryNodeGeometryToInstance")
		geometry_to_instance.name = "Geometry to Instance"
		
		#node Duplicate Elements.001
		duplicate_elements_001 = tripod_legs_020.nodes.new("GeometryNodeDuplicateElements")
		duplicate_elements_001.name = "Duplicate Elements.001"
		duplicate_elements_001.domain = 'INSTANCE'
		#Selection
		duplicate_elements_001.inputs[1].default_value = True
		#Amount
		duplicate_elements_001.inputs[2].default_value = 1
		
		#node Rotate Instances.001
		rotate_instances_001 = tripod_legs_020.nodes.new("GeometryNodeRotateInstances")
		rotate_instances_001.name = "Rotate Instances.001"
		#Selection
		rotate_instances_001.inputs[1].default_value = True
		#Rotation
		rotate_instances_001.inputs[2].default_value = (0.0, 0.0, 4.188790321350098)
		#Pivot Point
		rotate_instances_001.inputs[3].default_value = (0.0, 0.0, 0.0)
		#Local Space
		rotate_instances_001.inputs[4].default_value = True
		
		#node Realize Instances.001
		realize_instances_001 = tripod_legs_020.nodes.new("GeometryNodeRealizeInstances")
		realize_instances_001.name = "Realize Instances.001"
		#Selection
		realize_instances_001.inputs[1].default_value = True
		#Realize All
		realize_instances_001.inputs[2].default_value = True
		#Depth
		realize_instances_001.inputs[3].default_value = 0
		
		
		
		
		#Set locations
		group_output_4.location = (642.7841186523438, 44.30887985229492)
		group_input_4.location = (-547.0955810546875, -179.69712829589844)
		duplicate_elements.location = (7.261772155761719, 227.2937469482422)
		rotate_instances.location = (217.94598388671875, 249.5121612548828)
		realize_instances.location = (395.64813232421875, 257.35009765625)
		geometry_to_instance.location = (-275.817138671875, -185.96356201171875)
		duplicate_elements_001.location = (4.972343444824219, -105.44453430175781)
		rotate_instances_001.location = (219.89862060546875, -61.984134674072266)
		realize_instances_001.location = (452.78424072265625, -41.83817672729492)
		
		#Set dimensions
		group_output_4.width, group_output_4.height = 140.0, 100.0
		group_input_4.width, group_input_4.height = 140.0, 100.0
		duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
		rotate_instances.width, rotate_instances.height = 140.0, 100.0
		realize_instances.width, realize_instances.height = 140.0, 100.0
		geometry_to_instance.width, geometry_to_instance.height = 160.0, 100.0
		duplicate_elements_001.width, duplicate_elements_001.height = 140.0, 100.0
		rotate_instances_001.width, rotate_instances_001.height = 140.0, 100.0
		realize_instances_001.width, realize_instances_001.height = 140.0, 100.0
		
		#initialize tripod_legs_020 links
		#geometry_to_instance.Instances -> duplicate_elements.Geometry
		tripod_legs_020.links.new(geometry_to_instance.outputs[0], duplicate_elements.inputs[0])
		#geometry_to_instance.Instances -> duplicate_elements_001.Geometry
		tripod_legs_020.links.new(geometry_to_instance.outputs[0], duplicate_elements_001.inputs[0])
		#duplicate_elements_001.Geometry -> rotate_instances_001.Instances
		tripod_legs_020.links.new(duplicate_elements_001.outputs[0], rotate_instances_001.inputs[0])
		#duplicate_elements.Geometry -> rotate_instances.Instances
		tripod_legs_020.links.new(duplicate_elements.outputs[0], rotate_instances.inputs[0])
		#rotate_instances.Instances -> realize_instances.Geometry
		tripod_legs_020.links.new(rotate_instances.outputs[0], realize_instances.inputs[0])
		#rotate_instances_001.Instances -> realize_instances_001.Geometry
		tripod_legs_020.links.new(rotate_instances_001.outputs[0], realize_instances_001.inputs[0])
		#group_input_4.Base leg -> geometry_to_instance.Geometry
		tripod_legs_020.links.new(group_input_4.outputs[0], geometry_to_instance.inputs[0])
		#realize_instances.Geometry -> group_output_4.Leg 2
		tripod_legs_020.links.new(realize_instances.outputs[0], group_output_4.inputs[0])
		#realize_instances_001.Geometry -> group_output_4.Leg 3
		tripod_legs_020.links.new(realize_instances_001.outputs[0], group_output_4.inputs[1])
		return tripod_legs_020

	tripod_legs_020 = tripod_legs_020_node_group()

	#initialize scanner_model_019 node group
	def scanner_model_019_node_group():
		scanner_model_019 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Scanner model.019")

		scanner_model_019.color_tag = 'NONE'
		scanner_model_019.description = ""

		
		#scanner_model_019 interface
		#Socket scanner_model
		scanner_model_socket = scanner_model_019.interface.new_socket(name = "scanner_model", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		scanner_model_socket.attribute_domain = 'POINT'
		
		#Socket Angle
		angle_socket_2 = scanner_model_019.interface.new_socket(name = "Angle", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
		angle_socket_2.default_value = 0.0
		angle_socket_2.min_value = -3.4028234663852886e+38
		angle_socket_2.max_value = 3.4028234663852886e+38
		angle_socket_2.subtype = 'NONE'
		angle_socket_2.attribute_domain = 'POINT'
		
		#Socket height
		height_socket_1 = scanner_model_019.interface.new_socket(name = "height", in_out='INPUT', socket_type = 'NodeSocketFloat')
		height_socket_1.default_value = 0.5
		height_socket_1.min_value = -10000.0
		height_socket_1.max_value = 10000.0
		height_socket_1.subtype = 'NONE'
		height_socket_1.attribute_domain = 'POINT'
		
		#Socket Min aberture
		min_aberture_socket = scanner_model_019.interface.new_socket(name = "Min aberture", in_out='INPUT', socket_type = 'NodeSocketFloat')
		min_aberture_socket.default_value = 0.0
		min_aberture_socket.min_value = -3.4028234663852886e+38
		min_aberture_socket.max_value = 3.4028234663852886e+38
		min_aberture_socket.subtype = 'NONE'
		min_aberture_socket.attribute_domain = 'POINT'
		
		
		#initialize scanner_model_019 nodes
		#node Group Output
		group_output_5 = scanner_model_019.nodes.new("NodeGroupOutput")
		group_output_5.name = "Group Output"
		group_output_5.is_active_output = True
		
		#node Group Input
		group_input_5 = scanner_model_019.nodes.new("NodeGroupInput")
		group_input_5.name = "Group Input"
		
		#node Cylinder
		cylinder = scanner_model_019.nodes.new("GeometryNodeMeshCylinder")
		cylinder.name = "Cylinder"
		cylinder.fill_type = 'NGON'
		#Vertices
		cylinder.inputs[0].default_value = 32
		#Side Segments
		cylinder.inputs[1].default_value = 1
		#Fill Segments
		cylinder.inputs[2].default_value = 1
		
		#node Set Material
		set_material = scanner_model_019.nodes.new("GeometryNodeSetMaterial")
		set_material.name = "Set Material"
		#Selection
		set_material.inputs[1].default_value = True
		if "Scanner_model" in bpy.data.materials:
			set_material.inputs[2].default_value = bpy.data.materials["Scanner_model"]
		
		#node Combine XYZ
		combine_xyz = scanner_model_019.nodes.new("ShaderNodeCombineXYZ")
		combine_xyz.name = "Combine XYZ"
		#X
		combine_xyz.inputs[0].default_value = 0.0
		#Y
		combine_xyz.inputs[1].default_value = 0.0
		
		#node Math
		math_2 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_2.name = "Math"
		math_2.operation = 'RADIANS'
		math_2.use_clamp = False
		
		#node Vector Rotate
		vector_rotate = scanner_model_019.nodes.new("ShaderNodeVectorRotate")
		vector_rotate.name = "Vector Rotate"
		vector_rotate.invert = False
		vector_rotate.rotation_type = 'Y_AXIS'
		
		#node Position
		position = scanner_model_019.nodes.new("GeometryNodeInputPosition")
		position.name = "Position"
		
		#node Set Position
		set_position_1 = scanner_model_019.nodes.new("GeometryNodeSetPosition")
		set_position_1.name = "Set Position"
		#Selection
		set_position_1.inputs[1].default_value = True
		#Offset
		set_position_1.inputs[3].default_value = (0.0, 0.0, 0.0)
		
		#node Combine XYZ.001
		combine_xyz_001 = scanner_model_019.nodes.new("ShaderNodeCombineXYZ")
		combine_xyz_001.name = "Combine XYZ.001"
		#X
		combine_xyz_001.inputs[0].default_value = 0.0
		#Y
		combine_xyz_001.inputs[1].default_value = 0.0
		
		#node Math.001
		math_001_1 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_001_1.name = "Math.001"
		math_001_1.operation = 'MULTIPLY'
		math_001_1.use_clamp = False
		#Value_001
		math_001_1.inputs[1].default_value = 0.5
		
		#node Sample Nearest
		sample_nearest = scanner_model_019.nodes.new("GeometryNodeSampleNearest")
		sample_nearest.name = "Sample Nearest"
		sample_nearest.domain = 'POINT'
		
		#node Position.001
		position_001 = scanner_model_019.nodes.new("GeometryNodeInputPosition")
		position_001.name = "Position.001"
		
		#node Sample Index
		sample_index = scanner_model_019.nodes.new("GeometryNodeSampleIndex")
		sample_index.name = "Sample Index"
		sample_index.clamp = False
		sample_index.data_type = 'FLOAT_VECTOR'
		sample_index.domain = 'POINT'
		
		#node Combine XYZ.003
		combine_xyz_003 = scanner_model_019.nodes.new("ShaderNodeCombineXYZ")
		combine_xyz_003.name = "Combine XYZ.003"
		#X
		combine_xyz_003.inputs[0].default_value = 0.0
		#Y
		combine_xyz_003.inputs[1].default_value = 0.0
		
		#node Set Position.001
		set_position_001 = scanner_model_019.nodes.new("GeometryNodeSetPosition")
		set_position_001.name = "Set Position.001"
		#Selection
		set_position_001.inputs[1].default_value = True
		#Position
		set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)
		
		#node Separate XYZ
		separate_xyz_1 = scanner_model_019.nodes.new("ShaderNodeSeparateXYZ")
		separate_xyz_1.name = "Separate XYZ"
		
		#node Combine XYZ.004
		combine_xyz_004 = scanner_model_019.nodes.new("ShaderNodeCombineXYZ")
		combine_xyz_004.name = "Combine XYZ.004"
		#X
		combine_xyz_004.inputs[0].default_value = 0.0
		#Y
		combine_xyz_004.inputs[1].default_value = 0.0
		
		#node Math.002
		math_002_1 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_002_1.name = "Math.002"
		math_002_1.operation = 'MULTIPLY'
		math_002_1.use_clamp = False
		#Value_001
		math_002_1.inputs[1].default_value = -1.0
		
		#node Math.003
		math_003_1 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_003_1.name = "Math.003"
		math_003_1.operation = 'MULTIPLY'
		math_003_1.use_clamp = False
		#Value_001
		math_003_1.inputs[1].default_value = -1.0
		
		#node Join Geometry
		join_geometry = scanner_model_019.nodes.new("GeometryNodeJoinGeometry")
		join_geometry.name = "Join Geometry"
		
		#node Group
		group = scanner_model_019.nodes.new("GeometryNodeGroup")
		group.name = "Group"
		group.node_tree = scanner_device_020
		
		#node Group.001
		group_001 = scanner_model_019.nodes.new("GeometryNodeGroup")
		group_001.name = "Group.001"
		group_001.node_tree = tripod_legs_020
		
		#node Math.006
		math_006_3 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_006_3.name = "Math.006"
		math_006_3.operation = 'DIVIDE'
		math_006_3.use_clamp = False
		#Value_001
		math_006_3.inputs[1].default_value = 60.0
		
		#node Switch.005
		switch_005 = scanner_model_019.nodes.new("GeometryNodeSwitch")
		switch_005.name = "Switch.005"
		switch_005.input_type = 'FLOAT'
		
		#node Math.007
		math_007_2 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_007_2.name = "Math.007"
		math_007_2.operation = 'ARCCOSINE'
		math_007_2.use_clamp = False
		
		#node Math.008
		math_008_1 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_008_1.name = "Math.008"
		math_008_1.operation = 'DIVIDE'
		math_008_1.use_clamp = False
		
		#node Switch.006
		switch_006 = scanner_model_019.nodes.new("GeometryNodeSwitch")
		switch_006.name = "Switch.006"
		switch_006.input_type = 'FLOAT'
		
		#node Compare
		compare = scanner_model_019.nodes.new("FunctionNodeCompare")
		compare.name = "Compare"
		compare.data_type = 'FLOAT'
		compare.mode = 'ELEMENT'
		compare.operation = 'GREATER_THAN'
		
		#node Math.009
		math_009_1 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_009_1.name = "Math.009"
		math_009_1.operation = 'SUBTRACT'
		math_009_1.use_clamp = False
		
		#node Math.010
		math_010 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_010.name = "Math.010"
		math_010.operation = 'ADD'
		math_010.use_clamp = False
		
		#node Math.011
		math_011 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_011.name = "Math.011"
		math_011.operation = 'MULTIPLY'
		math_011.use_clamp = False
		
		#node Compare.001
		compare_001 = scanner_model_019.nodes.new("FunctionNodeCompare")
		compare_001.name = "Compare.001"
		compare_001.data_type = 'FLOAT'
		compare_001.mode = 'ELEMENT'
		compare_001.operation = 'GREATER_THAN'
		
		#node Switch.007
		switch_007 = scanner_model_019.nodes.new("GeometryNodeSwitch")
		switch_007.name = "Switch.007"
		switch_007.input_type = 'FLOAT'
		
		#node Object Info
		object_info = scanner_model_019.nodes.new("GeometryNodeObjectInfo")
		object_info.name = "Object Info"
		object_info.transform_space = 'ORIGINAL'
		#As Instance
		object_info.inputs[1].default_value = False
		
		#node Separate XYZ.001
		separate_xyz_001 = scanner_model_019.nodes.new("ShaderNodeSeparateXYZ")
		separate_xyz_001.name = "Separate XYZ.001"
		
		#node Transform Geometry
		transform_geometry = scanner_model_019.nodes.new("GeometryNodeTransform")
		transform_geometry.name = "Transform Geometry"
		transform_geometry.mode = 'COMPONENTS'
		#Rotation
		transform_geometry.inputs[2].default_value = (0.0, 0.0, 0.0)
		#Scale
		transform_geometry.inputs[3].default_value = (1.0, 1.0, 1.0)
		
		#node Math.004
		math_004_3 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_004_3.name = "Math.004"
		math_004_3.operation = 'COSINE'
		math_004_3.use_clamp = False
		
		#node Math.005
		math_005_2 = scanner_model_019.nodes.new("ShaderNodeMath")
		math_005_2.name = "Math.005"
		math_005_2.operation = 'MULTIPLY'
		math_005_2.use_clamp = False
		#Value_001
		math_005_2.inputs[1].default_value = -1.0
		
		#node Self Object
		self_object = scanner_model_019.nodes.new("GeometryNodeSelfObject")
		self_object.name = "Self Object"
		
		
		
		
		#Set locations
		group_output_5.location = (2942.37060546875, -89.16279602050781)
		group_input_5.location = (-4815.9287109375, -113.621826171875)
		cylinder.location = (-599.0537109375, -290.8514099121094)
		set_material.location = (2501.89208984375, 239.3936004638672)
		combine_xyz.location = (1847.0205078125, 117.7630386352539)
		math_2.location = (-4577.82861328125, -386.3826904296875)
		vector_rotate.location = (-1289.958251953125, 303.9515686035156)
		position.location = (-1983.188720703125, 217.59194946289062)
		set_position_1.location = (-142.8206024169922, -283.6128234863281)
		combine_xyz_001.location = (-1987.0888671875, 137.65966796875)
		math_001_1.location = (-2191.20703125, 89.49179077148438)
		sample_nearest.location = (-254.6549835205078, 611.9027099609375)
		position_001.location = (-266.19110107421875, 737.2174682617188)
		sample_index.location = (215.17251586914062, 850.0807495117188)
		combine_xyz_003.location = (-1590.543701171875, 536.0594482421875)
		set_position_001.location = (562.5130615234375, 7.298304080963135)
		separate_xyz_1.location = (481.6890563964844, 919.7169189453125)
		combine_xyz_004.location = (981.7727661132812, 994.1314697265625)
		math_002_1.location = (750.2759399414062, 944.33203125)
		math_003_1.location = (-1903.1380615234375, 468.51507568359375)
		join_geometry.location = (1349.010986328125, 255.65087890625)
		group.location = (-591.9064331054688, 385.76434326171875)
		group_001.location = (948.1644287109375, -32.48196029663086)
		math_006_3.location = (-1380.87890625, -387.260009765625)
		switch_005.location = (-2033.78515625, -254.9252166748047)
		math_007_2.location = (-2458.401123046875, -389.3037109375)
		math_008_1.location = (-2729.25927734375, -461.70458984375)
		switch_006.location = (-2716.9140625, 382.3277282714844)
		compare.location = (-3200.80517578125, 181.34375)
		math_009_1.location = (-3799.4921875, 270.01904296875)
		math_010.location = (-3382.48974609375, 330.60333251953125)
		math_011.location = (-4032.615966796875, -53.410301208496094)
		compare_001.location = (-3559.813232421875, -457.70452880859375)
		switch_007.location = (-3216.40771484375, -74.66142272949219)
		object_info.location = (-4545.9736328125, 174.81314086914062)
		separate_xyz_001.location = (-4359.0791015625, 186.484130859375)
		transform_geometry.location = (2203.178955078125, 207.644775390625)
		math_004_3.location = (-4376.06005859375, -244.452880859375)
		math_005_2.location = (1575.7396240234375, 100.4747085571289)
		self_object.location = (-4750.5556640625, 30.531993865966797)
		
		#Set dimensions
		group_output_5.width, group_output_5.height = 140.0, 100.0
		group_input_5.width, group_input_5.height = 140.0, 100.0
		cylinder.width, cylinder.height = 140.0, 100.0
		set_material.width, set_material.height = 140.0, 100.0
		combine_xyz.width, combine_xyz.height = 140.0, 100.0
		math_2.width, math_2.height = 140.0, 100.0
		vector_rotate.width, vector_rotate.height = 140.0, 100.0
		position.width, position.height = 140.0, 100.0
		set_position_1.width, set_position_1.height = 140.0, 100.0
		combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
		math_001_1.width, math_001_1.height = 140.0, 100.0
		sample_nearest.width, sample_nearest.height = 140.0, 100.0
		position_001.width, position_001.height = 140.0, 100.0
		sample_index.width, sample_index.height = 140.0, 100.0
		combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
		set_position_001.width, set_position_001.height = 140.0, 100.0
		separate_xyz_1.width, separate_xyz_1.height = 140.0, 100.0
		combine_xyz_004.width, combine_xyz_004.height = 140.0, 100.0
		math_002_1.width, math_002_1.height = 140.0, 100.0
		math_003_1.width, math_003_1.height = 140.0, 100.0
		join_geometry.width, join_geometry.height = 140.0, 100.0
		group.width, group.height = 140.0, 100.0
		group_001.width, group_001.height = 140.0, 100.0
		math_006_3.width, math_006_3.height = 140.0, 100.0
		switch_005.width, switch_005.height = 140.0, 100.0
		math_007_2.width, math_007_2.height = 140.0, 100.0
		math_008_1.width, math_008_1.height = 140.0, 100.0
		switch_006.width, switch_006.height = 140.0, 100.0
		compare.width, compare.height = 140.0, 100.0
		math_009_1.width, math_009_1.height = 140.0, 100.0
		math_010.width, math_010.height = 140.0, 100.0
		math_011.width, math_011.height = 140.0, 100.0
		compare_001.width, compare_001.height = 140.0, 100.0
		switch_007.width, switch_007.height = 140.0, 100.0
		object_info.width, object_info.height = 140.0, 100.0
		separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
		transform_geometry.width, transform_geometry.height = 140.0, 100.0
		math_004_3.width, math_004_3.height = 140.0, 100.0
		math_005_2.width, math_005_2.height = 140.0, 100.0
		self_object.width, self_object.height = 140.0, 100.0
		
		#initialize scanner_model_019 links
		#switch_007.Output -> math_008_1.Value
		scanner_model_019.links.new(switch_007.outputs[0], math_008_1.inputs[0])
		#cylinder.Mesh -> set_position_1.Geometry
		scanner_model_019.links.new(cylinder.outputs[0], set_position_1.inputs[0])
		#math_003_1.Value -> combine_xyz_003.Z
		scanner_model_019.links.new(math_003_1.outputs[0], combine_xyz_003.inputs[2])
		#join_geometry.Geometry -> transform_geometry.Geometry
		scanner_model_019.links.new(join_geometry.outputs[0], transform_geometry.inputs[0])
		#set_position_1.Geometry -> set_position_001.Geometry
		scanner_model_019.links.new(set_position_1.outputs[0], set_position_001.inputs[0])
		#math_001_1.Value -> combine_xyz_001.Z
		scanner_model_019.links.new(math_001_1.outputs[0], combine_xyz_001.inputs[2])
		#vector_rotate.Vector -> set_position_1.Position
		scanner_model_019.links.new(vector_rotate.outputs[0], set_position_1.inputs[2])
		#sample_index.Value -> separate_xyz_1.Vector
		scanner_model_019.links.new(sample_index.outputs[0], separate_xyz_1.inputs[0])
		#object_info.Location -> separate_xyz_001.Vector
		scanner_model_019.links.new(object_info.outputs[1], separate_xyz_001.inputs[0])
		#sample_nearest.Index -> sample_index.Index
		scanner_model_019.links.new(sample_nearest.outputs[0], sample_index.inputs[2])
		#switch_005.Output -> group.alfa
		scanner_model_019.links.new(switch_005.outputs[0], group.inputs[0])
		#switch_005.Output -> vector_rotate.Angle
		scanner_model_019.links.new(switch_005.outputs[0], vector_rotate.inputs[3])
		#math_2.Value -> switch_005.True
		scanner_model_019.links.new(math_2.outputs[0], switch_005.inputs[2])
		#switch_006.Output -> cylinder.Depth
		scanner_model_019.links.new(switch_006.outputs[0], cylinder.inputs[4])
		#math_006_3.Value -> cylinder.Radius
		scanner_model_019.links.new(math_006_3.outputs[0], cylinder.inputs[3])
		#math_008_1.Value -> math_007_2.Value
		scanner_model_019.links.new(math_008_1.outputs[0], math_007_2.inputs[0])
		#position_001.Position -> sample_index.Value
		scanner_model_019.links.new(position_001.outputs[0], sample_index.inputs[1])
		#math_010.Value -> switch_006.True
		scanner_model_019.links.new(math_010.outputs[0], switch_006.inputs[2])
		#combine_xyz_004.Vector -> set_position_001.Offset
		scanner_model_019.links.new(combine_xyz_004.outputs[0], set_position_001.inputs[3])
		#set_position_001.Geometry -> group_001.Base leg
		scanner_model_019.links.new(set_position_001.outputs[0], group_001.inputs[0])
		#math_009_1.Value -> math_010.Value
		scanner_model_019.links.new(math_009_1.outputs[0], math_010.inputs[1])
		#combine_xyz_001.Vector -> vector_rotate.Center
		scanner_model_019.links.new(combine_xyz_001.outputs[0], vector_rotate.inputs[1])
		#math_011.Value -> compare_001.B
		scanner_model_019.links.new(math_011.outputs[0], compare_001.inputs[1])
		#switch_006.Output -> group.height
		scanner_model_019.links.new(switch_006.outputs[0], group.inputs[1])
		#compare_001.Result -> switch_007.Switch
		scanner_model_019.links.new(compare_001.outputs[0], switch_007.inputs[0])
		#switch_006.Output -> math_003_1.Value
		scanner_model_019.links.new(switch_006.outputs[0], math_003_1.inputs[0])
		#combine_xyz_003.Vector -> sample_nearest.Sample Position
		scanner_model_019.links.new(combine_xyz_003.outputs[0], sample_nearest.inputs[1])
		#math_011.Value -> compare.B
		scanner_model_019.links.new(math_011.outputs[0], compare.inputs[1])
		#math_007_2.Value -> switch_005.False
		scanner_model_019.links.new(math_007_2.outputs[0], switch_005.inputs[1])
		#set_position_1.Geometry -> sample_index.Geometry
		scanner_model_019.links.new(set_position_1.outputs[0], sample_index.inputs[0])
		#group_001.Leg 3 -> join_geometry.Geometry
		scanner_model_019.links.new(group_001.outputs[1], join_geometry.inputs[0])
		#math_002_1.Value -> combine_xyz_004.Z
		scanner_model_019.links.new(math_002_1.outputs[0], combine_xyz_004.inputs[2])
		#switch_006.Output -> math_001_1.Value
		scanner_model_019.links.new(switch_006.outputs[0], math_001_1.inputs[0])
		#compare_001.Result -> switch_005.Switch
		scanner_model_019.links.new(compare_001.outputs[0], switch_005.inputs[0])
		#compare.Result -> switch_006.Switch
		scanner_model_019.links.new(compare.outputs[0], switch_006.inputs[0])
		#cylinder.Mesh -> sample_nearest.Geometry
		scanner_model_019.links.new(cylinder.outputs[0], sample_nearest.inputs[0])
		#switch_006.Output -> math_006_3.Value
		scanner_model_019.links.new(switch_006.outputs[0], math_006_3.inputs[0])
		#separate_xyz_1.Z -> math_002_1.Value
		scanner_model_019.links.new(separate_xyz_1.outputs[2], math_002_1.inputs[0])
		#position.Position -> vector_rotate.Vector
		scanner_model_019.links.new(position.outputs[0], vector_rotate.inputs[0])
		#transform_geometry.Geometry -> set_material.Geometry
		scanner_model_019.links.new(transform_geometry.outputs[0], set_material.inputs[0])
		#group_input_5.height -> math_008_1.Value
		scanner_model_019.links.new(group_input_5.outputs[0], math_008_1.inputs[1])
		#group_input_5.height -> switch_006.False
		scanner_model_019.links.new(group_input_5.outputs[0], switch_006.inputs[1])
		#group_input_5.height -> math_009_1.Value
		scanner_model_019.links.new(group_input_5.outputs[0], math_009_1.inputs[1])
		#group_input_5.height -> math_010.Value
		scanner_model_019.links.new(group_input_5.outputs[0], math_010.inputs[0])
		#group_input_5.height -> math_011.Value
		scanner_model_019.links.new(group_input_5.outputs[0], math_011.inputs[0])
		#group_input_5.height -> switch_007.True
		scanner_model_019.links.new(group_input_5.outputs[0], switch_007.inputs[2])
		#set_material.Geometry -> group_output_5.scanner_model
		scanner_model_019.links.new(set_material.outputs[0], group_output_5.inputs[0])
		#combine_xyz.Vector -> transform_geometry.Translation
		scanner_model_019.links.new(combine_xyz.outputs[0], transform_geometry.inputs[1])
		#switch_005.Output -> group_output_5.Angle
		scanner_model_019.links.new(switch_005.outputs[0], group_output_5.inputs[1])
		#group_input_5.Min aberture -> math_2.Value
		scanner_model_019.links.new(group_input_5.outputs[1], math_2.inputs[0])
		#math_004_3.Value -> math_011.Value
		scanner_model_019.links.new(math_004_3.outputs[0], math_011.inputs[1])
		#math_2.Value -> math_004_3.Value
		scanner_model_019.links.new(math_2.outputs[0], math_004_3.inputs[0])
		#math_005_2.Value -> combine_xyz.Z
		scanner_model_019.links.new(math_005_2.outputs[0], combine_xyz.inputs[2])
		#switch_007.Output -> math_005_2.Value
		scanner_model_019.links.new(switch_007.outputs[0], math_005_2.inputs[0])
		#separate_xyz_001.Z -> math_009_1.Value
		scanner_model_019.links.new(separate_xyz_001.outputs[2], math_009_1.inputs[0])
		#separate_xyz_001.Z -> compare.A
		scanner_model_019.links.new(separate_xyz_001.outputs[2], compare.inputs[0])
		#separate_xyz_001.Z -> switch_007.False
		scanner_model_019.links.new(separate_xyz_001.outputs[2], switch_007.inputs[1])
		#separate_xyz_001.Z -> compare_001.A
		scanner_model_019.links.new(separate_xyz_001.outputs[2], compare_001.inputs[0])
		#self_object.Self Object -> object_info.Object
		scanner_model_019.links.new(self_object.outputs[0], object_info.inputs[0])
		#set_position_001.Geometry -> join_geometry.Geometry
		scanner_model_019.links.new(set_position_001.outputs[0], join_geometry.inputs[0])
		#group_001.Leg 2 -> join_geometry.Geometry
		scanner_model_019.links.new(group_001.outputs[0], join_geometry.inputs[0])
		#group.Scanner_device -> join_geometry.Geometry
		scanner_model_019.links.new(group.outputs[0], join_geometry.inputs[0])
		return scanner_model_019

	scanner_model_019 = scanner_model_019_node_group()

	#initialize scanner_018 node group
	def scanner_018_node_group():
		scanner_018 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Scanner.018")

		scanner_018.color_tag = 'CONVERTER'
		scanner_018.description = ""

		
		#scanner_018 interface
		#node Group Input.001
		group_input_001 = scanner_018.nodes.new("NodeGroupInput")
		group_input_001.name = "Group Input.001"
		#Socket Geometry
		geometry_socket_4 = scanner_018.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_4.attribute_domain = 'POINT'
		
		#Socket Scanner model
		scanner_model_socket_1 = scanner_018.interface.new_socket(name = "Scanner model", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		scanner_model_socket_1.attribute_domain = 'POINT'
		
		#Socket Normal
		normal_socket_1 = scanner_018.interface.new_socket(name = "Normal", in_out='INPUT', socket_type = 'NodeSocketVector')
		normal_socket_1.default_value = (0.0, 0.0, 0.0)
		normal_socket_1.min_value = -10000.0
		normal_socket_1.max_value = 10000.0
		normal_socket_1.subtype = 'NONE'
		normal_socket_1.attribute_domain = 'POINT'
		
		#Socket Selection
		selection_socket_2 = scanner_018.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
		selection_socket_2.default_value = True
		selection_socket_2.attribute_domain = 'POINT'
		selection_socket_2.hide_value = True
		
		#Socket Position
		position_socket_1 = scanner_018.interface.new_socket(name = "Position", in_out='INPUT', socket_type = 'NodeSocketVector')
		position_socket_1.default_value = (0.0, 0.0, 0.0)
		position_socket_1.min_value = -3.4028234663852886e+38
		position_socket_1.max_value = 3.4028234663852886e+38
		position_socket_1.subtype = 'NONE'
		position_socket_1.attribute_domain = 'POINT'
		position_socket_1.hide_value = True
		
		#Socket Hit distance
		hit_distance_socket_1 = scanner_018.interface.new_socket(name = "Hit distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
		hit_distance_socket_1.default_value = 0.5
		hit_distance_socket_1.min_value = -10000.0
		hit_distance_socket_1.max_value = 10000.0
		hit_distance_socket_1.subtype = 'NONE'
		hit_distance_socket_1.attribute_domain = 'POINT'
		
		#Socket Angle
		angle_socket_3 = scanner_018.interface.new_socket(name = "Angle", in_out='INPUT', socket_type = 'NodeSocketFloat')
		angle_socket_3.default_value = 0.0
		angle_socket_3.min_value = -3.4028234663852886e+38
		angle_socket_3.max_value = 3.4028234663852886e+38
		angle_socket_3.subtype = 'NONE'
		angle_socket_3.attribute_domain = 'POINT'
		
		#Socket Height
		height_socket_2 = scanner_018.interface.new_socket(name = "Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
		height_socket_2.default_value = 0.5
		height_socket_2.min_value = -10000.0
		height_socket_2.max_value = 10000.0
		height_socket_2.subtype = 'NONE'
		height_socket_2.attribute_domain = 'POINT'
		
		#Socket Noise
		noise_socket_1 = scanner_018.interface.new_socket(name = "Noise", in_out='INPUT', socket_type = 'NodeSocketMenu')
		noise_socket_1.attribute_domain = 'POINT'

		#node Group
		group_1 = scanner_018.nodes.new("GeometryNodeGroup")
		group_1.name = "Group"
		group_1.node_tree = setposition_026
		 
		#group_input_001.Noise -> group_1.Noise
		scanner_018.links.new(group_input_001.outputs[6], group_1.inputs[5])	
		
		noise_socket_1.default_value = "Noise-normal"
		
		#Socket Noise@1m
		noise_1m_socket_1 = scanner_018.interface.new_socket(name = "Noise@1m", in_out='INPUT', socket_type = 'NodeSocketFloat')
		noise_1m_socket_1.default_value = 0.10000000149011612
		noise_1m_socket_1.min_value = -10000.0
		noise_1m_socket_1.max_value = 10000.0
		noise_1m_socket_1.subtype = 'NONE'
		noise_1m_socket_1.attribute_domain = 'POINT'
		
		#Socket Radius
		radius_socket_1 = scanner_018.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
		radius_socket_1.default_value = 0.0
		radius_socket_1.min_value = -3.4028234663852886e+38
		radius_socket_1.max_value = 3.4028234663852886e+38
		radius_socket_1.subtype = 'NONE'
		radius_socket_1.attribute_domain = 'POINT'
		
		#Socket Seed
		seed_socket_1 = scanner_018.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketFloat')
		seed_socket_1.default_value = 0.0
		seed_socket_1.min_value = -3.4028234663852886e+38
		seed_socket_1.max_value = 3.4028234663852886e+38
		seed_socket_1.subtype = 'NONE'
		seed_socket_1.attribute_domain = 'POINT'
		
		#Socket Distance - factor
		distance___factor_socket_1 = scanner_018.interface.new_socket(name = "Distance - factor", in_out='INPUT', socket_type = 'NodeSocketFloat')
		distance___factor_socket_1.default_value = 0.0
		distance___factor_socket_1.min_value = -3.4028234663852886e+38
		distance___factor_socket_1.max_value = 3.4028234663852886e+38
		distance___factor_socket_1.subtype = 'NONE'
		distance___factor_socket_1.attribute_domain = 'POINT'
		
		#Socket Reference
		reference_socket_1 = scanner_018.interface.new_socket(name = "Reference", in_out='INPUT', socket_type = 'NodeSocketMenu')
		reference_socket_1.attribute_domain = 'POINT'

		#group_input_001.Reference -> group_1.Reference
		scanner_018.links.new(group_input_001.outputs[11], group_1.inputs[10])

		reference_socket_1.default_value = "Global"
		
		#Socket XYZ - factors
		xyz___factors_socket_1 = scanner_018.interface.new_socket(name = "XYZ - factors", in_out='INPUT', socket_type = 'NodeSocketVector')
		xyz___factors_socket_1.default_value = (0.0, 0.0, 0.0)
		xyz___factors_socket_1.min_value = -3.4028234663852886e+38
		xyz___factors_socket_1.max_value = 3.4028234663852886e+38
		xyz___factors_socket_1.subtype = 'NONE'
		xyz___factors_socket_1.attribute_domain = 'POINT'
		
		#Socket Min aberture
		min_aberture_socket_1 = scanner_018.interface.new_socket(name = "Min aberture", in_out='INPUT', socket_type = 'NodeSocketFloat')
		min_aberture_socket_1.default_value = 0.0
		min_aberture_socket_1.min_value = -3.4028234663852886e+38
		min_aberture_socket_1.max_value = 3.4028234663852886e+38
		min_aberture_socket_1.subtype = 'NONE'
		min_aberture_socket_1.attribute_domain = 'POINT'
		
		#Socket Scanner model
		scanner_model_socket_2 = scanner_018.interface.new_socket(name = "Scanner model", in_out='INPUT', socket_type = 'NodeSocketBool')
		scanner_model_socket_2.default_value = False
		scanner_model_socket_2.attribute_domain = 'POINT'
		
		
		#initialize scanner_018 nodes
		#node Group Output
		group_output_6 = scanner_018.nodes.new("NodeGroupOutput")
		group_output_6.name = "Group Output"
		group_output_6.is_active_output = True
		
		
		#node Group.003
		group_003 = scanner_018.nodes.new("GeometryNodeGroup")
		group_003.name = "Group.003"
		group_003.node_tree = sphere_scanner_019
		
		#node Group.007
		group_007 = scanner_018.nodes.new("GeometryNodeGroup")
		group_007.name = "Group.007"
		group_007.node_tree = points_deletion_019
		
		#node Group.008
		group_008 = scanner_018.nodes.new("GeometryNodeGroup")
		group_008.name = "Group.008"
		group_008.node_tree = scanner_model_019
		
		#node Switch.001
		switch_001 = scanner_018.nodes.new("GeometryNodeSwitch")
		switch_001.name = "Switch.001"
		switch_001.hide = True
		switch_001.input_type = 'GEOMETRY'
		
		#node Frame.001
		frame_001 = scanner_018.nodes.new("NodeFrame")
		frame_001.label = "SPHERE SCANNER"
		frame_001.name = "Frame.001"
		frame_001.label_size = 22
		frame_001.shrink = True
		
		#node Frame.002
		frame_002_1 = scanner_018.nodes.new("NodeFrame")
		frame_002_1.label = "SCANNER MODEL"
		frame_002_1.name = "Frame.002"
		frame_002_1.label_size = 22
		frame_002_1.shrink = True
		
		#node Frame.003
		frame_003 = scanner_018.nodes.new("NodeFrame")
		frame_003.label = "POINT DELETION"
		frame_003.name = "Frame.003"
		frame_003.label_size = 22
		frame_003.shrink = True
		
		#node Frame.004
		frame_004 = scanner_018.nodes.new("NodeFrame")
		frame_004.label = "TRANSFORM POINTS"
		frame_004.name = "Frame.004"
		frame_004.label_size = 22
		frame_004.shrink = False
		
		#node Frame.005
		frame_005 = scanner_018.nodes.new("NodeFrame")
		frame_005.label = "INPUT"
		frame_005.name = "Frame.005"
		frame_005.label_size = 22
		frame_005.shrink = True
		
		#node Frame.006
		frame_006 = scanner_018.nodes.new("NodeFrame")
		frame_006.label = "OUTPUT"
		frame_006.name = "Frame.006"
		frame_006.label_size = 22
		frame_006.shrink = True
		
		#node Reroute
		reroute_2 = scanner_018.nodes.new("NodeReroute")
		reroute_2.name = "Reroute"
		#node Reroute.001
		reroute_001_1 = scanner_018.nodes.new("NodeReroute")
		reroute_001_1.name = "Reroute.001"
		#node Reroute.004
		reroute_004 = scanner_018.nodes.new("NodeReroute")
		reroute_004.name = "Reroute.004"
		
		
		#Set parents
		group_output_6.parent = frame_006
		group_input_001.parent = frame_005
		group_1.parent = frame_004
		group_003.parent = frame_001
		group_007.parent = frame_003
		group_008.parent = frame_002_1
		switch_001.parent = frame_003
		
		#Set locations
		group_output_6.location = (625.253662109375, -16.1058349609375)
		group_input_001.location = (-280.85955810546875, 113.20248413085938)
		group_1.location = (-150.87615966796875, 14.054000854492188)
		group_003.location = (-294.3008117675781, 31.9805908203125)
		group_007.location = (-310.8580627441406, 181.85980224609375)
		group_008.location = (-281.88726806640625, 62.97381591796875)
		switch_001.location = (-316.3081970214844, 2.026123046875)
		frame_001.location = (-210.9942626953125, -564.6177978515625)
		frame_002_1.location = (-212.5897216796875, -777.417236328125)
		frame_003.location = (242.2271728515625, -642.3556518554688)
		frame_004.location = (413.57061767578125, -87.94036865234375)
		frame_005.location = (-653.6921997070312, -239.34764099121094)
		frame_006.location = (491.6222229003906, -192.26004028320312)
		reroute_2.location = (-240.42453002929688, -158.40611267089844)
		reroute_001_1.location = (-278.30889892578125, -177.571044921875)
		reroute_004.location = (-254.1930694580078, -497.2965393066406)
		
		#Set dimensions
		group_output_6.width, group_output_6.height = 140.0, 100.0
		group_input_001.width, group_input_001.height = 140.0, 100.0
		group_1.width, group_1.height = 140.0, 100.0
		group_003.width, group_003.height = 140.0, 100.0
		group_007.width, group_007.height = 140.0, 100.0
		group_008.width, group_008.height = 140.0, 100.0
		switch_001.width, switch_001.height = 140.0, 100.0
		frame_001.width, frame_001.height = 199.99996948242188, 169.29998779296875
		frame_002_1.width, frame_002_1.height = 200.00003051757812, 212.5
		frame_003.width, frame_003.height = 205.59999084472656, 276.70001220703125
		frame_004.width, frame_004.height = 410.4134521484375, 553.29931640625
		frame_005.width, frame_005.height = 200.0, 446.0999755859375
		frame_006.width, frame_006.height = 200.0, 165.29998779296875
		reroute_2.width, reroute_2.height = 16.0, 100.0
		reroute_001_1.width, reroute_001_1.height = 16.0, 100.0
		reroute_004.width, reroute_004.height = 16.0, 100.0
		
		#initialize scanner_018 links
		#group_008.Angle -> group_007.Angle
		scanner_018.links.new(group_008.outputs[1], group_007.inputs[1])
		#group_008.scanner_model -> switch_001.True
		scanner_018.links.new(group_008.outputs[0], switch_001.inputs[2])
		#group_input_001.Position -> group_1.Position
		scanner_018.links.new(group_input_001.outputs[2], group_1.inputs[2])
		#group_input_001.Hit distance -> group_1.Hit distance
		scanner_018.links.new(group_input_001.outputs[3], group_1.inputs[4])
		#reroute_001_1.Output -> group_1.Selection
		scanner_018.links.new(reroute_001_1.outputs[0], group_1.inputs[1])
		#reroute_2.Output -> group_1.Normal
		scanner_018.links.new(reroute_2.outputs[0], group_1.inputs[3])
		#group_input_001.Angle -> group_003.Angle
		scanner_018.links.new(group_input_001.outputs[4], group_003.inputs[0])
		#group_input_001.Min aberture -> group_008.Min aberture
		scanner_018.links.new(group_input_001.outputs[13], group_008.inputs[1])
		#group_input_001.Height -> group_008.height
		scanner_018.links.new(group_input_001.outputs[5], group_008.inputs[0])
		#reroute_004.Output -> switch_001.Switch
		scanner_018.links.new(reroute_004.outputs[0], switch_001.inputs[0])
		#switch_001.Output -> group_output_6.Scanner model
		scanner_018.links.new(switch_001.outputs[0], group_output_6.inputs[1])
		#group_1.Geometry -> group_output_6.Geometry
		scanner_018.links.new(group_1.outputs[0], group_output_6.inputs[0])
		#group_003.Mesh -> group_007.Geometry
		scanner_018.links.new(group_003.outputs[0], group_007.inputs[0])
		#group_007.Geometry -> group_1.Geometry
		scanner_018.links.new(group_007.outputs[0], group_1.inputs[0])
		#group_input_001.Normal -> reroute_2.Input
		scanner_018.links.new(group_input_001.outputs[0], reroute_2.inputs[0])
		#reroute_2.Output -> group_007.Vector
		scanner_018.links.new(reroute_2.outputs[0], group_007.inputs[2])
		#group_input_001.Selection -> reroute_001_1.Input
		scanner_018.links.new(group_input_001.outputs[1], reroute_001_1.inputs[0])
		#reroute_001_1.Output -> group_007.Selection
		scanner_018.links.new(reroute_001_1.outputs[0], group_007.inputs[3])
		#group_input_001.Scanner model -> reroute_004.Input
		scanner_018.links.new(group_input_001.outputs[14], reroute_004.inputs[0])
		#group_input_001.Distance - factor -> group_1.Distance - factor
		scanner_018.links.new(group_input_001.outputs[10], group_1.inputs[9])
		#group_input_001.XYZ - factors -> group_1.XYZ - factors
		scanner_018.links.new(group_input_001.outputs[12], group_1.inputs[11])
		#group_input_001.Noise@1m -> group_1.Noise@1m
		scanner_018.links.new(group_input_001.outputs[7], group_1.inputs[6])
		#group_input_001.Seed -> group_1.Seed
		scanner_018.links.new(group_input_001.outputs[9], group_1.inputs[8])
		#group_input_001.Radius -> group_1.Radius
		scanner_018.links.new(group_input_001.outputs[8], group_1.inputs[7])
		return scanner_018

	scanner_018 = scanner_018_node_group()

	#initialize color_configuration_028 node group
	def color_configuration_028_node_group():
		color_configuration_028 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Color configuration.028")

		color_configuration_028.color_tag = 'COLOR'
		color_configuration_028.description = ""

		
		#color_configuration_028 interface
		#initialize color_configuration_028 nodes
		#node Group Input
		group_input_6 = color_configuration_028.nodes.new("NodeGroupInput")
		group_input_6.name = "Group Input"
		#Socket Output
		output_socket = color_configuration_028.interface.new_socket(name = "Output", in_out='OUTPUT', socket_type = 'NodeSocketColor')
		output_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
		output_socket.attribute_domain = 'POINT'
		
		#Socket Geometry
		geometry_socket_5 = color_configuration_028.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_5.attribute_domain = 'POINT'
		
		#Socket Geometry
		geometry_socket_6 = color_configuration_028.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_6.attribute_domain = 'POINT'
		
		#Socket Selection
		selection_socket_3 = color_configuration_028.interface.new_socket(name = "Selection", in_out='INPUT', socket_type = 'NodeSocketBool')
		selection_socket_3.default_value = True
		selection_socket_3.attribute_domain = 'POINT'
		selection_socket_3.hide_value = True
		
		#Socket Sample Position
		sample_position_socket = color_configuration_028.interface.new_socket(name = "Sample Position", in_out='INPUT', socket_type = 'NodeSocketVector')
		sample_position_socket.default_value = (0.0, 0.0, 0.0)
		sample_position_socket.min_value = -3.4028234663852886e+38
		sample_position_socket.max_value = 3.4028234663852886e+38
		sample_position_socket.subtype = 'NONE'
		sample_position_socket.attribute_domain = 'POINT'
		sample_position_socket.hide_value = True
		
		#Socket Hit Distance
		hit_distance_socket_2 = color_configuration_028.interface.new_socket(name = "Hit Distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
		hit_distance_socket_2.default_value = 0.0
		hit_distance_socket_2.min_value = -3.4028234663852886e+38
		hit_distance_socket_2.max_value = 3.4028234663852886e+38
		hit_distance_socket_2.subtype = 'NONE'
		hit_distance_socket_2.attribute_domain = 'POINT'
		hit_distance_socket_2.hide_value = True
		
		#Socket Menu
		menu_socket = color_configuration_028.interface.new_socket(name = "Menu", in_out='INPUT', socket_type = 'NodeSocketMenu')
		menu_socket.attribute_domain = 'POINT'
		

		#node Menu Switch
		menu_switch_1 = color_configuration_028.nodes.new("GeometryNodeMenuSwitch")
		menu_switch_1.name = "Menu Switch"
		menu_switch_1.active_index = 2
		menu_switch_1.data_type = 'RGBA'
		menu_switch_1.enum_items.clear()
		menu_switch_1.enum_items.new("Plain")
		menu_switch_1.enum_items[0].description = ""
		menu_switch_1.enum_items.new("Distance")
		menu_switch_1.enum_items[1].description = ""
		menu_switch_1.enum_items.new("Texture")
		menu_switch_1.enum_items[2].description = ""
		
		#group_input_6.Menu -> menu_switch_1.Menu
		color_configuration_028.links.new(group_input_6.outputs[5], menu_switch_1.inputs[0])

		menu_socket.default_value = "Plain"
		
		#Socket Plain
		plain_socket = color_configuration_028.interface.new_socket(name = "Plain", in_out='INPUT', socket_type = 'NodeSocketColor')
		plain_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
		plain_socket.attribute_domain = 'POINT'
		
		#Socket Image
		image_socket = color_configuration_028.interface.new_socket(name = "Image", in_out='INPUT', socket_type = 'NodeSocketImage')
		image_socket.attribute_domain = 'POINT'
		
		#node Group Output
		group_output_7 = color_configuration_028.nodes.new("NodeGroupOutput")
		group_output_7.name = "Group Output"
		group_output_7.is_active_output = True
		
		#node Named Attribute
		named_attribute = color_configuration_028.nodes.new("GeometryNodeInputNamedAttribute")
		named_attribute.name = "Named Attribute"
		named_attribute.data_type = 'FLOAT_VECTOR'
		#Name
		named_attribute.inputs[0].default_value = "UVMap"
		
		#node Attribute Statistic
		attribute_statistic = color_configuration_028.nodes.new("GeometryNodeAttributeStatistic")
		attribute_statistic.name = "Attribute Statistic"
		attribute_statistic.data_type = 'FLOAT'
		attribute_statistic.domain = 'POINT'
		
		#node Map Range
		map_range = color_configuration_028.nodes.new("ShaderNodeMapRange")
		map_range.name = "Map Range"
		map_range.clamp = False
		map_range.data_type = 'FLOAT'
		map_range.interpolation_type = 'SMOOTHERSTEP'
		#To Min
		map_range.inputs[3].default_value = 0.0
		#To Max
		map_range.inputs[4].default_value = 1.0
		
		#node Color Ramp
		color_ramp = color_configuration_028.nodes.new("ShaderNodeValToRGB")
		color_ramp.name = "Color Ramp"
		color_ramp.color_ramp.color_mode = 'HSV'
		color_ramp.color_ramp.hue_interpolation = 'NEAR'
		color_ramp.color_ramp.interpolation = 'EASE'
		
		#initialize color ramp elements
		color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
		color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
		color_ramp_cre_0.position = 0.0
		color_ramp_cre_0.alpha = 1.0
		color_ramp_cre_0.color = (1.0, 0.0, 0.0, 1.0)

		color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.33333298563957214)
		color_ramp_cre_1.alpha = 1.0
		color_ramp_cre_1.color = (1.0, 0.9078109264373779, 0.0, 1.0)

		color_ramp_cre_2 = color_ramp.color_ramp.elements.new(0.6666666269302368)
		color_ramp_cre_2.alpha = 1.0
		color_ramp_cre_2.color = (0.0, 1.0, 0.003756897756829858, 1.0)

		color_ramp_cre_3 = color_ramp.color_ramp.elements.new(1.0)
		color_ramp_cre_3.alpha = 1.0
		color_ramp_cre_3.color = (0.011158492416143417, 0.0, 1.0, 1.0)

		
		#node Sample Nearest
		sample_nearest_1 = color_configuration_028.nodes.new("GeometryNodeSampleNearest")
		sample_nearest_1.name = "Sample Nearest"
		sample_nearest_1.domain = 'POINT'
		
		#node Sample Index
		sample_index_1 = color_configuration_028.nodes.new("GeometryNodeSampleIndex")
		sample_index_1.name = "Sample Index"
		sample_index_1.clamp = False
		sample_index_1.data_type = 'FLOAT_VECTOR'
		sample_index_1.domain = 'POINT'
		
		#node Image Texture
		image_texture = color_configuration_028.nodes.new("GeometryNodeImageTexture")
		image_texture.name = "Image Texture"
		image_texture.extension = 'REPEAT'
		image_texture.interpolation = 'Linear'
		#Frame
		image_texture.inputs[2].default_value = 0
		
		#node Reroute
		reroute_3 = color_configuration_028.nodes.new("NodeReroute")
		reroute_3.name = "Reroute"
		#node Reroute.001
		reroute_001_2 = color_configuration_028.nodes.new("NodeReroute")
		reroute_001_2.name = "Reroute.001"
		#node Reroute.002
		reroute_002_1 = color_configuration_028.nodes.new("NodeReroute")
		reroute_002_1.name = "Reroute.002"
		#node Reroute.003
		reroute_003_1 = color_configuration_028.nodes.new("NodeReroute")
		reroute_003_1.name = "Reroute.003"
		
		
		
		#Set locations
		group_input_6.location = (-1076.482421875, -90.782470703125)
		menu_switch_1.location = (-31.06085968017578, -144.35125732421875)
		group_output_7.location = (132.9921417236328, -144.39820861816406)
		named_attribute.location = (-819.3297119140625, -535.5785522460938)
		attribute_statistic.location = (-830.0711669921875, 114.56112670898438)
		map_range.location = (-628.4990844726562, 145.6301727294922)
		color_ramp.location = (-313.793701171875, -266.978271484375)
		sample_nearest_1.location = (-822.2525024414062, -406.5987548828125)
		sample_index_1.location = (-666.6641845703125, -290.6698913574219)
		image_texture.location = (-317.51190185546875, -483.02349853515625)
		reroute_3.location = (-853.3014526367188, -322.6751708984375)
		reroute_001_2.location = (-483.70428466796875, -277.74005126953125)
		reroute_002_1.location = (-701.8469848632812, -320.2386474609375)
		reroute_003_1.location = (-684.7481689453125, -216.38258361816406)
		
		#Set dimensions
		group_input_6.width, group_input_6.height = 140.0, 100.0
		menu_switch_1.width, menu_switch_1.height = 140.0, 100.0
		group_output_7.width, group_output_7.height = 140.0, 100.0
		named_attribute.width, named_attribute.height = 140.0, 100.0
		attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
		map_range.width, map_range.height = 140.0, 100.0
		color_ramp.width, color_ramp.height = 240.0, 100.0
		sample_nearest_1.width, sample_nearest_1.height = 140.0, 100.0
		sample_index_1.width, sample_index_1.height = 140.0, 100.0
		image_texture.width, image_texture.height = 240.0, 100.0
		reroute_3.width, reroute_3.height = 100.0, 100.0
		reroute_001_2.width, reroute_001_2.height = 100.0, 100.0
		reroute_002_1.width, reroute_002_1.height = 100.0, 100.0
		reroute_003_1.width, reroute_003_1.height = 100.0, 100.0
		
		#initialize color_configuration_028 links
		#sample_index_1.Value -> image_texture.Vector
		color_configuration_028.links.new(sample_index_1.outputs[0], image_texture.inputs[1])
		#color_ramp.Color -> menu_switch_1.Distance
		color_configuration_028.links.new(color_ramp.outputs[0], menu_switch_1.inputs[2])
		#attribute_statistic.Min -> map_range.From Min
		color_configuration_028.links.new(attribute_statistic.outputs[3], map_range.inputs[1])
		#map_range.Result -> color_ramp.Fac
		color_configuration_028.links.new(map_range.outputs[0], color_ramp.inputs[0])
		#attribute_statistic.Max -> map_range.From Max
		color_configuration_028.links.new(attribute_statistic.outputs[4], map_range.inputs[2])
		#image_texture.Color -> menu_switch_1.Texture
		color_configuration_028.links.new(image_texture.outputs[0], menu_switch_1.inputs[3])
		#group_input_6.Hit Distance -> attribute_statistic.Attribute
		color_configuration_028.links.new(group_input_6.outputs[4], attribute_statistic.inputs[2])
		#reroute_003_1.Output -> map_range.Value
		color_configuration_028.links.new(reroute_003_1.outputs[0], map_range.inputs[0])
		#group_input_6.Plain -> menu_switch_1.Plain
		color_configuration_028.links.new(group_input_6.outputs[6], menu_switch_1.inputs[1])
		#group_input_6.Geometry -> attribute_statistic.Geometry
		color_configuration_028.links.new(group_input_6.outputs[1], attribute_statistic.inputs[0])
		#reroute_3.Output -> sample_nearest_1.Geometry
		color_configuration_028.links.new(reroute_3.outputs[0], sample_nearest_1.inputs[0])
		#group_input_6.Selection -> attribute_statistic.Selection
		color_configuration_028.links.new(group_input_6.outputs[2], attribute_statistic.inputs[1])
		#group_input_6.Geometry -> reroute_3.Input
		color_configuration_028.links.new(group_input_6.outputs[0], reroute_3.inputs[0])
		#reroute_002_1.Output -> sample_index_1.Geometry
		color_configuration_028.links.new(reroute_002_1.outputs[0], sample_index_1.inputs[0])
		#group_input_6.Image -> reroute_001_2.Input
		color_configuration_028.links.new(group_input_6.outputs[7], reroute_001_2.inputs[0])
		#reroute_001_2.Output -> image_texture.Image
		color_configuration_028.links.new(reroute_001_2.outputs[0], image_texture.inputs[0])
		#reroute_3.Output -> reroute_002_1.Input
		color_configuration_028.links.new(reroute_3.outputs[0], reroute_002_1.inputs[0])
		#group_input_6.Hit Distance -> reroute_003_1.Input
		color_configuration_028.links.new(group_input_6.outputs[4], reroute_003_1.inputs[0])
		#named_attribute.Attribute -> sample_index_1.Value
		color_configuration_028.links.new(named_attribute.outputs[0], sample_index_1.inputs[1])
		#group_input_6.Sample Position -> sample_nearest_1.Sample Position
		color_configuration_028.links.new(group_input_6.outputs[3], sample_nearest_1.inputs[1])
		#sample_nearest_1.Index -> sample_index_1.Index
		color_configuration_028.links.new(sample_nearest_1.outputs[0], sample_index_1.inputs[2])
		#menu_switch_1.Output -> group_output_7.Output
		color_configuration_028.links.new(menu_switch_1.outputs[0], group_output_7.inputs[0])
		return color_configuration_028

	color_configuration_028 = color_configuration_028_node_group()

	#initialize attributes_storage_025 node group
	def attributes_storage_025_node_group():
		attributes_storage_025 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Attributes storage.025")

		attributes_storage_025.color_tag = 'ATTRIBUTE'
		attributes_storage_025.description = ""

		
		#attributes_storage_025 interface
		#Socket Geometry
		geometry_socket_7 = attributes_storage_025.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_7.attribute_domain = 'POINT'
		
		#Socket Geometry
		geometry_socket_8 = attributes_storage_025.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_8.attribute_domain = 'POINT'
		
		#Socket Scanner height
		scanner_height_socket = attributes_storage_025.interface.new_socket(name = "Scanner height", in_out='INPUT', socket_type = 'NodeSocketFloat')
		scanner_height_socket.default_value = 0.0
		scanner_height_socket.min_value = -3.4028234663852886e+38
		scanner_height_socket.max_value = 3.4028234663852886e+38
		scanner_height_socket.subtype = 'NONE'
		scanner_height_socket.attribute_domain = 'POINT'
		
		#Socket Color
		color_socket = attributes_storage_025.interface.new_socket(name = "Color", in_out='INPUT', socket_type = 'NodeSocketColor')
		color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
		color_socket.attribute_domain = 'POINT'
		
		#Socket Hit distance
		hit_distance_socket_3 = attributes_storage_025.interface.new_socket(name = "Hit distance", in_out='INPUT', socket_type = 'NodeSocketFloat')
		hit_distance_socket_3.default_value = 0.0
		hit_distance_socket_3.min_value = -3.4028234663852886e+38
		hit_distance_socket_3.max_value = 3.4028234663852886e+38
		hit_distance_socket_3.subtype = 'NONE'
		hit_distance_socket_3.attribute_domain = 'POINT'
		
		#Socket Enable point size
		enable_point_size_socket = attributes_storage_025.interface.new_socket(name = "Enable point size", in_out='INPUT', socket_type = 'NodeSocketBool')
		enable_point_size_socket.default_value = False
		enable_point_size_socket.attribute_domain = 'POINT'
		
		
		#initialize attributes_storage_025 nodes
		#node Group Output
		group_output_8 = attributes_storage_025.nodes.new("NodeGroupOutput")
		group_output_8.name = "Group Output"
		group_output_8.is_active_output = True
		
		#node Group Input
		group_input_7 = attributes_storage_025.nodes.new("NodeGroupInput")
		group_input_7.name = "Group Input"
		
		#node Store Named Attribute
		store_named_attribute = attributes_storage_025.nodes.new("GeometryNodeStoreNamedAttribute")
		store_named_attribute.name = "Store Named Attribute"
		store_named_attribute.data_type = 'FLOAT_COLOR'
		store_named_attribute.domain = 'POINT'
		#Selection
		store_named_attribute.inputs[1].default_value = True
		#Name
		store_named_attribute.inputs[2].default_value = "color"
		
		#node Store Named Attribute.001
		store_named_attribute_001 = attributes_storage_025.nodes.new("GeometryNodeStoreNamedAttribute")
		store_named_attribute_001.name = "Store Named Attribute.001"
		store_named_attribute_001.data_type = 'FLOAT'
		store_named_attribute_001.domain = 'POINT'
		#Selection
		store_named_attribute_001.inputs[1].default_value = True
		#Name
		store_named_attribute_001.inputs[2].default_value = "distance"
		
		#node Store Named Attribute.002
		store_named_attribute_002 = attributes_storage_025.nodes.new("GeometryNodeStoreNamedAttribute")
		store_named_attribute_002.name = "Store Named Attribute.002"
		store_named_attribute_002.data_type = 'FLOAT'
		store_named_attribute_002.domain = 'POINT'
		#Selection
		store_named_attribute_002.inputs[1].default_value = True
		#Name
		store_named_attribute_002.inputs[2].default_value = "hit_distance"
		
		#node Store Named Attribute.003
		store_named_attribute_003 = attributes_storage_025.nodes.new("GeometryNodeStoreNamedAttribute")
		store_named_attribute_003.name = "Store Named Attribute.003"
		store_named_attribute_003.data_type = 'FLOAT_VECTOR'
		store_named_attribute_003.domain = 'POINT'
		#Selection
		store_named_attribute_003.inputs[1].default_value = True
		#Name
		store_named_attribute_003.inputs[2].default_value = "point_coordinates"
		
		#node Position
		position_1 = attributes_storage_025.nodes.new("GeometryNodeInputPosition")
		position_1.name = "Position"
		
		#node Store Named Attribute.004
		store_named_attribute_004 = attributes_storage_025.nodes.new("GeometryNodeStoreNamedAttribute")
		store_named_attribute_004.name = "Store Named Attribute.004"
		store_named_attribute_004.data_type = 'BOOLEAN'
		store_named_attribute_004.domain = 'POINT'
		#Selection
		store_named_attribute_004.inputs[1].default_value = True
		#Name
		store_named_attribute_004.inputs[2].default_value = "point_cloud_activate"
		
		#node Reroute
		reroute_4 = attributes_storage_025.nodes.new("NodeReroute")
		reroute_4.name = "Reroute"
		#node Reroute.001
		reroute_001_3 = attributes_storage_025.nodes.new("NodeReroute")
		reroute_001_3.name = "Reroute.001"
		#node Reroute.002
		reroute_002_2 = attributes_storage_025.nodes.new("NodeReroute")
		reroute_002_2.name = "Reroute.002"
		#node Reroute.003
		reroute_003_2 = attributes_storage_025.nodes.new("NodeReroute")
		reroute_003_2.name = "Reroute.003"
		#node Reroute.004
		reroute_004_1 = attributes_storage_025.nodes.new("NodeReroute")
		reroute_004_1.name = "Reroute.004"
		#node Reroute.005
		reroute_005_1 = attributes_storage_025.nodes.new("NodeReroute")
		reroute_005_1.name = "Reroute.005"
		
		
		
		#Set locations
		group_output_8.location = (663.4078369140625, 14.384516716003418)
		group_input_7.location = (-661.1233520507812, -55.48540115356445)
		store_named_attribute.location = (-155.03089904785156, -12.098981857299805)
		store_named_attribute_001.location = (116.40339660644531, 0.5612942576408386)
		store_named_attribute_002.location = (300.146484375, 3.5042591094970703)
		store_named_attribute_003.location = (484.875732421875, 14.555829048156738)
		position_1.location = (302.0515441894531, -204.64739990234375)
		store_named_attribute_004.location = (-441.6122131347656, -12.404535293579102)
		reroute_4.location = (-428.0332946777344, -270.88824462890625)
		reroute_001_3.location = (-435.9966735839844, -228.3959197998047)
		reroute_002_2.location = (-430.68768310546875, 25.229772567749023)
		reroute_003_2.location = (-224.9663543701172, -227.0680694580078)
		reroute_004_1.location = (61.7164306640625, -253.6258087158203)
		reroute_005_1.location = (259.47430419921875, 21.246166229248047)
		
		#Set dimensions
		group_output_8.width, group_output_8.height = 140.0, 100.0
		group_input_7.width, group_input_7.height = 140.0, 100.0
		store_named_attribute.width, store_named_attribute.height = 215.97225952148438, 100.0
		store_named_attribute_001.width, store_named_attribute_001.height = 140.0, 100.0
		store_named_attribute_002.width, store_named_attribute_002.height = 140.0, 100.0
		store_named_attribute_003.width, store_named_attribute_003.height = 140.0, 100.0
		position_1.width, position_1.height = 140.0, 100.0
		store_named_attribute_004.width, store_named_attribute_004.height = 215.97225952148438, 100.0
		reroute_4.width, reroute_4.height = 100.0, 100.0
		reroute_001_3.width, reroute_001_3.height = 100.0, 100.0
		reroute_002_2.width, reroute_002_2.height = 100.0, 100.0
		reroute_003_2.width, reroute_003_2.height = 100.0, 100.0
		reroute_004_1.width, reroute_004_1.height = 100.0, 100.0
		reroute_005_1.width, reroute_005_1.height = 100.0, 100.0
		
		#initialize attributes_storage_025 links
		#store_named_attribute.Geometry -> store_named_attribute_001.Geometry
		attributes_storage_025.links.new(store_named_attribute.outputs[0], store_named_attribute_001.inputs[0])
		#store_named_attribute_001.Geometry -> store_named_attribute_002.Geometry
		attributes_storage_025.links.new(store_named_attribute_001.outputs[0], store_named_attribute_002.inputs[0])
		#store_named_attribute_004.Geometry -> store_named_attribute.Geometry
		attributes_storage_025.links.new(store_named_attribute_004.outputs[0], store_named_attribute.inputs[0])
		#reroute_003_2.Output -> store_named_attribute.Value
		attributes_storage_025.links.new(reroute_003_2.outputs[0], store_named_attribute.inputs[3])
		#reroute_005_1.Output -> store_named_attribute_002.Value
		attributes_storage_025.links.new(reroute_005_1.outputs[0], store_named_attribute_002.inputs[3])
		#reroute_004_1.Output -> store_named_attribute_001.Value
		attributes_storage_025.links.new(reroute_004_1.outputs[0], store_named_attribute_001.inputs[3])
		#store_named_attribute_003.Geometry -> group_output_8.Geometry
		attributes_storage_025.links.new(store_named_attribute_003.outputs[0], group_output_8.inputs[0])
		#store_named_attribute_002.Geometry -> store_named_attribute_003.Geometry
		attributes_storage_025.links.new(store_named_attribute_002.outputs[0], store_named_attribute_003.inputs[0])
		#position_1.Position -> store_named_attribute_003.Value
		attributes_storage_025.links.new(position_1.outputs[0], store_named_attribute_003.inputs[3])
		#group_input_7.Geometry -> store_named_attribute_004.Geometry
		attributes_storage_025.links.new(group_input_7.outputs[0], store_named_attribute_004.inputs[0])
		#group_input_7.Enable point size -> store_named_attribute_004.Value
		attributes_storage_025.links.new(group_input_7.outputs[4], store_named_attribute_004.inputs[3])
		#group_input_7.Hit distance -> reroute_4.Input
		attributes_storage_025.links.new(group_input_7.outputs[3], reroute_4.inputs[0])
		#group_input_7.Color -> reroute_001_3.Input
		attributes_storage_025.links.new(group_input_7.outputs[2], reroute_001_3.inputs[0])
		#group_input_7.Scanner height -> reroute_002_2.Input
		attributes_storage_025.links.new(group_input_7.outputs[1], reroute_002_2.inputs[0])
		#reroute_001_3.Output -> reroute_003_2.Input
		attributes_storage_025.links.new(reroute_001_3.outputs[0], reroute_003_2.inputs[0])
		#reroute_4.Output -> reroute_004_1.Input
		attributes_storage_025.links.new(reroute_4.outputs[0], reroute_004_1.inputs[0])
		#reroute_002_2.Output -> reroute_005_1.Input
		attributes_storage_025.links.new(reroute_002_2.outputs[0], reroute_005_1.inputs[0])
		return attributes_storage_025

	attributes_storage_025 = attributes_storage_025_node_group()

	#initialize raycast_group_025 node group
	def raycast_group_025_node_group():
		raycast_group_025 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Raycast Group.025")

		raycast_group_025.color_tag = 'CONVERTER'
		raycast_group_025.description = ""

		
		#raycast_group_025 interface
		#Socket Geometry
		geometry_socket_9 = raycast_group_025.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_9.attribute_domain = 'POINT'
		
		#Socket Normal
		normal_socket_2 = raycast_group_025.interface.new_socket(name = "Normal", in_out='OUTPUT', socket_type = 'NodeSocketVector')
		normal_socket_2.default_value = (0.0, 0.0, 0.0)
		normal_socket_2.min_value = -3.4028234663852886e+38
		normal_socket_2.max_value = 3.4028234663852886e+38
		normal_socket_2.subtype = 'NONE'
		normal_socket_2.attribute_domain = 'POINT'
		
		#Socket Is Hit
		is_hit_socket = raycast_group_025.interface.new_socket(name = "Is Hit", in_out='OUTPUT', socket_type = 'NodeSocketBool')
		is_hit_socket.default_value = False
		is_hit_socket.attribute_domain = 'POINT'
		
		#Socket Hit Position
		hit_position_socket = raycast_group_025.interface.new_socket(name = "Hit Position", in_out='OUTPUT', socket_type = 'NodeSocketVector')
		hit_position_socket.default_value = (0.0, 0.0, 0.0)
		hit_position_socket.min_value = -3.4028234663852886e+38
		hit_position_socket.max_value = 3.4028234663852886e+38
		hit_position_socket.subtype = 'NONE'
		hit_position_socket.attribute_domain = 'POINT'
		
		#Socket Hit Distance
		hit_distance_socket_4 = raycast_group_025.interface.new_socket(name = "Hit Distance", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
		hit_distance_socket_4.default_value = 0.0
		hit_distance_socket_4.min_value = -3.4028234663852886e+38
		hit_distance_socket_4.max_value = 3.4028234663852886e+38
		hit_distance_socket_4.subtype = 'NONE'
		hit_distance_socket_4.attribute_domain = 'POINT'
		
		#Socket Is Hit
		is_hit_socket_1 = raycast_group_025.interface.new_socket(name = "Is Hit", in_out='OUTPUT', socket_type = 'NodeSocketBool')
		is_hit_socket_1.default_value = False
		is_hit_socket_1.attribute_domain = 'POINT'
		
		#Socket Hit Distance
		hit_distance_socket_5 = raycast_group_025.interface.new_socket(name = "Hit Distance", in_out='OUTPUT', socket_type = 'NodeSocketFloat')
		hit_distance_socket_5.default_value = 0.0
		hit_distance_socket_5.min_value = -3.4028234663852886e+38
		hit_distance_socket_5.max_value = 3.4028234663852886e+38
		hit_distance_socket_5.subtype = 'NONE'
		hit_distance_socket_5.attribute_domain = 'POINT'
		
		#Socket Object
		object_socket = raycast_group_025.interface.new_socket(name = "Object", in_out='INPUT', socket_type = 'NodeSocketObject')
		object_socket.attribute_domain = 'POINT'
		
		#Socket Ray Length
		ray_length_socket = raycast_group_025.interface.new_socket(name = "Ray Length", in_out='INPUT', socket_type = 'NodeSocketFloat')
		ray_length_socket.default_value = 100.0
		ray_length_socket.min_value = 0.0
		ray_length_socket.max_value = 3.4028234663852886e+38
		ray_length_socket.subtype = 'DISTANCE'
		ray_length_socket.attribute_domain = 'POINT'
		
		#Socket Scanner Height
		scanner_height_socket_1 = raycast_group_025.interface.new_socket(name = "Scanner Height", in_out='INPUT', socket_type = 'NodeSocketFloat')
		scanner_height_socket_1.default_value = 0.0
		scanner_height_socket_1.min_value = -3.4028234663852886e+38
		scanner_height_socket_1.max_value = 3.4028234663852886e+38
		scanner_height_socket_1.subtype = 'NONE'
		scanner_height_socket_1.attribute_domain = 'POINT'
		
		
		#initialize raycast_group_025 nodes
		#node Group Output
		group_output_9 = raycast_group_025.nodes.new("NodeGroupOutput")
		group_output_9.name = "Group Output"
		group_output_9.is_active_output = True
		
		#node Group Input
		group_input_8 = raycast_group_025.nodes.new("NodeGroupInput")
		group_input_8.name = "Group Input"
		
		#node Object Info
		object_info_1 = raycast_group_025.nodes.new("GeometryNodeObjectInfo")
		object_info_1.name = "Object Info"
		object_info_1.transform_space = 'RELATIVE'
		#As Instance
		object_info_1.inputs[1].default_value = False
		
		#node Vector
		vector_1 = raycast_group_025.nodes.new("FunctionNodeInputVector")
		vector_1.name = "Vector"
		vector_1.vector = (0.0, 0.0, 0.0)
		
		#node Raycast
		raycast = raycast_group_025.nodes.new("GeometryNodeRaycast")
		raycast.name = "Raycast"
		raycast.data_type = 'FLOAT'
		raycast.mapping = 'INTERPOLATED'
		
		#node Raycast.001
		raycast_001 = raycast_group_025.nodes.new("GeometryNodeRaycast")
		raycast_001.name = "Raycast.001"
		raycast_001.data_type = 'FLOAT'
		raycast_001.mapping = 'NEAREST'
		#Attribute
		raycast_001.inputs[1].default_value = 0.0
		
		#node Vector.001
		vector_001 = raycast_group_025.nodes.new("FunctionNodeInputVector")
		vector_001.name = "Vector.001"
		vector_001.vector = (0.0, 0.0, -1.0)
		
		#node Position
		position_2 = raycast_group_025.nodes.new("GeometryNodeInputPosition")
		position_2.name = "Position"
		position_2.hide = True
		
		#node Frame
		frame_2 = raycast_group_025.nodes.new("NodeFrame")
		frame_2.label = "RAYCASTING"
		frame_2.name = "Frame"
		frame_2.label_size = 37
		frame_2.shrink = True
		
		#node Math
		math_3 = raycast_group_025.nodes.new("ShaderNodeMath")
		math_3.name = "Math"
		math_3.operation = 'ADD'
		math_3.use_clamp = False
		
		#node Vector Math
		vector_math_1 = raycast_group_025.nodes.new("ShaderNodeVectorMath")
		vector_math_1.name = "Vector Math"
		vector_math_1.hide = True
		vector_math_1.operation = 'NORMALIZE'
		
		#node Reroute
		reroute_5 = raycast_group_025.nodes.new("NodeReroute")
		reroute_5.name = "Reroute"
		#node Normal
		normal = raycast_group_025.nodes.new("GeometryNodeInputNormal")
		normal.name = "Normal"
		
		
		
		
		#Set locations
		group_output_9.location = (419.30859375, 361.034912109375)
		group_input_8.location = (-468.45855712890625, 65.83087921142578)
		object_info_1.location = (-235.4115753173828, 460.255859375)
		vector_1.location = (-217.26748657226562, -44.752037048339844)
		raycast.location = (99.18263244628906, 299.07476806640625)
		raycast_001.location = (104.05245208740234, -22.58469009399414)
		vector_001.location = (-222.1340789794922, -245.64535522460938)
		position_2.location = (-297.3208923339844, 86.49778747558594)
		frame_2.location = (38.3643798828125, 405.7378845214844)
		math_3.location = (-219.79428100585938, -383.43695068359375)
		vector_math_1.location = (-136.34609985351562, 85.71537780761719)
		reroute_5.location = (19.408300399780273, 310.41351318359375)
		normal.location = (909.4095458984375, 568.904296875)
		
		#Set dimensions
		group_output_9.width, group_output_9.height = 140.0, 100.0
		group_input_8.width, group_input_8.height = 140.0, 100.0
		object_info_1.width, object_info_1.height = 140.0, 100.0
		vector_1.width, vector_1.height = 140.0, 100.0
		raycast.width, raycast.height = 150.0, 100.0
		raycast_001.width, raycast_001.height = 150.0, 100.0
		vector_001.width, vector_001.height = 140.0, 100.0
		position_2.width, position_2.height = 140.0, 100.0
		frame_2.width, frame_2.height = 301.1312255859375, 746.3209228515625
		math_3.width, math_3.height = 140.0, 100.0
		vector_math_1.width, vector_math_1.height = 140.0, 100.0
		reroute_5.width, reroute_5.height = 16.0, 100.0
		normal.width, normal.height = 140.0, 100.0
		
		#initialize raycast_group_025 links
		#vector_1.Vector -> raycast_001.Source Position
		raycast_group_025.links.new(vector_1.outputs[0], raycast_001.inputs[2])
		#object_info_1.Geometry -> raycast.Target Geometry
		raycast_group_025.links.new(object_info_1.outputs[4], raycast.inputs[0])
		#object_info_1.Geometry -> raycast_001.Target Geometry
		raycast_group_025.links.new(object_info_1.outputs[4], raycast_001.inputs[0])
		#vector_1.Vector -> raycast.Source Position
		raycast_group_025.links.new(vector_1.outputs[0], raycast.inputs[2])
		#group_input_8.Object -> object_info_1.Object
		raycast_group_025.links.new(group_input_8.outputs[0], object_info_1.inputs[0])
		#group_input_8.Ray Length -> raycast.Ray Length
		raycast_group_025.links.new(group_input_8.outputs[1], raycast.inputs[4])
		#object_info_1.Geometry -> group_output_9.Geometry
		raycast_group_025.links.new(object_info_1.outputs[4], group_output_9.inputs[0])
		#raycast.Is Hit -> group_output_9.Is Hit
		raycast_group_025.links.new(raycast.outputs[0], group_output_9.inputs[2])
		#raycast.Hit Position -> group_output_9.Hit Position
		raycast_group_025.links.new(raycast.outputs[1], group_output_9.inputs[3])
		#raycast.Hit Distance -> group_output_9.Hit Distance
		raycast_group_025.links.new(raycast.outputs[3], group_output_9.inputs[4])
		#raycast_001.Is Hit -> group_output_9.Is Hit
		raycast_group_025.links.new(raycast_001.outputs[0], group_output_9.inputs[5])
		#raycast_001.Hit Distance -> group_output_9.Hit Distance
		raycast_group_025.links.new(raycast_001.outputs[3], group_output_9.inputs[6])
		#vector_math_1.Vector -> raycast.Ray Direction
		raycast_group_025.links.new(vector_math_1.outputs[0], raycast.inputs[3])
		#vector_001.Vector -> raycast_001.Ray Direction
		raycast_group_025.links.new(vector_001.outputs[0], raycast_001.inputs[3])
		#group_input_8.Ray Length -> math_3.Value
		raycast_group_025.links.new(group_input_8.outputs[1], math_3.inputs[0])
		#group_input_8.Scanner Height -> math_3.Value
		raycast_group_025.links.new(group_input_8.outputs[2], math_3.inputs[1])
		#math_3.Value -> raycast_001.Ray Length
		raycast_group_025.links.new(math_3.outputs[0], raycast_001.inputs[4])
		#position_2.Position -> vector_math_1.Vector
		raycast_group_025.links.new(position_2.outputs[0], vector_math_1.inputs[0])
		#vector_math_1.Vector -> raycast.Attribute
		raycast_group_025.links.new(vector_math_1.outputs[0], raycast.inputs[1])
		#reroute_5.Output -> group_output_9.Normal
		raycast_group_025.links.new(reroute_5.outputs[0], group_output_9.inputs[1])
		#vector_math_1.Vector -> reroute_5.Input
		raycast_group_025.links.new(vector_math_1.outputs[0], reroute_5.inputs[0])
		return raycast_group_025

	raycast_group_025 = raycast_group_025_node_group()

	#initialize filter_long_edges_018 node group
	def filter_long_edges_018_node_group():
		filter_long_edges_018 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Filter long edges.018")

		filter_long_edges_018.color_tag = 'NONE'
		filter_long_edges_018.description = ""

		
		#filter_long_edges_018 interface
		#Socket Geometry
		geometry_socket_10 = filter_long_edges_018.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_10.attribute_domain = 'POINT'
		
		#Socket Geometry
		geometry_socket_11 = filter_long_edges_018.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_11.attribute_domain = 'POINT'
		
		#Socket filter long edges
		filter_long_edges_socket = filter_long_edges_018.interface.new_socket(name = "filter long edges", in_out='INPUT', socket_type = 'NodeSocketFloat')
		filter_long_edges_socket.default_value = 0.5
		filter_long_edges_socket.min_value = -10000.0
		filter_long_edges_socket.max_value = 10000.0
		filter_long_edges_socket.subtype = 'NONE'
		filter_long_edges_socket.attribute_domain = 'POINT'
		
		
		#initialize filter_long_edges_018 nodes
		#node Group Output
		group_output_10 = filter_long_edges_018.nodes.new("NodeGroupOutput")
		group_output_10.name = "Group Output"
		group_output_10.is_active_output = True
		
		#node Group Input
		group_input_9 = filter_long_edges_018.nodes.new("NodeGroupInput")
		group_input_9.name = "Group Input"
		
		#node Edge Vertices
		edge_vertices = filter_long_edges_018.nodes.new("GeometryNodeInputMeshEdgeVertices")
		edge_vertices.name = "Edge Vertices"
		
		#node Math.002
		math_002_2 = filter_long_edges_018.nodes.new("ShaderNodeMath")
		math_002_2.name = "Math.002"
		math_002_2.operation = 'SQRT'
		math_002_2.use_clamp = False
		
		#node Compare
		compare_1 = filter_long_edges_018.nodes.new("FunctionNodeCompare")
		compare_1.name = "Compare"
		compare_1.data_type = 'FLOAT'
		compare_1.mode = 'ELEMENT'
		compare_1.operation = 'GREATER_THAN'
		
		#node Delete Geometry
		delete_geometry_1 = filter_long_edges_018.nodes.new("GeometryNodeDeleteGeometry")
		delete_geometry_1.name = "Delete Geometry"
		delete_geometry_1.domain = 'EDGE'
		delete_geometry_1.mode = 'ALL'
		
		#node Attribute Statistic
		attribute_statistic_1 = filter_long_edges_018.nodes.new("GeometryNodeAttributeStatistic")
		attribute_statistic_1.name = "Attribute Statistic"
		attribute_statistic_1.data_type = 'FLOAT'
		attribute_statistic_1.domain = 'EDGE'
		#Selection
		attribute_statistic_1.inputs[1].default_value = True
		
		#node Store Named Attribute
		store_named_attribute_1 = filter_long_edges_018.nodes.new("GeometryNodeStoreNamedAttribute")
		store_named_attribute_1.name = "Store Named Attribute"
		store_named_attribute_1.data_type = 'FLOAT'
		store_named_attribute_1.domain = 'EDGE'
		#Selection
		store_named_attribute_1.inputs[1].default_value = True
		
		#node String
		string = filter_long_edges_018.nodes.new("FunctionNodeInputString")
		string.name = "String"
		string.string = "edgeslengths"
		
		#node Named Attribute
		named_attribute_1 = filter_long_edges_018.nodes.new("GeometryNodeInputNamedAttribute")
		named_attribute_1.name = "Named Attribute"
		named_attribute_1.data_type = 'FLOAT'
		
		#node Math.003
		math_003_2 = filter_long_edges_018.nodes.new("ShaderNodeMath")
		math_003_2.name = "Math.003"
		math_003_2.operation = 'MULTIPLY'
		math_003_2.use_clamp = False
		
		#node Vector Math
		vector_math_2 = filter_long_edges_018.nodes.new("ShaderNodeVectorMath")
		vector_math_2.name = "Vector Math"
		vector_math_2.operation = 'SUBTRACT'
		
		#node Vector Math.001
		vector_math_001_2 = filter_long_edges_018.nodes.new("ShaderNodeVectorMath")
		vector_math_001_2.name = "Vector Math.001"
		vector_math_001_2.operation = 'DOT_PRODUCT'
		
		#node Reroute
		reroute_6 = filter_long_edges_018.nodes.new("NodeReroute")
		reroute_6.name = "Reroute"
		#node Reroute.001
		reroute_001_4 = filter_long_edges_018.nodes.new("NodeReroute")
		reroute_001_4.name = "Reroute.001"
		
		
		
		#Set locations
		group_output_10.location = (502.9207458496094, 183.5653076171875)
		group_input_9.location = (-1201.4833984375, -105.70333099365234)
		edge_vertices.location = (-1161.968505859375, -309.76519775390625)
		math_002_2.location = (-660.0365600585938, -166.90835571289062)
		compare_1.location = (159.7508544921875, 54.67945098876953)
		delete_geometry_1.location = (327.7901611328125, 183.2783203125)
		attribute_statistic_1.location = (-220.5529327392578, -154.30894470214844)
		store_named_attribute_1.location = (-423.0304260253906, 58.29344940185547)
		string.location = (-659.8743896484375, -344.43792724609375)
		named_attribute_1.location = (-420.3539123535156, -418.92999267578125)
		math_003_2.location = (4.119769096374512, -82.02665710449219)
		vector_math_2.location = (-1002.4909057617188, -300.65594482421875)
		vector_math_001_2.location = (-827.6976318359375, -241.72412109375)
		reroute_6.location = (-33.535194396972656, -137.86866760253906)
		reroute_001_4.location = (-676.257080078125, 71.01051330566406)
		
		#Set dimensions
		group_output_10.width, group_output_10.height = 140.0, 100.0
		group_input_9.width, group_input_9.height = 140.0, 100.0
		edge_vertices.width, edge_vertices.height = 140.0, 100.0
		math_002_2.width, math_002_2.height = 140.0, 100.0
		compare_1.width, compare_1.height = 140.0, 100.0
		delete_geometry_1.width, delete_geometry_1.height = 140.0, 100.0
		attribute_statistic_1.width, attribute_statistic_1.height = 140.0, 100.0
		store_named_attribute_1.width, store_named_attribute_1.height = 140.0, 100.0
		string.width, string.height = 140.0, 100.0
		named_attribute_1.width, named_attribute_1.height = 140.0, 100.0
		math_003_2.width, math_003_2.height = 140.0, 100.0
		vector_math_2.width, vector_math_2.height = 140.0, 100.0
		vector_math_001_2.width, vector_math_001_2.height = 147.49395751953125, 100.0
		reroute_6.width, reroute_6.height = 100.0, 100.0
		reroute_001_4.width, reroute_001_4.height = 100.0, 100.0
		
		#initialize filter_long_edges_018 links
		#edge_vertices.Position 2 -> vector_math_2.Vector
		filter_long_edges_018.links.new(edge_vertices.outputs[3], vector_math_2.inputs[1])
		#math_002_2.Value -> store_named_attribute_1.Value
		filter_long_edges_018.links.new(math_002_2.outputs[0], store_named_attribute_1.inputs[3])
		#math_003_2.Value -> compare_1.B
		filter_long_edges_018.links.new(math_003_2.outputs[0], compare_1.inputs[1])
		#edge_vertices.Position 1 -> vector_math_2.Vector
		filter_long_edges_018.links.new(edge_vertices.outputs[2], vector_math_2.inputs[0])
		#attribute_statistic_1.Mean -> math_003_2.Value
		filter_long_edges_018.links.new(attribute_statistic_1.outputs[0], math_003_2.inputs[0])
		#vector_math_001_2.Value -> math_002_2.Value
		filter_long_edges_018.links.new(vector_math_001_2.outputs[1], math_002_2.inputs[0])
		#math_002_2.Value -> compare_1.A
		filter_long_edges_018.links.new(math_002_2.outputs[0], compare_1.inputs[0])
		#vector_math_2.Vector -> vector_math_001_2.Vector
		filter_long_edges_018.links.new(vector_math_2.outputs[0], vector_math_001_2.inputs[0])
		#string.String -> named_attribute_1.Name
		filter_long_edges_018.links.new(string.outputs[0], named_attribute_1.inputs[0])
		#vector_math_2.Vector -> vector_math_001_2.Vector
		filter_long_edges_018.links.new(vector_math_2.outputs[0], vector_math_001_2.inputs[1])
		#named_attribute_1.Attribute -> attribute_statistic_1.Attribute
		filter_long_edges_018.links.new(named_attribute_1.outputs[0], attribute_statistic_1.inputs[2])
		#compare_1.Result -> delete_geometry_1.Selection
		filter_long_edges_018.links.new(compare_1.outputs[0], delete_geometry_1.inputs[1])
		#string.String -> store_named_attribute_1.Name
		filter_long_edges_018.links.new(string.outputs[0], store_named_attribute_1.inputs[2])
		#store_named_attribute_1.Geometry -> attribute_statistic_1.Geometry
		filter_long_edges_018.links.new(store_named_attribute_1.outputs[0], attribute_statistic_1.inputs[0])
		#reroute_6.Output -> math_003_2.Value
		filter_long_edges_018.links.new(reroute_6.outputs[0], math_003_2.inputs[1])
		#reroute_001_4.Output -> delete_geometry_1.Geometry
		filter_long_edges_018.links.new(reroute_001_4.outputs[0], delete_geometry_1.inputs[0])
		#group_input_9.Geometry -> store_named_attribute_1.Geometry
		filter_long_edges_018.links.new(group_input_9.outputs[0], store_named_attribute_1.inputs[0])
		#delete_geometry_1.Geometry -> group_output_10.Geometry
		filter_long_edges_018.links.new(delete_geometry_1.outputs[0], group_output_10.inputs[0])
		#group_input_9.filter long edges -> reroute_6.Input
		filter_long_edges_018.links.new(group_input_9.outputs[1], reroute_6.inputs[0])
		#group_input_9.Geometry -> reroute_001_4.Input
		filter_long_edges_018.links.new(group_input_9.outputs[0], reroute_001_4.inputs[0])
		return filter_long_edges_018

	filter_long_edges_018 = filter_long_edges_018_node_group()

	#initialize sparse_points_018 node group
	def sparse_points_018_node_group():
		sparse_points_018 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Sparse points.018")

		sparse_points_018.color_tag = 'NONE'
		sparse_points_018.description = ""

		
		#sparse_points_018 interface
		#Socket Geometry
		geometry_socket_12 = sparse_points_018.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_12.attribute_domain = 'POINT'
		
		#Socket Mesh
		mesh_socket_1 = sparse_points_018.interface.new_socket(name = "Mesh", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		mesh_socket_1.attribute_domain = 'POINT'
		
		#Socket Density
		density_socket = sparse_points_018.interface.new_socket(name = "Density", in_out='INPUT', socket_type = 'NodeSocketFloat')
		density_socket.default_value = 10.0
		density_socket.min_value = 0.0
		density_socket.max_value = 3.4028234663852886e+38
		density_socket.subtype = 'NONE'
		density_socket.attribute_domain = 'POINT'
		
		#Socket Seed
		seed_socket_2 = sparse_points_018.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt')
		seed_socket_2.default_value = 0
		seed_socket_2.min_value = -2147483648
		seed_socket_2.max_value = 2147483647
		seed_socket_2.subtype = 'NONE'
		seed_socket_2.attribute_domain = 'POINT'
		
		#Socket Radius
		radius_socket_2 = sparse_points_018.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat')
		radius_socket_2.default_value = 1.0
		radius_socket_2.min_value = 0.0
		radius_socket_2.max_value = 3.4028234663852886e+38
		radius_socket_2.subtype = 'DISTANCE'
		radius_socket_2.attribute_domain = 'POINT'
		
		
		#initialize sparse_points_018 nodes
		#node Group Output
		group_output_11 = sparse_points_018.nodes.new("NodeGroupOutput")
		group_output_11.name = "Group Output"
		group_output_11.is_active_output = True
		
		#node Group Input
		group_input_10 = sparse_points_018.nodes.new("NodeGroupInput")
		group_input_10.name = "Group Input"
		
		#node Distribute Points on Faces
		distribute_points_on_faces = sparse_points_018.nodes.new("GeometryNodeDistributePointsOnFaces")
		distribute_points_on_faces.name = "Distribute Points on Faces"
		distribute_points_on_faces.distribute_method = 'RANDOM'
		distribute_points_on_faces.use_legacy_normal = False
		#Selection
		distribute_points_on_faces.inputs[1].default_value = True
		
		#node UV Sphere.002
		uv_sphere_002 = sparse_points_018.nodes.new("GeometryNodeMeshUVSphere")
		uv_sphere_002.name = "UV Sphere.002"
		#Segments
		uv_sphere_002.inputs[0].default_value = 3
		#Rings
		uv_sphere_002.inputs[1].default_value = 2
		
		#node Instance on Points.001
		instance_on_points_001 = sparse_points_018.nodes.new("GeometryNodeInstanceOnPoints")
		instance_on_points_001.name = "Instance on Points.001"
		#Selection
		instance_on_points_001.inputs[1].default_value = True
		#Pick Instance
		instance_on_points_001.inputs[3].default_value = False
		#Instance Index
		instance_on_points_001.inputs[4].default_value = 0
		#Rotation
		instance_on_points_001.inputs[5].default_value = (0.0, 0.0, 0.0)
		#Scale
		instance_on_points_001.inputs[6].default_value = (1.0, 1.0, 1.0)
		
		#node Realize Instances.001
		realize_instances_001_1 = sparse_points_018.nodes.new("GeometryNodeRealizeInstances")
		realize_instances_001_1.name = "Realize Instances.001"
		#Selection
		realize_instances_001_1.inputs[1].default_value = True
		#Realize All
		realize_instances_001_1.inputs[2].default_value = True
		#Depth
		realize_instances_001_1.inputs[3].default_value = 0
		
		
		
		
		#Set locations
		group_output_11.location = (396.067138671875, -32.04473876953125)
		group_input_10.location = (-340.0479431152344, 20.92717742919922)
		distribute_points_on_faces.location = (-144.15103149414062, 114.72419738769531)
		uv_sphere_002.location = (-127.62850189208984, -123.22586822509766)
		instance_on_points_001.location = (69.95654296875, -56.486663818359375)
		realize_instances_001_1.location = (234.82797241210938, -32.31230926513672)
		
		#Set dimensions
		group_output_11.width, group_output_11.height = 140.0, 100.0
		group_input_10.width, group_input_10.height = 140.0, 100.0
		distribute_points_on_faces.width, distribute_points_on_faces.height = 170.0, 100.0
		uv_sphere_002.width, uv_sphere_002.height = 140.0, 100.0
		instance_on_points_001.width, instance_on_points_001.height = 140.0, 100.0
		realize_instances_001_1.width, realize_instances_001_1.height = 140.0, 100.0
		
		#initialize sparse_points_018 links
		#uv_sphere_002.Mesh -> instance_on_points_001.Instance
		sparse_points_018.links.new(uv_sphere_002.outputs[0], instance_on_points_001.inputs[2])
		#instance_on_points_001.Instances -> realize_instances_001_1.Geometry
		sparse_points_018.links.new(instance_on_points_001.outputs[0], realize_instances_001_1.inputs[0])
		#distribute_points_on_faces.Points -> instance_on_points_001.Points
		sparse_points_018.links.new(distribute_points_on_faces.outputs[0], instance_on_points_001.inputs[0])
		#group_input_10.Radius -> uv_sphere_002.Radius
		sparse_points_018.links.new(group_input_10.outputs[3], uv_sphere_002.inputs[2])
		#group_input_10.Mesh -> distribute_points_on_faces.Mesh
		sparse_points_018.links.new(group_input_10.outputs[0], distribute_points_on_faces.inputs[0])
		#group_input_10.Seed -> distribute_points_on_faces.Seed
		sparse_points_018.links.new(group_input_10.outputs[2], distribute_points_on_faces.inputs[6])
		#group_input_10.Density -> distribute_points_on_faces.Density
		sparse_points_018.links.new(group_input_10.outputs[1], distribute_points_on_faces.inputs[4])
		#realize_instances_001_1.Geometry -> group_output_11.Geometry
		sparse_points_018.links.new(realize_instances_001_1.outputs[0], group_output_11.inputs[0])
		return sparse_points_018

	sparse_points_018 = sparse_points_018_node_group()

	#initialize point_representation_017 node group
	def point_representation_017_node_group():
		point_representation_017 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Point representation.017")

		point_representation_017.color_tag = 'NONE'
		point_representation_017.description = ""

		
		#point_representation_017 interface
		#Socket Geometry
		geometry_socket_13 = point_representation_017.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_13.attribute_domain = 'POINT'
		
		#Socket Mesh
		mesh_socket_2 = point_representation_017.interface.new_socket(name = "Mesh", in_out='INPUT', socket_type = 'NodeSocketGeometry')
		mesh_socket_2.attribute_domain = 'POINT'
		
		#Socket Point cloud
		point_cloud_socket = point_representation_017.interface.new_socket(name = "Point cloud", in_out='INPUT', socket_type = 'NodeSocketBool')
		point_cloud_socket.default_value = False
		point_cloud_socket.attribute_domain = 'POINT'
		
		#Socket Point size
		point_size_socket = point_representation_017.interface.new_socket(name = "Point size", in_out='INPUT', socket_type = 'NodeSocketFloat')
		point_size_socket.default_value = 0.0
		point_size_socket.min_value = -3.4028234663852886e+38
		point_size_socket.max_value = 3.4028234663852886e+38
		point_size_socket.subtype = 'NONE'
		point_size_socket.attribute_domain = 'POINT'
		
		#Socket Mesh cloud
		mesh_cloud_socket = point_representation_017.interface.new_socket(name = "Mesh cloud", in_out='INPUT', socket_type = 'NodeSocketBool')
		mesh_cloud_socket.default_value = False
		mesh_cloud_socket.attribute_domain = 'POINT'
		
		#Socket Filter long edges
		filter_long_edges_socket_1 = point_representation_017.interface.new_socket(name = "Filter long edges", in_out='INPUT', socket_type = 'NodeSocketFloat')
		filter_long_edges_socket_1.default_value = 0.0
		filter_long_edges_socket_1.min_value = -3.4028234663852886e+38
		filter_long_edges_socket_1.max_value = 3.4028234663852886e+38
		filter_long_edges_socket_1.subtype = 'NONE'
		filter_long_edges_socket_1.attribute_domain = 'POINT'
		
		#Socket Sparse points
		sparse_points_socket = point_representation_017.interface.new_socket(name = "Sparse points", in_out='INPUT', socket_type = 'NodeSocketBool')
		sparse_points_socket.default_value = False
		sparse_points_socket.attribute_domain = 'POINT'
		
		#Socket Density
		density_socket_1 = point_representation_017.interface.new_socket(name = "Density", in_out='INPUT', socket_type = 'NodeSocketFloat')
		density_socket_1.default_value = 0.0
		density_socket_1.min_value = -3.4028234663852886e+38
		density_socket_1.max_value = 3.4028234663852886e+38
		density_socket_1.subtype = 'NONE'
		density_socket_1.attribute_domain = 'POINT'
		
		#Socket Seed
		seed_socket_3 = point_representation_017.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketFloat')
		seed_socket_3.default_value = 0.0
		seed_socket_3.min_value = -3.4028234663852886e+38
		seed_socket_3.max_value = 3.4028234663852886e+38
		seed_socket_3.subtype = 'NONE'
		seed_socket_3.attribute_domain = 'POINT'
		
		
		#initialize point_representation_017 nodes
		#node Group Output
		group_output_12 = point_representation_017.nodes.new("NodeGroupOutput")
		group_output_12.name = "Group Output"
		group_output_12.is_active_output = True
		
		#node Group Input
		group_input_11 = point_representation_017.nodes.new("NodeGroupInput")
		group_input_11.name = "Group Input"
		
		#node UV Sphere.001
		uv_sphere_001 = point_representation_017.nodes.new("GeometryNodeMeshUVSphere")
		uv_sphere_001.name = "UV Sphere.001"
		#Segments
		uv_sphere_001.inputs[0].default_value = 3
		#Rings
		uv_sphere_001.inputs[1].default_value = 2
		
		#node Mesh to Points.002
		mesh_to_points_002 = point_representation_017.nodes.new("GeometryNodeMeshToPoints")
		mesh_to_points_002.name = "Mesh to Points.002"
		mesh_to_points_002.mode = 'VERTICES'
		#Selection
		mesh_to_points_002.inputs[1].default_value = True
		#Position
		mesh_to_points_002.inputs[2].default_value = (0.0, 0.0, 0.0)
		
		#node Instance on Points
		instance_on_points = point_representation_017.nodes.new("GeometryNodeInstanceOnPoints")
		instance_on_points.name = "Instance on Points"
		#Selection
		instance_on_points.inputs[1].default_value = True
		#Pick Instance
		instance_on_points.inputs[3].default_value = False
		#Instance Index
		instance_on_points.inputs[4].default_value = 0
		#Rotation
		instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
		#Scale
		instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)
		
		#node Realize Instances
		realize_instances_1 = point_representation_017.nodes.new("GeometryNodeRealizeInstances")
		realize_instances_1.name = "Realize Instances"
		#Selection
		realize_instances_1.inputs[1].default_value = True
		#Realize All
		realize_instances_1.inputs[2].default_value = True
		#Depth
		realize_instances_1.inputs[3].default_value = 0
		
		#node Set Material.001
		set_material_001 = point_representation_017.nodes.new("GeometryNodeSetMaterial")
		set_material_001.name = "Set Material.001"
		#Selection
		set_material_001.inputs[1].default_value = True
		if "Points_material" in bpy.data.materials:
			set_material_001.inputs[2].default_value = bpy.data.materials["Points_material"]
		
		#node Switch
		switch = point_representation_017.nodes.new("GeometryNodeSwitch")
		switch.name = "Switch"
		switch.input_type = 'GEOMETRY'
		
		#node Switch.001
		switch_001_1 = point_representation_017.nodes.new("GeometryNodeSwitch")
		switch_001_1.name = "Switch.001"
		switch_001_1.hide = True
		switch_001_1.input_type = 'GEOMETRY'
		
		#node Group
		group_2 = point_representation_017.nodes.new("GeometryNodeGroup")
		group_2.name = "Group"
		group_2.node_tree = filter_long_edges_018
		
		#node Boolean Math
		boolean_math_1 = point_representation_017.nodes.new("FunctionNodeBooleanMath")
		boolean_math_1.name = "Boolean Math"
		boolean_math_1.hide = True
		boolean_math_1.operation = 'OR'
		
		#node Switch.002
		switch_002 = point_representation_017.nodes.new("GeometryNodeSwitch")
		switch_002.name = "Switch.002"
		switch_002.input_type = 'GEOMETRY'
		
		#node Group.001
		group_001_1 = point_representation_017.nodes.new("GeometryNodeGroup")
		group_001_1.name = "Group.001"
		group_001_1.node_tree = sparse_points_018
		
		#node Reroute
		reroute_7 = point_representation_017.nodes.new("NodeReroute")
		reroute_7.name = "Reroute"
		#node Reroute.001
		reroute_001_5 = point_representation_017.nodes.new("NodeReroute")
		reroute_001_5.name = "Reroute.001"
		#node Reroute.002
		reroute_002_3 = point_representation_017.nodes.new("NodeReroute")
		reroute_002_3.name = "Reroute.002"
		#node Reroute.003
		reroute_003_3 = point_representation_017.nodes.new("NodeReroute")
		reroute_003_3.name = "Reroute.003"
		#node Reroute.004
		reroute_004_2 = point_representation_017.nodes.new("NodeReroute")
		reroute_004_2.name = "Reroute.004"
		#node Flip Faces
		flip_faces = point_representation_017.nodes.new("GeometryNodeFlipFaces")
		flip_faces.name = "Flip Faces"
		flip_faces.hide = True
		#Selection
		flip_faces.inputs[1].default_value = True
		
		#node Reroute.005
		reroute_005_2 = point_representation_017.nodes.new("NodeReroute")
		reroute_005_2.name = "Reroute.005"
		
		
		
		#Set locations
		group_output_12.location = (469.10760498046875, 396.643798828125)
		group_input_11.location = (-1331.3475341796875, 246.73638916015625)
		uv_sphere_001.location = (-1131.3861083984375, 501.6838073730469)
		mesh_to_points_002.location = (-962.156494140625, 455.5345458984375)
		instance_on_points.location = (-786.4528198242188, 572.0782470703125)
		realize_instances_1.location = (-610.8919067382812, 598.907470703125)
		set_material_001.location = (306.5623779296875, 397.5404052734375)
		switch.location = (-443.1806335449219, 515.828125)
		switch_001_1.location = (-182.16650390625, 272.6781311035156)
		group_2.location = (-524.306884765625, 298.49981689453125)
		boolean_math_1.location = (-413.20318603515625, 162.11036682128906)
		switch_002.location = (146.36769104003906, 371.976806640625)
		group_001_1.location = (-7.6687774658203125, 178.02064514160156)
		reroute_7.location = (-443.4488525390625, 111.25348663330078)
		reroute_001_5.location = (-1037.176513671875, 209.07533264160156)
		reroute_002_3.location = (-629.302734375, 196.94912719726562)
		reroute_003_3.location = (-798.2232666015625, 232.66336059570312)
		reroute_004_2.location = (-628.834716796875, 234.8502960205078)
		flip_faces.location = (-361.71478271484375, 263.48919677734375)
		reroute_005_2.location = (-1136.6099853515625, 16.380332946777344)
		
		#Set dimensions
		group_output_12.width, group_output_12.height = 140.0, 100.0
		group_input_11.width, group_input_11.height = 140.0, 100.0
		uv_sphere_001.width, uv_sphere_001.height = 140.0, 100.0
		mesh_to_points_002.width, mesh_to_points_002.height = 140.0, 100.0
		instance_on_points.width, instance_on_points.height = 140.0, 100.0
		realize_instances_1.width, realize_instances_1.height = 140.0, 100.0
		set_material_001.width, set_material_001.height = 140.0, 100.0
		switch.width, switch.height = 140.0, 100.0
		switch_001_1.width, switch_001_1.height = 140.0, 100.0
		group_2.width, group_2.height = 140.0, 100.0
		boolean_math_1.width, boolean_math_1.height = 140.0, 100.0
		switch_002.width, switch_002.height = 140.0, 100.0
		group_001_1.width, group_001_1.height = 140.0, 100.0
		reroute_7.width, reroute_7.height = 100.0, 100.0
		reroute_001_5.width, reroute_001_5.height = 100.0, 100.0
		reroute_002_3.width, reroute_002_3.height = 100.0, 100.0
		reroute_003_3.width, reroute_003_3.height = 100.0, 100.0
		reroute_004_2.width, reroute_004_2.height = 100.0, 100.0
		flip_faces.width, flip_faces.height = 140.0, 100.0
		reroute_005_2.width, reroute_005_2.height = 100.0, 100.0
		
		#initialize point_representation_017 links
		#instance_on_points.Instances -> realize_instances_1.Geometry
		point_representation_017.links.new(instance_on_points.outputs[0], realize_instances_1.inputs[0])
		#set_material_001.Geometry -> group_output_12.Geometry
		point_representation_017.links.new(set_material_001.outputs[0], group_output_12.inputs[0])
		#mesh_to_points_002.Points -> instance_on_points.Points
		point_representation_017.links.new(mesh_to_points_002.outputs[0], instance_on_points.inputs[0])
		#switch_002.Output -> set_material_001.Geometry
		point_representation_017.links.new(switch_002.outputs[0], set_material_001.inputs[0])
		#uv_sphere_001.Mesh -> instance_on_points.Instance
		point_representation_017.links.new(uv_sphere_001.outputs[0], instance_on_points.inputs[2])
		#reroute_004_2.Output -> switch.True
		point_representation_017.links.new(reroute_004_2.outputs[0], switch.inputs[2])
		#realize_instances_1.Geometry -> switch.False
		point_representation_017.links.new(realize_instances_1.outputs[0], switch.inputs[1])
		#group_input_11.Point size -> mesh_to_points_002.Radius
		point_representation_017.links.new(group_input_11.outputs[2], mesh_to_points_002.inputs[3])
		#reroute_001_5.Output -> mesh_to_points_002.Mesh
		point_representation_017.links.new(reroute_001_5.outputs[0], mesh_to_points_002.inputs[0])
		#switch.Output -> switch_001_1.False
		point_representation_017.links.new(switch.outputs[0], switch_001_1.inputs[1])
		#boolean_math_1.Boolean -> switch_001_1.Switch
		point_representation_017.links.new(boolean_math_1.outputs[0], switch_001_1.inputs[0])
		#flip_faces.Mesh -> switch_001_1.True
		point_representation_017.links.new(flip_faces.outputs[0], switch_001_1.inputs[2])
		#group_input_11.Filter long edges -> group_2.filter long edges
		point_representation_017.links.new(group_input_11.outputs[4], group_2.inputs[1])
		#group_input_11.Mesh cloud -> boolean_math_1.Boolean
		point_representation_017.links.new(group_input_11.outputs[3], boolean_math_1.inputs[0])
		#reroute_7.Output -> boolean_math_1.Boolean
		point_representation_017.links.new(reroute_7.outputs[0], boolean_math_1.inputs[1])
		#switch_001_1.Output -> switch_002.False
		point_representation_017.links.new(switch_001_1.outputs[0], switch_002.inputs[1])
		#group_001_1.Geometry -> switch_002.True
		point_representation_017.links.new(group_001_1.outputs[0], switch_002.inputs[2])
		#switch_001_1.Output -> group_001_1.Mesh
		point_representation_017.links.new(switch_001_1.outputs[0], group_001_1.inputs[0])
		#group_input_11.Seed -> group_001_1.Seed
		point_representation_017.links.new(group_input_11.outputs[7], group_001_1.inputs[2])
		#group_input_11.Density -> group_001_1.Density
		point_representation_017.links.new(group_input_11.outputs[6], group_001_1.inputs[1])
		#group_input_11.Sparse points -> reroute_7.Input
		point_representation_017.links.new(group_input_11.outputs[5], reroute_7.inputs[0])
		#reroute_7.Output -> switch_002.Switch
		point_representation_017.links.new(reroute_7.outputs[0], switch_002.inputs[0])
		#group_input_11.Mesh -> reroute_001_5.Input
		point_representation_017.links.new(group_input_11.outputs[0], reroute_001_5.inputs[0])
		#reroute_001_5.Output -> group_2.Geometry
		point_representation_017.links.new(reroute_001_5.outputs[0], group_2.inputs[0])
		#group_input_11.Point cloud -> reroute_002_3.Input
		point_representation_017.links.new(group_input_11.outputs[1], reroute_002_3.inputs[0])
		#reroute_002_3.Output -> switch.Switch
		point_representation_017.links.new(reroute_002_3.outputs[0], switch.inputs[0])
		#mesh_to_points_002.Points -> reroute_003_3.Input
		point_representation_017.links.new(mesh_to_points_002.outputs[0], reroute_003_3.inputs[0])
		#reroute_003_3.Output -> reroute_004_2.Input
		point_representation_017.links.new(reroute_003_3.outputs[0], reroute_004_2.inputs[0])
		#group_2.Geometry -> flip_faces.Mesh
		point_representation_017.links.new(group_2.outputs[0], flip_faces.inputs[0])
		#group_input_11.Point size -> uv_sphere_001.Radius
		point_representation_017.links.new(group_input_11.outputs[2], uv_sphere_001.inputs[2])
		#reroute_005_2.Output -> group_001_1.Radius
		point_representation_017.links.new(reroute_005_2.outputs[0], group_001_1.inputs[3])
		#group_input_11.Point size -> reroute_005_2.Input
		point_representation_017.links.new(group_input_11.outputs[2], reroute_005_2.inputs[0])
		return point_representation_017

	point_representation_017 = point_representation_017_node_group()

	#initialize geometry_nodes_001 node group
	def geometry_nodes_001_node_group():
		geometry_nodes_001 = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "Geometry Nodes.001")

		geometry_nodes_001.color_tag = 'NONE'
		geometry_nodes_001.description = ""

		geometry_nodes_001.is_modifier = True
		
		#geometry_nodes_001 interface
		#initialize geometry_nodes_001 nodes
		#node Group Input
		group_input_12 = geometry_nodes_001.nodes.new("NodeGroupInput")
		group_input_12.name = "Group Input"
		#Socket Geometry
		geometry_socket_14 = geometry_nodes_001.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
		geometry_socket_14.attribute_domain = 'POINT'
		
		#Socket Target
		target_socket = geometry_nodes_001.interface.new_socket(name = "Target", in_out='INPUT', socket_type = 'NodeSocketObject')
		target_socket.attribute_domain = 'POINT'
		
		#Panel Scanner parameters
		scanner_parameters_panel = geometry_nodes_001.interface.new_panel("Scanner parameters")
		#Socket Range (m)
		range__m__socket = geometry_nodes_001.interface.new_socket(name = "Range (m)", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = scanner_parameters_panel)
		range__m__socket.default_value = 100.0
		range__m__socket.min_value = 0.0
		range__m__socket.max_value = 3.4028234663852886e+38
		range__m__socket.subtype = 'NONE'
		range__m__socket.attribute_domain = 'POINT'
		
		#Socket Angle (º)
		angle_____socket = geometry_nodes_001.interface.new_socket(name = "Angle (º)", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = scanner_parameters_panel)
		angle_____socket.default_value = 2.0
		angle_____socket.min_value = 9.999999747378752e-06
		angle_____socket.max_value = 10.0
		angle_____socket.subtype = 'NONE'
		angle_____socket.attribute_domain = 'POINT'
		
		
		#Panel Noise
		noise_panel = geometry_nodes_001.interface.new_panel("Noise", default_closed=True)
		#Socket Noise
		noise_socket_2 = geometry_nodes_001.interface.new_socket(name = "Noise", in_out='INPUT', socket_type = 'NodeSocketMenu', parent = noise_panel)
		noise_socket_2.attribute_domain = 'POINT'

		#node Group.005
		group_005 = geometry_nodes_001.nodes.new("GeometryNodeGroup")
		group_005.name = "Group.005"
		group_005.node_tree = scanner_018

		#group_input_12.Noise -> group_005.Noise
		geometry_nodes_001.links.new(group_input_12.outputs[3], group_005.inputs[6])

		noise_socket_2.default_value = "Noise-normal"
		
		#Socket Noise@1m (m)
		noise_1m__m__socket = geometry_nodes_001.interface.new_socket(name = "Noise@1m (m)", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_panel)
		noise_1m__m__socket.default_value = 0.0
		noise_1m__m__socket.min_value = 0.0
		noise_1m__m__socket.max_value = 100.0
		noise_1m__m__socket.subtype = 'NONE'
		noise_1m__m__socket.attribute_domain = 'POINT'
		
		#Socket Radius
		radius_socket_3 = geometry_nodes_001.interface.new_socket(name = "Radius", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_panel)
		radius_socket_3.default_value = 0.0
		radius_socket_3.min_value = 0.0
		radius_socket_3.max_value = 3.4028234663852886e+38
		radius_socket_3.subtype = 'NONE'
		radius_socket_3.attribute_domain = 'POINT'
		
		#Socket Seed
		seed_socket_4 = geometry_nodes_001.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketInt', parent = noise_panel)
		seed_socket_4.default_value = 0
		seed_socket_4.min_value = 0
		seed_socket_4.max_value = 2147483647
		seed_socket_4.subtype = 'NONE'
		seed_socket_4.attribute_domain = 'POINT'
		
		#Socket Distance factor
		distance_factor_socket = geometry_nodes_001.interface.new_socket(name = "Distance factor", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = noise_panel)
		distance_factor_socket.default_value = 1.0
		distance_factor_socket.min_value = 0.0
		distance_factor_socket.max_value = 3.4028234663852886e+38
		distance_factor_socket.subtype = 'NONE'
		distance_factor_socket.attribute_domain = 'POINT'
		
		#Socket Reference
		reference_socket_2 = geometry_nodes_001.interface.new_socket(name = "Reference", in_out='INPUT', socket_type = 'NodeSocketMenu', parent = noise_panel)
		reference_socket_2.attribute_domain = 'POINT'
		#group_input_12.Reference -> group_005.Reference
		geometry_nodes_001.links.new(group_input_12.outputs[8], group_005.inputs[11])

		reference_socket_2.default_value = "Global"
		
		#Socket XYZ - factors
		xyz___factors_socket_2 = geometry_nodes_001.interface.new_socket(name = "XYZ - factors", in_out='INPUT', socket_type = 'NodeSocketVector', parent = noise_panel)
		xyz___factors_socket_2.default_value = (0.0, 0.0, 0.0)
		xyz___factors_socket_2.min_value = 0.0
		xyz___factors_socket_2.max_value = 3.4028234663852886e+38
		xyz___factors_socket_2.subtype = 'NONE'
		xyz___factors_socket_2.attribute_domain = 'POINT'
		
		
		#Panel Scanner model
		scanner_model_panel = geometry_nodes_001.interface.new_panel("Scanner model", default_closed=True)
		#Socket Height (m)
		height__m__socket = geometry_nodes_001.interface.new_socket(name = "Height (m)", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = scanner_model_panel)
		height__m__socket.default_value = 1.7000000476837158
		height__m__socket.min_value = 0.0
		height__m__socket.max_value = 3.4028234663852886e+38
		height__m__socket.subtype = 'NONE'
		height__m__socket.attribute_domain = 'POINT'
		
		#Socket Min Aperture (º)
		min_aperture_____socket = geometry_nodes_001.interface.new_socket(name = "Min Aperture (º)", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = scanner_model_panel)
		min_aperture_____socket.default_value = 15.0
		min_aperture_____socket.min_value = 0.0
		min_aperture_____socket.max_value = 90.0
		min_aperture_____socket.subtype = 'NONE'
		min_aperture_____socket.attribute_domain = 'POINT'
		
		#Socket Scanner model
		scanner_model_socket_3 = geometry_nodes_001.interface.new_socket(name = "Scanner model", in_out='INPUT', socket_type = 'NodeSocketBool', parent = scanner_model_panel)
		scanner_model_socket_3.default_value = True
		scanner_model_socket_3.attribute_domain = 'POINT'
		
		
		#Panel Points visualization
		points_visualization_panel = geometry_nodes_001.interface.new_panel("Points visualization")
		#Socket Points color
		points_color_socket = geometry_nodes_001.interface.new_socket(name = "Points color", in_out='INPUT', socket_type = 'NodeSocketMenu', parent = points_visualization_panel)

		points_color_socket.attribute_domain = 'POINT'

		#node Group.002
		group_002 = geometry_nodes_001.nodes.new("GeometryNodeGroup")
		group_002.name = "Group.002"
		group_002.node_tree = color_configuration_028

		#node Reroute.004
		reroute_004_3 = geometry_nodes_001.nodes.new("NodeReroute")
		reroute_004_3.name = "Reroute.004"

		#group_input_12.Points color -> reroute_004_3.Input
		geometry_nodes_001.links.new(group_input_12.outputs[13], reroute_004_3.inputs[0])
		
		#reroute_004_3.Output -> group_002.Menu
		geometry_nodes_001.links.new(reroute_004_3.outputs[0], group_002.inputs[5])


		points_color_socket.default_value = "Plain"
		
		#Socket Color
		color_socket_1 = geometry_nodes_001.interface.new_socket(name = "Color", in_out='INPUT', socket_type = 'NodeSocketColor', parent = points_visualization_panel)
		color_socket_1.default_value = (0.0, 0.35465332865715027, 1.0, 1.0)
		color_socket_1.attribute_domain = 'POINT'
		color_socket_1.description = " "
		
		#Socket Texture image
		texture_image_socket = geometry_nodes_001.interface.new_socket(name = "Texture image", in_out='INPUT', socket_type = 'NodeSocketImage', parent = points_visualization_panel)
		texture_image_socket.attribute_domain = 'POINT'
		
		#Socket Improve performance (No export)
		improve_performance__no_export__socket = geometry_nodes_001.interface.new_socket(name = "Improve performance (No export)", in_out='INPUT', socket_type = 'NodeSocketBool', parent = points_visualization_panel)
		improve_performance__no_export__socket.default_value = False
		improve_performance__no_export__socket.attribute_domain = 'POINT'
		
		#Socket Points size
		points_size_socket = geometry_nodes_001.interface.new_socket(name = "Points size", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = points_visualization_panel)
		points_size_socket.default_value = 0.10000000149011612
		points_size_socket.min_value = 0.0
		points_size_socket.max_value = 3.4028234663852886e+38
		points_size_socket.subtype = 'NONE'
		points_size_socket.attribute_domain = 'POINT'
		
		#Socket Mesh clouds
		mesh_clouds_socket = geometry_nodes_001.interface.new_socket(name = "Mesh clouds", in_out='INPUT', socket_type = 'NodeSocketBool', parent = points_visualization_panel)
		mesh_clouds_socket.default_value = False
		mesh_clouds_socket.attribute_domain = 'POINT'
		
		#Socket Filter long edges
		filter_long_edges_socket_2 = geometry_nodes_001.interface.new_socket(name = "Filter long edges", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = points_visualization_panel)
		filter_long_edges_socket_2.default_value = 1.0
		filter_long_edges_socket_2.min_value = 0.0
		filter_long_edges_socket_2.max_value = 3.4028234663852886e+38
		filter_long_edges_socket_2.subtype = 'NONE'
		filter_long_edges_socket_2.attribute_domain = 'POINT'
		
		#Socket Sparse points
		sparse_points_socket_1 = geometry_nodes_001.interface.new_socket(name = "Sparse points", in_out='INPUT', socket_type = 'NodeSocketBool', parent = points_visualization_panel)
		sparse_points_socket_1.default_value = False
		sparse_points_socket_1.attribute_domain = 'POINT'
		
		#Socket Density
		density_socket_2 = geometry_nodes_001.interface.new_socket(name = "Density", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = points_visualization_panel)
		density_socket_2.default_value = 0.0
		density_socket_2.min_value = -3.4028234663852886e+38
		density_socket_2.max_value = 3.4028234663852886e+38
		density_socket_2.subtype = 'NONE'
		density_socket_2.attribute_domain = 'POINT'
		
		#Socket Seed
		seed_socket_5 = geometry_nodes_001.interface.new_socket(name = "Seed", in_out='INPUT', socket_type = 'NodeSocketFloat', parent = points_visualization_panel)
		seed_socket_5.default_value = 0.0
		seed_socket_5.min_value = -3.4028234663852886e+38
		seed_socket_5.max_value = 3.4028234663852886e+38
		seed_socket_5.subtype = 'NONE'
		seed_socket_5.attribute_domain = 'POINT'
		
		

		#node Frame.001
		frame_001_1 = geometry_nodes_001.nodes.new("NodeFrame")
		frame_001_1.label = "RAYCASTING"
		frame_001_1.name = "Frame.001"
		frame_001_1.label_size = 35
		frame_001_1.shrink = False
		
		#node Group Output
		group_output_13 = geometry_nodes_001.nodes.new("NodeGroupOutput")
		group_output_13.name = "Group Output"
		group_output_13.is_active_output = True
		
		#node Switch
		switch_1 = geometry_nodes_001.nodes.new("GeometryNodeSwitch")
		switch_1.name = "Switch"
		switch_1.hide = True
		switch_1.input_type = 'FLOAT'
		#False
		switch_1.inputs[1].default_value = -0.09999999403953552
		
		#node Group.001
		group_001_2 = geometry_nodes_001.nodes.new("GeometryNodeGroup")
		group_001_2.name = "Group.001"
		group_001_2.node_tree = attributes_storage_025
		
		#node Group.004
		group_004 = geometry_nodes_001.nodes.new("GeometryNodeGroup")
		group_004.name = "Group.004"
		group_004.node_tree = raycast_group_025
		
		#node Group.006
		group_006 = geometry_nodes_001.nodes.new("GeometryNodeGroup")
		group_006.name = "Group.006"
		group_006.node_tree = point_representation_017
		
		#node Join Geometry
		join_geometry_1 = geometry_nodes_001.nodes.new("GeometryNodeJoinGeometry")
		join_geometry_1.name = "Join Geometry"
		
		#node Frame.002
		frame_002_2 = geometry_nodes_001.nodes.new("NodeFrame")
		frame_002_2.label = "COLOR"
		frame_002_2.name = "Frame.002"
		frame_002_2.label_size = 35
		frame_002_2.shrink = True
		
		#node Frame.003
		frame_003_1 = geometry_nodes_001.nodes.new("NodeFrame")
		frame_003_1.label = "ATTRIBUTES"
		frame_003_1.name = "Frame.003"
		frame_003_1.label_size = 35
		frame_003_1.shrink = False
		
		#node Frame.004
		frame_004_1 = geometry_nodes_001.nodes.new("NodeFrame")
		frame_004_1.label = "3D REPRESENTATION"
		frame_004_1.name = "Frame.004"
		frame_004_1.label_size = 35
		frame_004_1.shrink = False
		
		#node Frame.005
		frame_005_1 = geometry_nodes_001.nodes.new("NodeFrame")
		frame_005_1.label = "SCANNER"
		frame_005_1.name = "Frame.005"
		frame_005_1.label_size = 35
		frame_005_1.shrink = True
		
		#node Frame.006
		frame_006_1 = geometry_nodes_001.nodes.new("NodeFrame")
		frame_006_1.label = "OUTPUT"
		frame_006_1.name = "Frame.006"
		frame_006_1.label_size = 35
		frame_006_1.shrink = True
		
		#node Frame.007
		frame_007 = geometry_nodes_001.nodes.new("NodeFrame")
		frame_007.label = "INPUT"
		frame_007.name = "Frame.007"
		frame_007.label_size = 35
		frame_007.shrink = True
		
		#node Reroute
		reroute_8 = geometry_nodes_001.nodes.new("NodeReroute")
		reroute_8.name = "Reroute"
		#node Reroute.001
		reroute_001_6 = geometry_nodes_001.nodes.new("NodeReroute")
		reroute_001_6.name = "Reroute.001"
		#node Reroute.002
		reroute_002_4 = geometry_nodes_001.nodes.new("NodeReroute")
		reroute_002_4.name = "Reroute.002"
		#node Reroute.003
		reroute_003_4 = geometry_nodes_001.nodes.new("NodeReroute")
		reroute_003_4.name = "Reroute.003"
		#node Reroute.005
		reroute_005_3 = geometry_nodes_001.nodes.new("NodeReroute")
		reroute_005_3.name = "Reroute.005"
		
		
		#Set parents
		group_input_12.parent = frame_007
		group_005.parent = frame_005_1
		group_002.parent = frame_002_2
		group_output_13.parent = frame_006_1
		group_001_2.parent = frame_003_1
		group_004.parent = frame_001_1
		group_006.parent = frame_004_1
		
		#Set locations
		group_input_12.location = (-168.2718505859375, 141.27491760253906)
		group_005.location = (-166.03111267089844, 633.221923828125)
		group_002.location = (-82.408935546875, 191.80874633789062)
		reroute_004_3.location = (161.16146850585938, -190.00169372558594)
		frame_001_1.location = (-171.11376953125, 312.7098388671875)
		group_output_13.location = (-197.1890869140625, 86.82867431640625)
		switch_1.location = (167.96441650390625, 551.6930541992188)
		group_001_2.location = (120.52056884765625, -116.64823913574219)
		group_004.location = (-158.60421752929688, 195.45950317382812)
		group_006.location = (76.41741943359375, -242.00509643554688)
		join_geometry_1.location = (793.3658447265625, -52.16827392578125)
		frame_002_2.location = (315.75225830078125, 263.300537109375)
		frame_003_1.location = (347.75665283203125, 297.99969482421875)
		frame_004_1.location = (415.3235778808594, 49.21022033691406)
		frame_005_1.location = (77.6639404296875, -382.61663818359375)
		frame_006_1.location = (1176.693115234375, -131.32830810546875)
		frame_007.location = (-417.48980712890625, -29.7733154296875)
		reroute_8.location = (151.7628173828125, 105.03712463378906)
		reroute_001_6.location = (249.92724609375, -234.76287841796875)
		reroute_002_4.location = (204.51361083984375, -223.59164428710938)
		reroute_003_4.location = (181.79576110839844, -207.23757934570312)
		reroute_005_3.location = (171.73330688476562, 195.54495239257812)
		
		#Set dimensions
		group_input_12.width, group_input_12.height = 140.0, 100.0
		group_005.width, group_005.height = 140.0, 100.0
		group_002.width, group_002.height = 140.0, 100.0
		reroute_004_3.width, reroute_004_3.height = 16.0, 100.0
		frame_001_1.width, frame_001_1.height = 340.287353515625, 407.5858459472656
		group_output_13.width, group_output_13.height = 140.0, 100.0
		switch_1.width, switch_1.height = 215.01708984375, 100.0
		group_001_2.width, group_001_2.height = 140.0, 100.0
		group_004.width, group_004.height = 140.0, 100.0
		group_006.width, group_006.height = 140.0, 100.0
		join_geometry_1.width, join_geometry_1.height = 140.0, 100.0
		frame_002_2.width, frame_002_2.height = 200.0, 343.95001220703125
		frame_003_1.width, frame_003_1.height = 244.11965942382812, 335.0226745605469
		frame_004_1.width, frame_004_1.height = 308.4541320800781, 413.4084777832031
		frame_005_1.width, frame_005_1.height = 200.0, 515.949951171875
		frame_006_1.width, frame_006_1.height = 199.99993896484375, 159.9499969482422
		frame_007.width, frame_007.height = 199.99996948242188, 637.5499877929688
		reroute_8.width, reroute_8.height = 16.0, 100.0
		reroute_001_6.width, reroute_001_6.height = 16.0, 100.0
		reroute_002_4.width, reroute_002_4.height = 16.0, 100.0
		reroute_003_4.width, reroute_003_4.height = 16.0, 100.0
		reroute_005_3.width, reroute_005_3.height = 16.0, 100.0
		
		#initialize geometry_nodes_001 links
		#group_004.Hit Distance -> switch_1.True
		geometry_nodes_001.links.new(group_004.outputs[6], switch_1.inputs[2])
		#switch_1.Output -> group_001_2.Scanner height
		geometry_nodes_001.links.new(switch_1.outputs[0], group_001_2.inputs[1])
		#group_input_12.Target -> group_004.Object
		geometry_nodes_001.links.new(group_input_12.outputs[0], group_004.inputs[0])
		#group_input_12.Range (m) -> group_004.Ray Length
		geometry_nodes_001.links.new(group_input_12.outputs[1], group_004.inputs[1])
		#group_input_12.Noise@1m (m) -> group_005.Noise@1m
		geometry_nodes_001.links.new(group_input_12.outputs[4], group_005.inputs[7])
		#group_004.Geometry -> group_002.Geometry
		geometry_nodes_001.links.new(group_004.outputs[0], group_002.inputs[0])
		#group_001_2.Geometry -> group_006.Mesh
		geometry_nodes_001.links.new(group_001_2.outputs[0], group_006.inputs[0])
		#group_002.Output -> group_001_2.Color
		geometry_nodes_001.links.new(group_002.outputs[0], group_001_2.inputs[2])
		#group_004.Is Hit -> group_002.Selection
		geometry_nodes_001.links.new(group_004.outputs[2], group_002.inputs[2])
		#group_004.Hit Position -> group_002.Sample Position
		geometry_nodes_001.links.new(group_004.outputs[3], group_002.inputs[3])
		#reroute_005_3.Output -> group_001_2.Hit distance
		geometry_nodes_001.links.new(reroute_005_3.outputs[0], group_001_2.inputs[3])
		#group_004.Hit Distance -> group_002.Hit Distance
		geometry_nodes_001.links.new(group_004.outputs[4], group_002.inputs[4])
		#reroute_001_6.Output -> group_006.Point cloud
		geometry_nodes_001.links.new(reroute_001_6.outputs[0], group_006.inputs[1])
		#join_geometry_1.Geometry -> group_output_13.Geometry
		geometry_nodes_001.links.new(join_geometry_1.outputs[0], group_output_13.inputs[0])
		#group_input_12.Points size -> group_006.Point size
		geometry_nodes_001.links.new(group_input_12.outputs[17], group_006.inputs[2])
		#group_input_12.Mesh clouds -> group_006.Mesh cloud
		geometry_nodes_001.links.new(group_input_12.outputs[18], group_006.inputs[3])
		#group_input_12.Filter long edges -> group_006.Filter long edges
		geometry_nodes_001.links.new(group_input_12.outputs[19], group_006.inputs[4])
		#reroute_8.Output -> group_002.Geometry
		geometry_nodes_001.links.new(reroute_8.outputs[0], group_002.inputs[1])
		#group_004.Is Hit -> group_005.Selection
		geometry_nodes_001.links.new(group_004.outputs[2], group_005.inputs[1])
		#group_input_12.Angle (º) -> group_005.Angle
		geometry_nodes_001.links.new(group_input_12.outputs[2], group_005.inputs[4])
		#group_input_12.Min Aperture (º) -> group_005.Min aberture
		geometry_nodes_001.links.new(group_input_12.outputs[11], group_005.inputs[13])
		#group_input_12.Scanner model -> group_005.Scanner model
		geometry_nodes_001.links.new(group_input_12.outputs[12], group_005.inputs[14])
		#group_input_12.Height (m) -> group_005.Height
		geometry_nodes_001.links.new(group_input_12.outputs[10], group_005.inputs[5])
		#group_004.Hit Position -> group_005.Position
		geometry_nodes_001.links.new(group_004.outputs[3], group_005.inputs[2])
		#group_004.Normal -> group_005.Normal
		geometry_nodes_001.links.new(group_004.outputs[1], group_005.inputs[0])
		#group_004.Hit Distance -> group_005.Hit distance
		geometry_nodes_001.links.new(group_004.outputs[4], group_005.inputs[3])
		#group_input_12.Sparse points -> group_006.Sparse points
		geometry_nodes_001.links.new(group_input_12.outputs[20], group_006.inputs[5])
		#group_input_12.Density -> group_006.Density
		geometry_nodes_001.links.new(group_input_12.outputs[21], group_006.inputs[6])
		#group_input_12.Seed -> group_006.Seed
		geometry_nodes_001.links.new(group_input_12.outputs[22], group_006.inputs[7])
		#group_005.Geometry -> reroute_8.Input
		geometry_nodes_001.links.new(group_005.outputs[0], reroute_8.inputs[0])
		#reroute_8.Output -> group_001_2.Geometry
		geometry_nodes_001.links.new(reroute_8.outputs[0], group_001_2.inputs[0])
		#group_input_12.Improve performance (No export) -> reroute_001_6.Input
		geometry_nodes_001.links.new(group_input_12.outputs[16], reroute_001_6.inputs[0])
		#reroute_001_6.Output -> group_001_2.Enable point size
		geometry_nodes_001.links.new(reroute_001_6.outputs[0], group_001_2.inputs[4])
		#group_input_12.Texture image -> reroute_002_4.Input
		geometry_nodes_001.links.new(group_input_12.outputs[15], reroute_002_4.inputs[0])
		#reroute_002_4.Output -> group_002.Image
		geometry_nodes_001.links.new(reroute_002_4.outputs[0], group_002.inputs[7])
		#group_input_12.Color -> reroute_003_4.Input
		geometry_nodes_001.links.new(group_input_12.outputs[14], reroute_003_4.inputs[0])
		#reroute_003_4.Output -> group_002.Plain
		geometry_nodes_001.links.new(reroute_003_4.outputs[0], group_002.inputs[6])
		#group_005.Scanner model -> join_geometry_1.Geometry
		geometry_nodes_001.links.new(group_005.outputs[1], join_geometry_1.inputs[0])
		#group_004.Hit Distance -> reroute_005_3.Input
		geometry_nodes_001.links.new(group_004.outputs[4], reroute_005_3.inputs[0])
		#group_004.Is Hit -> switch_1.Switch
		geometry_nodes_001.links.new(group_004.outputs[5], switch_1.inputs[0])
		#group_input_12.Height (m) -> group_004.Scanner Height
		geometry_nodes_001.links.new(group_input_12.outputs[10], group_004.inputs[2])
		#group_input_12.Seed -> group_005.Seed
		geometry_nodes_001.links.new(group_input_12.outputs[6], group_005.inputs[9])
		#group_input_12.Radius -> group_005.Radius
		geometry_nodes_001.links.new(group_input_12.outputs[5], group_005.inputs[8])
		#group_input_12.Distance factor -> group_005.Distance - factor
		geometry_nodes_001.links.new(group_input_12.outputs[7], group_005.inputs[10])
		#group_input_12.XYZ - factors -> group_005.XYZ - factors
		geometry_nodes_001.links.new(group_input_12.outputs[9], group_005.inputs[12])
		#group_006.Geometry -> join_geometry_1.Geometry
		geometry_nodes_001.links.new(group_006.outputs[0], join_geometry_1.inputs[0])
		return geometry_nodes_001


	
	node_group = geometry_nodes_001_node_group()
	geometry_nodes = scanner_object.modifiers.new(name="GeometryNodes", type='NODES')
	geometry_nodes.node_group = node_group
	return scanner_object
################################ NEW
# Registro de la propiedad
bpy.types.Scene.hide_generated_scanners = bpy.props.BoolProperty(
	name="Hide generated scanners",
	description="If enabled, generated scanners will be hidden by default",
	default=True
)
################################## END NEW

# Operador para actualizar el valor float desde el atributo de Geometry Nodes
class OBJECT_OT_show_float_value(bpy.types.Operator):
	bl_idname = "object.show_float_value"
	bl_label = "Update Calculated Value"

	def execute(self, context):
		obj = context.active_object
		if obj and obj.modifiers.get("GeometryNodes"):
			depsgraph = context.evaluated_depsgraph_get()
			eval_obj = obj.evaluated_get(depsgraph)
			if eval_obj.data.attributes.get("hit_distance"):
				hit_distance_attr = eval_obj.data.attributes["hit_distance"]
				float_value = hit_distance_attr.data[0].value
				context.scene.float_value_to_show = float_value
				#self.report({'INFO'}, f"Calculated Value: {float_value}")
			else:
				self.report({'WARNING'}, "The 'hit_distance' attribute was not found in the geometry.")
		else:
			self.report({'WARNING'}, "No object with a Geometry Nodes modifier was found.")
		return {'FINISHED'}

# Operador personalizado para exportar cada scanner a PLY
class EXPORT_OT_points_ply(bpy.types.Operator):
	bl_idname = "export.points_ply"
	bl_label = "Export Points as PLY"
	bl_description = "Export scanner data as PLY format"
	
	filepath: bpy.props.StringProperty(subtype="FILE_PATH")
	attribute_name: bpy.props.StringProperty(name="hit_distance", default="hit_distance")

	def execute(self, context):
		obj = context.active_object
		if obj and obj.modifiers:
			geo_node_modifier = obj.modifiers.get("GeometryNodes")
			if geo_node_modifier:
				depsgraph = context.evaluated_depsgraph_get()
				eval_obj = obj.evaluated_get(depsgraph)
				mesh = eval_obj.to_mesh()
				point_coordinates = mesh.attributes.get("point_coordinates")
				color_layer = mesh.attributes.get("color")
				distance = mesh.attributes.get("distance")
				point_cloud_activate = mesh.attributes.get("point_cloud_activate")
				write_interval = 5 if point_cloud_activate else 1
				# Verificar si falta alguno de los atributos necesarios
				if not (mesh.attributes.get("point_coordinates") and 
						mesh.attributes.get("color") and 
						mesh.attributes.get("distance")):
					show_missing_attributes_dialog(self, context)
					return {'CANCELLED'}  # Cancela la operación y no abre el explorador
				if color_layer:
					with open(self.filepath, "w") as file:
						file.write("ply\n")
						file.write("format ascii 1.0\n")
						file.write(f"element vertex {len(mesh.vertices)/5}\n")
						file.write("property float x\n")
						file.write("property float y\n")
						file.write("property float z\n")
						file.write("property uchar red\n")
						file.write("property uchar green\n")
						file.write("property uchar blue\n")
						file.write("property float distance\n")
						file.write("end_header\n")
						
						for index, (vert, dista, color) in enumerate(zip(point_coordinates.data, distance.data, color_layer.data)):
							if index % write_interval == 0:
								co = obj.matrix_world @ vert.vector  # Coordenadas globales
								distan = dista.value
								col = color.color
								r, g, b = [int((c if not math.isnan(c) else 0) * 255) for c in col[:3]]
								file.write(f"{co.x} {co.y} {co.z} {r} {g} {b} {distan}\n")

					eval_obj.to_mesh_clear()
					self.report({'INFO'}, f"Data successfully exported as PLY to {self.filepath}")
				else:
					self.report({'WARNING'}, f"Attribute '{self.attribute_name}' does not exist in the geometry.")
			else:
				self.report({'WARNING'}, "Object does not have a Geometry Nodes modifier.")
		else:
			self.report({'WARNING'}, "No object selected or it has no modifiers.")
		return {'FINISHED'}

	def invoke(self, context, event):
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}

# Operador para exportar todos los scanners a un único PLY
class EXPORT_OT_combined_ply(bpy.types.Operator):
	bl_idname = "export.combined_ply"
	bl_label = "Export Combined PLY"
	bl_description = "Export all scanners as a single PLY file"
	
	filepath: bpy.props.StringProperty(subtype="FILE_PATH")
	hit_distance_attr: bpy.props.StringProperty(name="hit_distance", default="hit_distance")
	color_attr: bpy.props.StringProperty(name="color", default="color")

	def execute(self, context):
		scanner_objects = [obj for obj in bpy.data.objects if "scanner" in obj.name.lower()]
		if not scanner_objects:
			show_no_scanners_dialog(self, context)
			return {'CANCELLED'}

		total_vertex_count = 0
		for obj in scanner_objects:
			depsgraph = context.evaluated_depsgraph_get()
			eval_obj = obj.evaluated_get(depsgraph)
			total_vertex_count += len(eval_obj.data.vertices)

		with open(self.filepath, "w") as file:
			file.write("ply\n")
			file.write("format ascii 1.0\n")
			file.write(f"element vertex {total_vertex_count/5}\n")
			file.write("property float x\n")
			file.write("property float y\n")
			file.write("property float z\n")
			file.write("property uchar red\n")
			file.write("property uchar green\n")
			file.write("property uchar blue\n")
			file.write("property float hit_distance\n")
			file.write("end_header\n")

			for obj in scanner_objects:
				depsgraph = context.evaluated_depsgraph_get()
				eval_obj = obj.evaluated_get(depsgraph)
				mesh = eval_obj.to_mesh()
				point_coordinates = mesh.attributes.get("point_coordinates")
				hit_distance_layer = mesh.attributes.get(self.hit_distance_attr)
				color_layer = mesh.attributes.get(self.color_attr)
				point_cloud_activate = mesh.attributes.get("point_cloud_activate")
				write_interval = 5 if point_cloud_activate else 1
				
				if not hit_distance_layer or not color_layer:
					self.report({'WARNING'}, f"Attributes missing in '{obj.name}'. Skipping.")
					continue

				for index, (vert, hit_dist, color) in enumerate(zip(point_coordinates.data, hit_distance_layer.data, color_layer.data)):
					if index % write_interval == 0:
						global_co = obj.matrix_world @ vert.vector
						hit_value = hit_dist.value
						r, g, b = [int(c * 255) for c in color.color[:3]]
						file.write(f"{global_co.x} {global_co.y} {global_co.z} {r} {g} {b} {hit_value}\n")

				eval_obj.to_mesh_clear()

		self.report({'INFO'}, f"All scanner data successfully exported as a combined PLY to {self.filepath}")
		return {'FINISHED'}

	def invoke(self, context, event):
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}

class OPEN_OT_link(bpy.types.Operator):
	bl_idname = "wm.open_tlsynth_link"
	bl_label = "TLSynth Link"
	bl_description = "Open TLSynth documentation in the browser"

	url: bpy.props.StringProperty()

	def execute(self, context):
		import webbrowser
		webbrowser.open(self.url)
		self.report({'INFO'}, f"Opening {self.url}")
		return {'FINISHED'}

class OBJECT_PT_tlsynth_info_panel(bpy.types.Panel):
	bl_idname = "OBJECT_PT_tlsynth_info_panel"
	bl_label = "TLSynth Info"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = "modifier"
	bl_options = {'DEFAULT_CLOSED'}

	def draw(self, context):
		layout = self.layout
		# Texto con el título
		layout.label(text="TLSynth", icon='WORLD')
		# Enlace interactivo
		row = layout.row()
		row.operator("wm.open_tlsynth_link", text="More Info...", icon='URL').url = "https://github.com/3dcovim/TLSynth"
		# Texto con el título
		layout.label(text="Add-on created by 3DCo-Vim group.")
		# Segunda línea de enlace
		row = layout.row()
		row.operator("wm.open_tlsynth_link", text="Web", icon='HELP').url = "https://3dcovim.cms.unex.es/"



# Panel to display the float value and export PLY button, restricted to objects containing "scanner" in the name
class OBJECT_PT_float_value_and_export_panel(bpy.types.Panel):
	bl_idname = "OBJECT_PT_float_value_and_export_panel"
	bl_label = "Scanner Height & Export"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = "modifier"

	@classmethod
	def poll(cls, context):
		obj = context.active_object
		return obj is not None and "scanner" in obj.name.lower()

	def draw(self, context):
		layout = self.layout
		layout.label(text="Scanner Height:")
		layout.label(text=f"{context.scene.float_value_to_show:.3f}")
		
		layout.operator("object.show_float_value", text="Update Height")
		layout.operator("export.points_ply", text="Export to PLY")
		layout.separator()
		layout.label(text="Export Animation Settings:")
		layout.prop(context.scene, "animation_frame_start")
		layout.prop(context.scene, "animation_frame_end")
		layout.prop(context.scene, "animation_frame_step")
		layout.operator("export.animated_points_ply", text="Export Animation to PLY")


bpy.types.Scene.animation_frame_start = bpy.props.IntProperty(
	name="Start Frame", 
	default=1, 
	min=0, 
	description="Starting frame of the animation"
)

bpy.types.Scene.animation_frame_end = bpy.props.IntProperty(
	name="End Frame", 
	default=250, 
	min=0, 
	description="Ending frame of the animation"
)

bpy.types.Scene.animation_frame_step = bpy.props.IntProperty(
	name="Frame Step", 
	default=1, 
	min=1, 
	description="Step size between frames"
)

class EXPORT_OT_animated_points_ply(bpy.types.Operator):
	bl_idname = "export.animated_points_ply"
	bl_label = "Export Animation to PLY"
	bl_description = "Export scanner animation data as PLY format"

	filepath: bpy.props.StringProperty(subtype="FILE_PATH")

	def execute(self, context):
		# Validar que se haya especificado una ruta válida
		if not self.filepath:
			self.report({'ERROR'}, "No file path provided.")
			return {'CANCELLED'}

		# Obtener los valores de los campos del panel
		frame_start = context.scene.animation_frame_start
		frame_end = context.scene.animation_frame_end
		frame_step = context.scene.animation_frame_step

		# Validar rango de fotogramas
		if frame_start > frame_end:
			self.report({'WARNING'}, "Start Frame must be less than or equal to End Frame.")
			return {'CANCELLED'}

		if frame_step <= 0:
			self.report({'WARNING'}, "Frame Step must be greater than 0.")
			return {'CANCELLED'}

		# Validar que haya un objeto activo con Geometry Nodes
		obj = context.active_object
		if not obj or not obj.modifiers.get("GeometryNodes"):
			self.report({'WARNING'}, "No object with a Geometry Nodes modifier found.")
			return {'CANCELLED'}

		# Exportar la animación
		abs_path = bpy.path.abspath(self.filepath)
		export_animated_point_cloud(abs_path, obj, frame_start, frame_end, frame_step)

		self.report({'INFO'}, f"Animation data successfully exported as PLY to {abs_path}")
		return {'FINISHED'}

	def invoke(self, context, event):
		# Abrir cuadro de diálogo para seleccionar archivo
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}


class OBJECT_OT_select_target_mesh(bpy.types.Operator):
	bl_idname = "object.select_target_mesh"
	bl_label = "Select Target Mesh"
	bl_description = "Use the eyedropper to select the target mesh interactively"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		# Obtener el objeto activo después de la selección interactiva
		obj = context.view_layer.objects.active
		if obj and obj.type == 'MESH':
			# Asignar el nombre del objeto seleccionado a scanner_target_mesh
			context.scene.scanner_target_mesh = obj.name
			self.report({'INFO'}, f"Target Mesh set to {obj.name}")
			return {'FINISHED'}
		else:
			self.report({'WARNING'}, "Please select a valid mesh object.")
			return {'CANCELLED'}

	def invoke(self, context, event):
		# Activar el modo de selección interactiva en 3D
		bpy.ops.object.select_all(action='DESELECT')  # Desseleccionar todo
		context.window_manager.modal_handler_add(self)  # Añadir manejador modal
		return {'RUNNING_MODAL'}

	def modal(self, context, event):
		if event.type == 'LEFTMOUSE':  # Cuando el usuario hace clic izquierdo
			obj = context.view_layer.objects.active
			if obj:
				return self.execute(context)
			else:
				self.report({'WARNING'}, "No object selected.")
				return {'CANCELLED'}
		elif event.type in {'RIGHTMOUSE', 'ESC'}:  # Cancelar con clic derecho o escape
			self.report({'INFO'}, "Selection canceled.")
			return {'CANCELLED'}
		return {'RUNNING_MODAL'}


def export_animated_point_cloud(filepath, obj, frame_start, frame_end, frame_step):
	all_points = []
	# Configura el rango de fotogramas para la animación
	for frame in range(frame_start, frame_end + 1, frame_step):
		bpy.context.scene.frame_set(frame)

		# Evaluar Geometry Nodes en el fotograma actual
		depsgraph = bpy.context.evaluated_depsgraph_get()
		evaluated_obj = obj.evaluated_get(depsgraph)

		mesh = evaluated_obj.to_mesh()
		point_coordinates = mesh.attributes.get("point_coordinates")
		color_layer = mesh.attributes.get("color")
		distance = mesh.attributes.get("distance")
		point_cloud_activate = mesh.attributes.get("point_cloud_activate")
		write_interval = 5 if point_cloud_activate else 1

		# Obtener las posiciones globales de los puntos y el valor de frame para cada punto
		points = []
		for index, (vert, dista, color) in enumerate(zip(point_coordinates.data, distance.data, color_layer.data)):
			if index % write_interval == 0:
				co = obj.matrix_world @ vert.vector  # Coordenadas globales
				distan = dista.value
				col = color.color
				r, g, b = [int((c if not math.isnan(c) else 0) * 255) for c in col[:3]]
				points.append((co.x, co.y, co.z, r, g, b, distan, frame))
		all_points.extend(points)
		print(frame)
	if color_layer:
		with open(filepath, 'w') as file:
			file.write("ply\n")
			file.write("format ascii 1.0\n")
			file.write(f"element vertex {len(all_points)}\n")
			file.write("property float x\n")
			file.write("property float y\n")
			file.write("property float z\n")
			file.write("property uchar red\n")
			file.write("property uchar green\n")
			file.write("property uchar blue\n")
			file.write("property float distance\n")
			file.write("property float frame\n")
			file.write("end_header\n")
			for point in all_points:
				file.write(f"{point[0]} {point[1]} {point[2]} {point[3]} {point[4]} {point[5]} {point[6]} {point[7]}\n")

# Función para crear o verificar que el material 'Points_material' exista
def get_or_create_points_material():
	material_name = "Points_material"
	if material_name in bpy.data.materials:
		return bpy.data.materials[material_name]
	else:
		material = bpy.data.materials.new(name=material_name)
		material.use_nodes = True
		nodes = material.node_tree.nodes
		links = material.node_tree.links
		# Limpiar nodos iniciales
		nodes.clear()
		
		# Crear nodo: Material Output
		material_output = nodes.new('ShaderNodeOutputMaterial')
		material_output.location = (364.6596374511719, 191.44180297851562)
		# material_output.inputs['Thickness'].default_value = 0.0
		
		# Crear nodo: Principled BSDF
		principled_bsdf = nodes.new('ShaderNodeBsdfPrincipled')
		principled_bsdf.location = (0.6183532476425171, 196.85794067382812)
		principled_bsdf.inputs['Base Color'].default_value = (0.0, 0.0, 0.0, 1.0)
		principled_bsdf.inputs['Metallic'].default_value = 0.0
		principled_bsdf.inputs['Roughness'].default_value = 0.22363635897636414
		principled_bsdf.inputs['IOR'].default_value = 1.4500000476837158
		principled_bsdf.inputs['Alpha'].default_value = 1.0
		# principled_bsdf.inputs['Transmission'].default_value = 0.0
		# principled_bsdf.inputs['Weight'].default_value = 0.0
		# principled_bsdf.inputs['Subsurface Weight'].default_value = 0.0
		# principled_bsdf.inputs['Subsurface Scale'].default_value = 0.05000000074505806
		# principled_bsdf.inputs['Subsurface IOR'].default_value = 1.399999976158142
		# principled_bsdf.inputs['Subsurface Anisotropy'].default_value = 0.0
		# principled_bsdf.inputs['Specular IOR Level'].default_value = 0.5
		# principled_bsdf.inputs['Specular Tint'].default_value = (0.0, 0.0, 0.0, 1.0)
		# principled_bsdf.inputs['Anisotropic'].default_value = 0.0
		# principled_bsdf.inputs['Anisotropic Rotation'].default_value = 0.0
		# principled_bsdf.inputs['Transmission Weight'].default_value = 0.0
		# principled_bsdf.inputs['Coat Weight'].default_value = 0.0
		# principled_bsdf.inputs['Coat Roughness'].default_value = 0.029999999329447746
		# principled_bsdf.inputs['Coat IOR'].default_value = 1.5
		# principled_bsdf.inputs['Coat Tint'].default_value = (0.0, 0.0, 0.0, 1.0)
		# principled_bsdf.inputs['Sheen Weight'].default_value = 0.0
		# principled_bsdf.inputs['Sheen Roughness'].default_value = 0.5
		# principled_bsdf.inputs['Sheen Tint'].default_value = (0.0, 0.0, 0.0, 1.0)
		# principled_bsdf.inputs['Emission Color'].default_value = (0.0, 0.0, 0.0, 1.0)
		# principled_bsdf.inputs['Emission Strength'].default_value = 0.0
		# principled_bsdf.inputs['Thin Film Thickness'].default_value = 0.0
		# principled_bsdf.inputs['Thin Film IOR'].default_value = 1.3300000429153442
		
		# Crear nodo: Attribute
		attribute = nodes.new('ShaderNodeAttribute')
		attribute.location = (-605.9175415039062, 130.71517944335938)
		attribute.attribute_name = 'color'
		
		# Crear enlace
		links.new(principled_bsdf.outputs['BSDF'], material_output.inputs['Surface'])
		
		# Crear enlace
		links.new(attribute.outputs['Color'], principled_bsdf.inputs['Base Color'])
	return material


# Función para crear o verificar que el material 'Scanner_model' exista
def get_or_create_scanner_model_material():
	material_name = "Scanner_model"
	if material_name in bpy.data.materials:
		return bpy.data.materials[material_name]
	else:
		material = bpy.data.materials.new(name=material_name)
		material.use_nodes = True
		nodes = material.node_tree.nodes
		links = material.node_tree.links
		# Limpiar nodos iniciales
		nodes.clear()
		
		# Crear nodo: Principled BSDF
		principled_bsdf = nodes.new('ShaderNodeBsdfPrincipled')
		principled_bsdf.location = (11.094667434692383, 291.2257080078125)
		principled_bsdf.inputs['Base Color'].default_value = (0.152611, 0.0859102, 0.203713, 1)
		principled_bsdf.inputs['Metallic'].default_value = 0.4618181884288788
		principled_bsdf.inputs['Roughness'].default_value = 0.0
		principled_bsdf.inputs['IOR'].default_value = 3.799999952316284
		principled_bsdf.inputs['Alpha'].default_value = 1.0


		# Crear nodo: Material Output
		material_output = nodes.new('ShaderNodeOutputMaterial')
		material_output.location = (301.09466552734375, 291.2257080078125)
		material_output.inputs['Thickness'].default_value = 0.0

		# Crear enlace
		links.new(principled_bsdf.outputs['BSDF'], material_output.inputs['Surface'])
	return material


# Operador para crear los objetos scanner
class OBJECT_OT_generate_scanners(bpy.types.Operator):
	bl_idname = "object.generate_scanners"
	bl_label = "Generate Scanners"
	bl_description = "Generate multiple scanners for the selected mesh"

	def execute(self, context):
		target_mesh_name = context.scene.scanner_target_mesh
		target_mesh = bpy.data.objects.get(target_mesh_name)
		if not target_mesh:
			self.report({'ERROR'}, "Target mesh not found.")
			return {'CANCELLED'}

		# Obtén o crea el material 'Points_material'
		points_material = get_or_create_points_material()
		scanner_model_material = get_or_create_scanner_model_material()

		# Obtén la secuencia de numeración actual de los escáneres
		existing_scanners = [obj for obj in bpy.data.objects if obj.name.startswith("scanner")]
		if existing_scanners:
			# Obtener el número más alto de los nombres de los escáneres
			max_number = max([int(obj.name.split("_")[-1]) for obj in existing_scanners])
			next_number = max_number + 1
		else:
			next_number = 1

		if "scanner" not in [obj.name for obj in bpy.data.objects]:
			create_scanner_base()

		original_scanner = bpy.data.objects["scanner"]
		should_hide = context.scene.hide_generated_scanners

		for i in range(context.scene.scanner_count):
			scanner_number = next_number + i
			new_scanner = original_scanner.copy()
			new_scanner.data = original_scanner.data.copy()
			new_scanner.name = f"scanner_{scanner_number}"
			context.collection.objects.link(new_scanner)
			# Asigna el material 'Points_material' al scanner generado
			if new_scanner.data.materials:
				new_scanner.data.materials[0] = points_material
			else:
				new_scanner.data.materials.append(points_material)
			geo_node_modifier = new_scanner.modifiers.get("GeometryNodes")
			if geo_node_modifier:
				identifitarget = geo_node_modifier.node_group.nodes['Group Input'].outputs['Target'].identifier
				geo_node_modifier[identifitarget] = target_mesh
				#geo_node_modifier[0] = target_mesh
			# Desactiva el scanner en el viewport y el renderizado
			# new_scanner.hide_viewport = True
			# new_scanner.hide_render = True
			# new_scanner.hide_viewport = should_hide
			new_scanner.hide_set(should_hide) 
			new_scanner.hide_render = should_hide


		# Eliminar el scanner base original después de copiarlo
		bpy.data.objects.remove(original_scanner, do_unlink=True)

		return {'FINISHED'}

# Panel para seleccionar el objeto objetivo, definir el número de escáneres y exportar
class OBJECT_PT_generate_scanners_panel(bpy.types.Panel):
	bl_idname = "OBJECT_PT_generate_scanners_panel"
	bl_label = "Main menu - Global"
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'UI'
	bl_category = 'TLSynth'
	
	def draw(self, context):
		layout = self.layout
		col = layout.column()
		
		col.prop_search(context.scene, "scanner_target_mesh", context.scene, "objects", text="Target Mesh")
		col.operator("object.select_target_mesh", text="", icon='EYEDROPPER')
		col.prop(context.scene, "scanner_count", text="Number of Scanners")
		############################### NEW
		col.prop(context.scene, "hide_generated_scanners", text="Hide generated scanners")
		############################## END NEW
		
		col.operator("object.generate_scanners", text="Generate Scanners")
		col.operator("export.combined_ply", text="Export Combined PLY")
		# Añade el nuevo botón para renderizar la vista cenital
		col.operator("object.render_top_view", text="Generate Top View Image")

# Register and unregister
def register():
	bpy.utils.register_class(OPEN_OT_link)
	bpy.utils.register_class(OBJECT_PT_tlsynth_info_panel)
	bpy.utils.register_class(OBJECT_OT_generate_scanners)
	bpy.utils.register_class(OBJECT_OT_show_float_value)
	bpy.utils.register_class(EXPORT_OT_points_ply)
	bpy.utils.register_class(EXPORT_OT_combined_ply)
	bpy.utils.register_class(EXPORT_OT_animated_points_ply)  # Registro del nuevo operador
	bpy.utils.register_class(OBJECT_PT_generate_scanners_panel)
	bpy.utils.register_class(OBJECT_PT_float_value_and_export_panel)
	bpy.utils.register_class(OBJECT_OT_render_top_view)  # Registra aquí el nuevo operador
	bpy.utils.register_class(OBJECT_OT_select_target_mesh)  # Registra el nuevo operador
	bpy.types.Scene.scanner_target_mesh = bpy.props.StringProperty(name="Target Mesh")
	bpy.types.Scene.scanner_count = bpy.props.IntProperty(name="Number of Scanners", default=1, min=1)
	bpy.types.Scene.float_value_to_show = bpy.props.FloatProperty(name="Float Value", default=0.0)
	bpy.types.Scene.hide_generated_scanners = bpy.props.BoolProperty(name="Hide generated scanners", default=True)
	bpy.app.handlers.depsgraph_update_post.append(update_height_on_move)


def unregister():
	bpy.utils.unregister_class(OPEN_OT_link)
	bpy.utils.unregister_class(OBJECT_PT_tlsynth_info_panel)
	bpy.utils.unregister_class(OBJECT_OT_generate_scanners)
	bpy.utils.unregister_class(OBJECT_OT_show_float_value)
	bpy.utils.unregister_class(EXPORT_OT_points_ply)
	bpy.utils.unregister_class(EXPORT_OT_combined_ply)
	bpy.utils.unregister_class(EXPORT_OT_animated_points_ply)  # Eliminación del nuevo operador
	bpy.utils.unregister_class(OBJECT_PT_generate_scanners_panel)
	bpy.utils.unregister_class(OBJECT_PT_float_value_and_export_panel)
	bpy.utils.unregister_class(OBJECT_OT_render_top_view)  # Y desregistra aquí también
	bpy.utils.unregister_class(OBJECT_OT_select_target_mesh)  # Desregistra el operador
	del bpy.types.Scene.scanner_target_mesh
	del bpy.types.Scene.scanner_count
	del bpy.types.Scene.float_value_to_show
	del bpy.types.Scene.hide_generated_scanners
	bpy.app.handlers.depsgraph_update_post.remove(update_height_on_move)


if __name__ == "__main__":
	register()
